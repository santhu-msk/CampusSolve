import asyncio
from typing import Any, Dict, Optional, Set
from fastapi import WebSocket

from .database import SessionLocal
from . import services


class NotificationHub:
    """Authoritative WebSocket hub broadcasting live library alerts to connected librarians."""

    def __init__(self) -> None:
        self._connections: Set[WebSocket] = set()
        self._lock = asyncio.Lock()
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    def set_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        self._loop = loop

    async def connect(self, websocket: WebSocket) -> None:
        await websocket.accept()
        async with self._lock:
            self._connections.add(websocket)

    async def disconnect(self, websocket: WebSocket) -> None:
        async with self._lock:
            self._connections.discard(websocket)

    async def broadcast_json(self, message: Dict[str, Any]) -> None:
        async with self._lock:
            targets = list(self._connections)
        if not targets:
            return

        stale: list[WebSocket] = []
        for ws in targets:
            try:
                await ws.send_json(message)
            except Exception:
                stale.append(ws)

        if stale:
            async with self._lock:
                for ws in stale:
                    self._connections.discard(ws)

    async def broadcast_snapshot(self, event: str, alert: Optional[Dict[str, Any]] = None) -> None:
        db = SessionLocal()
        try:
            payload = services.build_notifications_payload(db)
        finally:
            db.close()

        await self.broadcast_json(
            {
                "type": "notification:sync",
                "event": event,
                "alert": alert,
                "payload": payload,
            }
        )

    def schedule_publish(self, event: str, alert: Optional[Dict[str, Any]] = None) -> None:
        if self._loop is None or self._loop.is_closed():
            return
        if not self._connections:
            return
        try:
            asyncio.run_coroutine_threadsafe(self.broadcast_snapshot(event, alert=alert), self._loop)
        except RuntimeError:
            pass


hub = NotificationHub()
