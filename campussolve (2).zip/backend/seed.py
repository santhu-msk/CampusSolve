from datetime import datetime, timedelta, timezone
from sqlalchemy.orm import Session

from .models import (
    ActivityLogModel,
    BookModel,
    MemberModel,
    MemberRequestModel,
    SettingModel,
    TransactionModel,
)


def _iso_date_offset(base: datetime, days: int) -> str:
    return (base + timedelta(days=days)).date().isoformat()


def _iso_ts_offset(base: datetime, days: int, hour: int = 10) -> str:
    d = (base + timedelta(days=days)).replace(hour=hour, minute=15, second=0, microsecond=0)
    return d.isoformat()


def seed_default_settings(db: Session) -> None:
    defaults = {
        "library_name": "CampusSolve Central Library",
        "institution_name": "Northbridge Institute of Technology",
        "default_loan_days": "14",
        "daily_fine_rate": "2.50",
        "warning_threshold_days": "3",
        "critical_overdue_days": "14",
        "default_borrow_limit": "5",
        "currency_symbol": "$",
    }
    for key, val in defaults.items():
        if not db.query(SettingModel).filter(SettingModel.key == key).first():
            db.add(SettingModel(key=key, value=val))
    db.commit()


def seed_initial_data_if_empty(db: Session) -> None:
    seed_default_settings(db)
    if db.query(BookModel).count() > 0:
        return

    today = datetime.now(timezone.utc)
    cs_cover = "/src/assets/images/cover_computer_science_1795149378897.jpg"
    sci_cover = "/src/assets/images/cover_natural_science_1795149379448.jpg"
    hum_cover = "/src/assets/images/cover_humanities_art_1795149379092.jpg"
    econ_cover = "/src/assets/images/cover_economics_law_1795149378934.jpg"

    books_seed = [
        ("BK-1001", "978-0262046305", "Introduction to Algorithms (4th Edition)", "Thomas H. Cormen, Charles E. Leiserson", "Computer Science", "MIT Press", 2022, "CS-A1-01", "Comprehensive reference on data structures, graph algorithms, dynamic programming, and NP-completeness.", cs_cover, 8),
        ("BK-1002", "978-1492040347", "Designing Data-Intensive Applications", "Martin Kleppmann", "Computer Science", "O'Reilly Media", 2021, "CS-A1-04", "Architectural principles behind reliable, scalable, and maintainable distributed data systems.", cs_cover, 7),
        ("BK-1003", "978-0134685991", "Effective Java (3rd Edition)", "Joshua Bloch", "Computer Science", "Addison-Wesley", 2020, "CS-A2-02", "Best-practice design patterns and concurrency idioms for robust enterprise software.", None, 5),
        ("BK-1004", "978-0262035613", "Deep Learning", "Ian Goodfellow, Yoshua Bengio, Aaron Courville", "Computer Science", "MIT Press", 2019, "CS-A2-09", "Mathematical foundations and modern architectures for neural networks and representation learning.", cs_cover, 6),
        ("BK-1005", "978-0132350884", "Clean Code: Agile Software Craftsmanship", "Robert C. Martin", "Computer Science", "Prentice Hall", 2018, "CS-A3-03", "Principles, patterns, and refactoring disciplines for writing maintainable software systems.", None, 6),
        ("BK-1006", "978-0321573513", "Algorithms (4th Edition)", "Robert Sedgewick, Kevin Wayne", "Computer Science", "Addison-Wesley", 2019, "CS-A3-07", "Sorting, searching, graph processing, and string algorithms with rigorous empirical analysis.", None, 5),
        ("BK-1007", "978-1593279509", "Eloquent JavaScript (4th Edition)", "Marijn Haverbeke", "Computer Science", "No Starch Press", 2024, "CS-B1-02", "Modern JavaScript fundamentals, asynchronous architecture, and browser runtime engineering.", None, 4),
        ("BK-1008", "978-0198853282", "Quantum Computation and Quantum Information", "Michael A. Nielsen, Isaac L. Chuang", "Natural Sciences", "Cambridge University Press", 2020, "NS-B2-01", "Foundational treatise on quantum circuits, error correction, and quantum information theory.", sci_cover, 5),
        ("BK-1009", "978-1108420990", "Introduction to Electrodynamics", "David J. Griffiths", "Natural Sciences", "Cambridge University Press", 2021, "NS-B2-06", "Undergraduate and graduate standard text on vector calculus, electrostatics, and Maxwell equations.", sci_cover, 6),
        ("BK-1010", "978-0691177298", "The Theoretical Minimum: Quantum Mechanics", "Leonard Susskind, Art Friedman", "Natural Sciences", "Basic Books", 2019, "NS-B3-04", "Rigorous conceptual introduction to state vectors, operators, entanglement, and spin systems.", None, 4),
        ("BK-1011", "978-0393609394", "Astrophysics for People in a Hurry", "Neil deGrasse Tyson", "Natural Sciences", "W. W. Norton", 2018, "NS-B3-08", "Concise exploration of cosmology, dark matter, exoplanets, and fundamental forces.", None, 5),
        ("BK-1012", "978-0815344322", "Molecular Biology of the Cell (7th Edition)", "Bruce Alberts", "Natural Sciences", "W. W. Norton", 2022, "NS-C1-02", "Definitive reference on cellular architecture, genetics, signaling pathways, and metabolism.", sci_cover, 5),
        ("BK-1013", "978-0980232776", "Linear Algebra Done Right (4th Edition)", "Sheldon Axler", "Mathematics", "Springer", 2024, "MA-A1-03", "Vector spaces, linear maps, eigenvalues, and inner product spaces without determinant-first clutter.", None, 7),
        ("BK-1014", "978-0387942841", "Principles of Mathematical Analysis", "Walter Rudin", "Mathematics", "McGraw-Hill", 2019, "MA-A1-08", "Classic rigorous treatment of metric spaces, sequences, differentiation, and Lebesgue integration.", None, 5),
        ("BK-1015", "978-0521880688", "Convex Optimization", "Stephen Boyd, Lieven Vandenberghe", "Mathematics", "Cambridge University Press", 2020, "MA-A2-05", "Theory, duality, and interior-point algorithms for convex optimization problems.", None, 6),
        ("BK-1016", "978-0691167510", "All of Statistics: A Concise Course", "Larry Wasserman", "Mathematics", "Springer", 2019, "MA-B1-01", "Probability, statistical inference, nonparametric methods, and modern machine learning theory.", None, 4),
        ("BK-1017", "978-0143127741", "Sapiens: A Brief History of Humankind", "Yuval Noah Harari", "Humanities & Arts", "Harper", 2018, "HA-A1-02", "Sweeping anthropological synthesis of cognitive, agricultural, and scientific revolutions.", hum_cover, 6),
        ("BK-1018", "978-0262537278", "The Design of Everyday Things", "Don Norman", "Humanities & Arts", "MIT Press", 2019, "HA-A2-07", "Human-centered cognitive psychology applied to industrial design, affordances, and usability.", hum_cover, 6),
        ("BK-1019", "978-0300246049", "Grid Systems in Graphic Design", "Josef Müller-Brockmann", "Humanities & Arts", "Niggli Verlag", 2021, "HA-B1-03", "Foundational Swiss typographic manual on proportional layout grids and visual clarity.", hum_cover, 4),
        ("BK-1020", "978-0140449136", "Meditations", "Marcus Aurelius", "Humanities & Arts", "Penguin Classics", 2020, "HA-B2-01", "Stoic philosophical notebooks on resilience, civic duty, and disciplined reasoning.", None, 5),
        ("BK-1021", "978-0674979857", "A Theory of Justice", "John Rawls", "Humanities & Arts", "Harvard University Press", 2020, "HA-B2-09", "Landmark treatise on distributive justice, the veil of ignorance, and democratic institutions.", None, 4),
        ("BK-1022", "978-0374533557", "Thinking, Fast and Slow", "Daniel Kahneman", "Economics & Law", "Farrar, Straus and Giroux", 2019, "EL-A1-01", "Behavioral economics investigation of dual-process judgment, heuristics, and prospect theory.", econ_cover, 7),
        ("BK-1023", "978-0674430006", "Capital in the Twenty-First Century", "Thomas Piketty", "Economics & Law", "Harvard University Press", 2018, "EL-A1-06", "Empirical historical study of wealth concentration, capital returns, and fiscal policy.", econ_cover, 4),
        ("BK-1024", "978-0307887894", "The Lean Startup", "Eric Ries", "Economics & Law", "Crown Business", 2020, "EL-A2-02", "Validated learning, rapid experimentation, and iterative product strategy in modern enterprises.", None, 5),
        ("BK-1025", "978-0198810926", "Principles of Corporate Finance", "Richard A. Brealey, Stewart C. Myers", "Economics & Law", "McGraw-Hill", 2022, "EL-B1-04", "Valuation, capital budgeting, asset pricing, and corporate governance frameworks.", econ_cover, 5),
        ("BK-1026", "978-0691182698", "Narrative Economics", "Robert J. Shiller", "Economics & Law", "Princeton University Press", 2021, "EL-B1-09", "How viral stories and collective beliefs shape macroeconomic cycles and market volatility.", None, 3),
        ("BK-1027", "978-0128148204", "Feedback Systems: An Introduction for Scientists", "Karl Johan Åström, Richard M. Murray", "Engineering", "Princeton University Press", 2021, "EN-A1-02", "Control theory, stability analysis, state-space modeling, and robust feedback engineering.", None, 5),
        ("BK-1028", "978-0133594140", "Microelectronic Circuits (8th Edition)", "Adel S. Sedra, Kenneth C. Smith", "Engineering", "Oxford University Press", 2020, "EN-A2-05", "Analog and digital circuit analysis, CMOS architectures, and amplifier frequency response.", None, 6),
        ("BK-1029", "978-0470509074", "Fundamentals of Thermodynamics", "Claus Borgnakke, Richard E. Sonntag", "Engineering", "Wiley", 2019, "EN-B1-01", "Classical laws of thermodynamics, entropy, power cycles, and chemical equilibrium.", None, 4),
        ("BK-1030", "978-0134092669", "Signals and Systems", "Alan V. Oppenheim, Alan S. Willsky", "Engineering", "Pearson", 2020, "EN-B1-07", "Continuous and discrete-time Fourier, Laplace, and Z-transform system analysis.", None, 5),
        ("BK-1031", "978-0262043793", "Probabilistic Robotics", "Sebastian Thrun, Wolfram Burgard, Dieter Fox", "Engineering", "MIT Press", 2019, "EN-C1-03", "Bayesian filtering, Kalman localization, SLAM, and autonomous planning under uncertainty.", cs_cover, 4),
        ("BK-1032", "978-1119455813", "Structural Analysis (10th Edition)", "Russell C. Hibbeler", "Engineering", "Pearson", 2021, "EN-C2-04", "Determinate and indeterminate trusses, beams, influence lines, and matrix stiffness methods.", None, 3),
    ]

    members_seed = [
        ("MEM-2001", "Aarav Mehta", "aarav.mehta@northbridge.edu", "+1 (555) 201-4810", "Computer Science", "B.Tech Artificial Intelligence", "Student", "Active", 5, -180),
        ("MEM-2002", "Sophia Lin", "sophia.lin@northbridge.edu", "+1 (555) 201-4821", "Computer Science", "M.S. Distributed Systems", "Student", "Active", 6, -165),
        ("MEM-2003", "Dr. Marcus Holloway", "m.holloway@northbridge.edu", "+1 (555) 201-4832", "Natural Sciences", "Quantum Photonics Lab", "Faculty", "Active", 10, -160),
        ("MEM-2004", "Priya Nair", "priya.nair@northbridge.edu", "+1 (555) 201-4843", "Mathematics", "Ph.D. Applied Mathematics", "Researcher", "Active", 8, -152),
        ("MEM-2005", "Liam O'Connor", "liam.oconnor@northbridge.edu", "+1 (555) 201-4854", "Economics & Law", "B.A. Quantitative Economics", "Student", "Active", 5, -140),
        ("MEM-2006", "Elena Rostova", "elena.rostova@northbridge.edu", "+1 (555) 201-4865", "Engineering", "M.S. Robotics & Control", "Student", "Active", 6, -135),
        ("MEM-2007", "Noah Kim", "noah.kim@northbridge.edu", "+1 (555) 201-4876", "Computer Science", "B.S. Computer Engineering", "Student", "Active", 5, -125),
        ("MEM-2008", "Prof. Clara Sterling", "c.sterling@northbridge.edu", "+1 (555) 201-4887", "Humanities & Arts", "Department of Design Studies", "Faculty", "Active", 10, -118),
        ("MEM-2009", "Daniel Okafor", "daniel.okafor@northbridge.edu", "+1 (555) 201-4898", "Engineering", "B.Tech Electrical Engineering", "Student", "Active", 5, -110),
        ("MEM-2010", "Hannah Bergstrom", "hannah.bergstrom@northbridge.edu", "+1 (555) 201-4909", "Natural Sciences", "M.S. Molecular Biology", "Researcher", "Active", 8, -98),
        ("MEM-2011", "Rohan Kulkarni", "rohan.kulkarni@northbridge.edu", "+1 (555) 201-4910", "Computer Science", "B.Tech Data Science", "Student", "Active", 5, -90),
        ("MEM-2012", "Maya Alvarez", "maya.alvarez@northbridge.edu", "+1 (555) 201-4921", "Humanities & Arts", "M.A. Visual Communication", "Student", "Active", 5, -82),
        ("MEM-2013", "Ethan Brooks", "ethan.brooks@northbridge.edu", "+1 (555) 201-4932", "Economics & Law", "MBA Technology Management", "Student", "Active", 6, -75),
        ("MEM-2014", "Zara Al-Mansoor", "zara.mansoor@northbridge.edu", "+1 (555) 201-4943", "Mathematics", "M.S. Financial Mathematics", "Student", "Active", 5, -64),
        ("MEM-2015", "Dr. Henrik Lindqvist", "h.lindqvist@northbridge.edu", "+1 (555) 201-4954", "Engineering", "Autonomous Systems Faculty", "Faculty", "Active", 10, -56),
        ("MEM-2016", "Chloe Moreau", "chloe.moreau@northbridge.edu", "+1 (555) 201-4965", "Natural Sciences", "B.S. Astrophysics", "Student", "Active", 5, -48),
        ("MEM-2017", "Lucas Fernandez", "lucas.fernandez@northbridge.edu", "+1 (555) 201-4976", "Economics & Law", "LL.B. Corporate Policy", "Student", "Suspended", 5, -40),
        ("MEM-2018", "Ananya Sharma", "ananya.sharma@northbridge.edu", "+1 (555) 201-4987", "Computer Science", "Ph.D. Machine Learning", "Researcher", "Active", 8, -32),
        ("MEM-2019", "Oliver Grant", "oliver.grant@northbridge.edu", "+1 (555) 201-4998", "Administration", "Academic Registrar Office", "Staff", "Active", 5, -24),
        ("MEM-2020", "Nadia Petrova", "nadia.petrova@northbridge.edu", "+1 (555) 201-5009", "Mathematics", "B.S. Pure Mathematics", "Student", "Active", 5, -18),
        ("MEM-2021", "Samuel Adeyemi", "samuel.adeyemi@northbridge.edu", "+1 (555) 201-5010", "Engineering", "M.S. Structural Systems", "Student", "Active", 6, -12),
        ("MEM-2022", "Grace Takahashi", "grace.takahashi@northbridge.edu", "+1 (555) 201-5021", "Humanities & Arts", "B.A. Philosophy & Ethics", "Student", "Active", 5, -8),
        ("MEM-2023", "Kabir Verma", "kabir.verma@northbridge.edu", "+1 (555) 201-5032", "Computer Science", "B.Tech Cybersecurity", "Student", "Active", 5, -5),
        ("MEM-2024", "Victoria Chen", "victoria.chen@northbridge.edu", "+1 (555) 201-5043", "Economics & Law", "M.S. Behavioral Finance", "Researcher", "Active", 8, -2),
    ]

    tx_seed = [
        ("TXN-3001", "BK-1001", "MEM-2001", -155, -141, -143, "Returned", 0.0, "Returned in good condition"),
        ("TXN-3002", "BK-1008", "MEM-2003", -150, -136, -135, "Returned", 2.5, "1 day late return"),
        ("TXN-3003", "BK-1013", "MEM-2004", -146, -132, -133, "Returned", 0.0, ""),
        ("TXN-3004", "BK-1022", "MEM-2005", -142, -128, -129, "Returned", 0.0, ""),
        ("TXN-3005", "BK-1018", "MEM-2008", -138, -124, -120, "Returned", 10.0, "4 days overdue fine settled"),
        ("TXN-3006", "BK-1002", "MEM-2002", -124, -110, -112, "Returned", 0.0, ""),
        ("TXN-3007", "BK-1004", "MEM-2001", -119, -105, -106, "Returned", 0.0, ""),
        ("TXN-3008", "BK-1017", "MEM-2012", -115, -101, -100, "Returned", 2.5, ""),
        ("TXN-3009", "BK-1028", "MEM-2009", -112, -98, -99, "Returned", 0.0, ""),
        ("TXN-3010", "BK-1015", "MEM-2004", -105, -91, -92, "Returned", 0.0, ""),
        ("TXN-3011", "BK-1023", "MEM-2013", -101, -87, -85, "Returned", 5.0, ""),
        ("TXN-3012", "BK-1001", "MEM-2011", -92, -78, -80, "Returned", 0.0, ""),
        ("TXN-3013", "BK-1009", "MEM-2016", -88, -74, -75, "Returned", 0.0, ""),
        ("TXN-3014", "BK-1012", "MEM-2010", -84, -70, -68, "Returned", 5.0, ""),
        ("TXN-3015", "BK-1031", "MEM-2006", -80, -66, -67, "Returned", 0.0, ""),
        ("TXN-3016", "BK-1019", "MEM-2008", -76, -62, -63, "Returned", 0.0, ""),
        ("TXN-3017", "BK-1025", "MEM-2005", -72, -58, -58, "Returned", 0.0, ""),
        ("TXN-3018", "BK-1002", "MEM-2007", -62, -48, -49, "Returned", 0.0, ""),
        ("TXN-3019", "BK-1005", "MEM-2011", -58, -44, -42, "Returned", 5.0, ""),
        ("TXN-3020", "BK-1014", "MEM-2014", -55, -41, -43, "Returned", 0.0, ""),
        ("TXN-3021", "BK-1027", "MEM-2015", -51, -37, -38, "Returned", 0.0, ""),
        ("TXN-3022", "BK-1024", "MEM-2013", -48, -34, -35, "Returned", 0.0, ""),
        ("TXN-3023", "BK-1003", "MEM-2002", -44, -30, -31, "Returned", 0.0, ""),
        ("TXN-3024", "BK-1010", "MEM-2003", -40, -26, -26, "Returned", 0.0, ""),
        ("TXN-3025", "BK-1001", "MEM-2018", -35, -21, -22, "Returned", 0.0, ""),
        ("TXN-3026", "BK-1004", "MEM-2007", -32, -18, -19, "Returned", 0.0, ""),
        ("TXN-3027", "BK-1001", "MEM-2001", -38, -24, None, "Overdue", 0.0, "Thesis algorithm reference"),
        ("TXN-3028", "BK-1012", "MEM-2010", -34, -20, None, "Overdue", 0.0, "Lab manual extended use"),
        ("TXN-3029", "BK-1019", "MEM-2012", -30, -16, None, "Overdue", 0.0, "Studio exhibition prep"),
        ("TXN-3030", "BK-1026", "MEM-2017", -28, -14, None, "Overdue", 0.0, "Account suspended pending return"),
        ("TXN-3031", "BK-1002", "MEM-2011", -24, -10, None, "Overdue", 0.0, "Systems coursework"),
        ("TXN-3032", "BK-1014", "MEM-2020", -21, -7, None, "Overdue", 0.0, "Real analysis problem set"),
        ("TXN-3033", "BK-1031", "MEM-2006", -19, -5, None, "Overdue", 0.0, "SLAM benchmark experiment"),
        ("TXN-3034", "BK-1025", "MEM-2013", -17, -3, None, "Overdue", 0.0, "Corporate finance case study"),
        ("TXN-3035", "BK-1018", "MEM-2022", -15, -1, None, "Overdue", 0.0, "Human factors seminar"),
        ("TXN-3036", "BK-1008", "MEM-2003", -12, 2, None, "Issued", 0.0, "Quantum seminar copy"),
        ("TXN-3037", "BK-1004", "MEM-2018", -11, 3, None, "Issued", 0.0, "Neural scaling research"),
        ("TXN-3038", "BK-1013", "MEM-2004", -10, 4, None, "Issued", 0.0, "Graduate algebra reading"),
        ("TXN-3039", "BK-1022", "MEM-2024", -9, 5, None, "Issued", 0.0, "Behavioral finance survey"),
        ("TXN-3040", "BK-1028", "MEM-2009", -8, 6, None, "Issued", 0.0, "CMOS circuit lab"),
        ("TXN-3041", "BK-1001", "MEM-2002", -7, 7, None, "Issued", 0.0, "Graph theory module"),
        ("TXN-3042", "BK-1002", "MEM-2023", -6, 8, None, "Issued", 0.0, "Consensus protocol review"),
        ("TXN-3043", "BK-1015", "MEM-2014", -5, 9, None, "Issued", 0.0, "Optimization seminar"),
        ("TXN-3044", "BK-1017", "MEM-2022", -4, 10, None, "Issued", 0.0, "History seminar"),
        ("TXN-3045", "BK-1030", "MEM-2015", -3, 11, None, "Issued", 0.0, "Signal processing lecture prep"),
        ("TXN-3046", "BK-1007", "MEM-2023", -2, 12, None, "Issued", 0.0, "Frontend engineering module"),
        ("TXN-3047", "BK-1029", "MEM-2021", -2, 12, None, "Issued", 0.0, "Thermal systems lab"),
        ("TXN-3048", "BK-1009", "MEM-2016", -1, 13, None, "Issued", 0.0, "Electrodynamics problem set"),
        ("TXN-3049", "BK-1021", "MEM-2008", -1, 13, None, "Issued", 0.0, "Ethics symposium"),
    ]

    active_per_book = {}
    for tx in tx_seed:
        if tx[5] is None:
            active_per_book[tx[1]] = active_per_book.get(tx[1], 0) + 1

    book_ts = _iso_ts_offset(today, -180, 9)
    for b in books_seed:
        b_id, isbn, title, author, category, publisher, year, shelf, desc, cover, total = b
        avail = max(0, total - active_per_book.get(b_id, 0))
        db.add(
            BookModel(
                id=b_id,
                isbn=isbn,
                title=title,
                author=author,
                category=category,
                publisher=publisher,
                publication_year=year,
                shelf_location=shelf,
                description=desc,
                cover_image=cover,
                total_copies=total,
                available_copies=avail,
                created_at=book_ts,
                updated_at=book_ts,
            )
        )

    for m in members_seed:
        m_id, name, email, phone, dept, course, m_type, status, limit, offset = m
        joined = _iso_ts_offset(today, offset, 10)
        db.add(
            MemberModel(
                id=m_id,
                full_name=name,
                email=email,
                phone=phone,
                department=dept,
                course=course,
                member_type=m_type,
                status=status,
                max_borrow_limit=limit,
                joined_at=joined,
                updated_at=joined,
            )
        )

    for tx in tx_seed:
        t_id, b_id, m_id, i_off, d_off, r_off, status, fine, notes = tx
        issue_d = _iso_date_offset(today, i_off)
        due_d = _iso_date_offset(today, d_off)
        ret_d = _iso_date_offset(today, r_off) if r_off is not None else None
        created = _iso_ts_offset(today, i_off, 11)
        updated = _iso_ts_offset(today, r_off, 15) if r_off is not None else created
        db.add(
            TransactionModel(
                id=t_id,
                book_id=b_id,
                member_id=m_id,
                issue_date=issue_d,
                due_date=due_d,
                return_date=ret_d,
                status=status,
                fine_amount=fine,
                notes=notes,
                created_at=created,
                updated_at=updated,
            )
        )

    activities = [
        ("BOOK_ISSUED", "Transaction", "TXN-3049", 'Issued "A Theory of Justice" (BK-1021) to Prof. Clara Sterling (MEM-2008)', -1),
        ("BOOK_ISSUED", "Transaction", "TXN-3048", 'Issued "Introduction to Electrodynamics" (BK-1009) to Chloe Moreau (MEM-2016)', -1),
        ("BOOK_ISSUED", "Transaction", "TXN-3047", 'Issued "Fundamentals of Thermodynamics" (BK-1029) to Samuel Adeyemi (MEM-2021)', -2),
        ("MEMBER_REGISTERED", "Member", "MEM-2024", "Registered researcher Victoria Chen (Economics & Law)", -2),
        ("BOOK_ISSUED", "Transaction", "TXN-3045", 'Issued "Signals and Systems" (BK-1030) to Dr. Henrik Lindqvist (MEM-2015)', -3),
        ("MEMBER_REGISTERED", "Member", "MEM-2023", "Registered student Kabir Verma (Computer Science)", -5),
        ("BOOK_RETURNED", "Transaction", "TXN-3026", 'Returned "Deep Learning" (BK-1004) from Noah Kim (MEM-2007)', -19),
        ("BOOK_RETURNED", "Transaction", "TXN-3025", 'Returned "Introduction to Algorithms" (BK-1001) from Ananya Sharma (MEM-2018)', -22),
    ]
    for a_type, e_type, e_id, summary, off in activities:
        db.add(
            ActivityLogModel(
                action_type=a_type,
                entity_type=e_type,
                entity_id=e_id,
                summary=summary,
                actor="Dr. Eleanor Vance",
                created_at=_iso_ts_offset(today, off, 14),
            )
        )

    db.commit()
    seed_initial_requests_if_empty(db)


def seed_initial_requests_if_empty(db: Session) -> None:
    if db.query(SettingModel).filter(SettingModel.key == "requests_seeded").first():
        return
    if db.query(MemberRequestModel).count() > 0:
        db.add(SettingModel(key="requests_seeded", value="1"))
        db.commit()
        return

    member_ids = {m_id for (m_id,) in db.query(MemberModel.id).all()}
    book_ids = {b_id for (b_id,) in db.query(BookModel.id).all()}
    if not member_ids:
        return

    today = datetime.now(timezone.utc)
    default_member = next(iter(member_ids))
    default_book = next(iter(book_ids)) if book_ids else None

    seeds = [
        (
            "REQ-4001",
            "MEM-2003" if "MEM-2003" in member_ids else default_member,
            "BK-1008" if "BK-1008" in book_ids else default_book,
            "Course Reserve",
            "Critical",
            "Urgent Faculty Course Reserve — Quantum Seminar",
            "Dr. Marcus Holloway requested immediate desk hold of Quantum Computation & Quantum Information for tomorrow's 09:00 graduate lab.",
            "Pending",
            0,
            8,
        ),
        (
            "REQ-4002",
            "MEM-2018" if "MEM-2018" in member_ids else default_member,
            "BK-1004" if "BK-1004" in book_ids else default_book,
            "Loan Extension",
            "Urgent",
            "Expedited 7-Day Loan Extension Request",
            "Ananya Sharma requested an urgent extension on Deep Learning (due shortly) for Ph.D. benchmark evaluation.",
            "Pending",
            0,
            9,
        ),
        (
            "REQ-4003",
            "MEM-2002" if "MEM-2002" in member_ids else default_member,
            "BK-1002" if "BK-1002" in book_ids else default_book,
            "Urgent Hold",
            "Urgent",
            "Priority Pickup Hold — Distributed Systems",
            "Sophia Lin requested priority notification and circulation desk hold as soon as the next copy checks in.",
            "Pending",
            -1,
            15,
        ),
    ]

    for req_id, m_id, b_id, r_type, urgency, title, notes, status, d_off, hour in seeds:
        ts = _iso_ts_offset(today, d_off, hour)
        db.add(
            MemberRequestModel(
                id=req_id,
                member_id=m_id,
                book_id=b_id,
                request_type=r_type,
                urgency=urgency,
                title=title,
                notes=notes,
                status=status,
                created_at=ts,
                updated_at=ts,
            )
        )
    db.add(SettingModel(key="requests_seeded", value="1"))
    db.commit()
