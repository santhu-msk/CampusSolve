import csv
import io
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy.orm import Session

from .database import DATABASE_URL
from .models import BookModel, MemberModel, TransactionModel
from .seed import seed_default_settings, seed_initial_data_if_empty, seed_initial_requests_if_empty
from .validators import SyncError, sanitize_text, validate_isbn

BOOK_FIELDS = [
    "id",
    "isbn",
    "title",
    "author",
    "category",
    "publisher",
    "publication_year",
    "shelf_location",
    "description",
    "cover_image",
    "total_copies",
    "available_copies",
    "created_at",
    "updated_at",
]

MEMBER_FIELDS = [
    "id",
    "full_name",
    "email",
    "phone",
    "department",
    "course",
    "member_type",
    "status",
    "max_borrow_limit",
    "joined_at",
    "updated_at",
]

TRANSACTION_FIELDS = [
    "id",
    "book_id",
    "member_id",
    "issue_date",
    "due_date",
    "return_date",
    "status",
    "fine_amount",
    "notes",
    "created_at",
    "updated_at",
]

_LAST_SYNC_STATE: Dict[str, Any] = {
    "status": "uninitialized",
    "last_synced_at": None,
    "warnings": [],
    "files": {},
}


def resolve_storage_dir() -> Path:
    custom = os.getenv("CAMPUSSOLVE_STORAGE_DIR")
    if custom:
        p = Path(custom)
        p.mkdir(parents=True, exist_ok=True)
        return p

    # When tests override CAMPUSSOLVE_DATABASE_URL to a temp SQLite DB without setting
    # CAMPUSSOLVE_STORAGE_DIR, keep test CSV/JSON files isolated next to that DB rather than data/
    if DATABASE_URL.startswith("sqlite:///") and not DATABASE_URL.endswith("/data/campussolve.db"):
        db_file = Path(DATABASE_URL.replace("sqlite:///", "", 1))
        if db_file.parent.exists():
            sync_dir = db_file.parent / f"{db_file.stem}_sync"
            sync_dir.mkdir(parents=True, exist_ok=True)
            return sync_dir

    data_dir = Path(__file__).resolve().parent.parent / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir


def _cleanup_stale_temps(storage_dir: Path) -> List[str]:
    cleaned: List[str] = []
    for tmp_file in storage_dir.glob("*.tmp"):
        try:
            tmp_file.unlink()
            cleaned.append(tmp_file.name)
        except OSError:
            pass
    return cleaned


def _backup_corrupted_file(file_path: Path, reason: str) -> Optional[str]:
    if not file_path.exists():
        return None
    backup_dir = file_path.parent / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup_path = backup_dir / f"corrupted_{file_path.name}.{ts}.bak"
    try:
        shutil.copy2(file_path, backup_path)
        return f"Preserved backup of {file_path.name} ({reason}) at backups/{backup_path.name}"
    except OSError as exc:
        return f"Failed to back up {file_path.name}: {exc}"


def _atomic_write_text(target: Path, content: str) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = target.parent / f".{target.name}.{os.getpid()}.tmp"
    try:
        with open(tmp_path, "w", encoding="utf-8", newline="") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, target)
    except Exception as exc:
        if tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass
        raise SyncError(f"Atomic file write failed for {target.name}: {exc}") from exc


def _read_json_records(path: Path, warnings: List[str]) -> Optional[List[Dict[str, Any]]]:
    if not path.exists():
        return None
    raw = path.read_text(encoding="utf-8", errors="replace")
    if not raw.strip():
        warnings.append(f"{path.name} was empty; will resynchronize from active store.")
        return None
    try:
        data = json.loads(raw)
        if not isinstance(data, list):
            msg = _backup_corrupted_file(path, "JSON root is not a list")
            if msg:
                warnings.append(msg)
            return None
        return [row for row in data if isinstance(row, dict)]
    except json.JSONDecodeError as exc:
        msg = _backup_corrupted_file(path, f"Corrupted JSON: {exc}")
        if msg:
            warnings.append(msg)
        return None


def _read_csv_records(path: Path, required_cols: Tuple[str, ...], warnings: List[str]) -> Optional[List[Dict[str, Any]]]:
    if not path.exists():
        return None
    raw = path.read_text(encoding="utf-8", errors="replace")
    if not raw.strip():
        warnings.append(f"{path.name} was empty; will resynchronize from active store.")
        return None
    try:
        reader = csv.DictReader(io.StringIO(raw))
        if not reader.fieldnames or not all(col in reader.fieldnames for col in required_cols):
            msg = _backup_corrupted_file(path, "Malformed CSV or missing required columns")
            if msg:
                warnings.append(msg)
            return None
        rows: List[Dict[str, Any]] = []
        for row in reader:
            if None in row:
                # Extra unmapped columns indicate malformed CSV row
                msg = _backup_corrupted_file(path, "Malformed CSV column count")
                if msg:
                    warnings.append(msg)
                return None
            if any(str(v or "").strip() for v in row.values()):
                rows.append({k: v for k, v in row.items() if k is not None})
        return rows
    except csv.Error as exc:
        msg = _backup_corrupted_file(path, f"Malformed CSV: {exc}")
        if msg:
            warnings.append(msg)
        return None


def _hydrate_sqlite_from_files(
    db: Session,
    books_raw: List[Dict[str, Any]],
    members_raw: List[Dict[str, Any]],
    tx_raw: List[Dict[str, Any]],
    warnings: List[str],
) -> bool:
    seen_book_ids = set()
    seen_isbns = set()
    books_loaded = 0
    ts = datetime.now(timezone.utc).isoformat()

    for idx, b in enumerate(books_raw, start=1):
        b_id = sanitize_text(b.get("id"), 30).upper()
        title = sanitize_text(b.get("title"), 200)
        author = sanitize_text(b.get("author"), 150)
        if not b_id or not title or not author:
            warnings.append(f"Skipped invalid book row #{idx} during file recovery.")
            continue
        try:
            isbn = validate_isbn(b.get("isbn"), required=True)
            total = int(b.get("total_copies", 0))
            avail = int(b.get("available_copies", total))
            year = int(b.get("publication_year", 2022))
        except Exception:
            warnings.append(f"Skipped malformed book {b_id} during file recovery.")
            continue
        if total < 0 or avail < 0 or avail > total:
            warnings.append(f"Skipped book {b_id} with invalid copy counts during recovery.")
            continue
        if b_id in seen_book_ids or isbn.lower() in seen_isbns:
            warnings.append(f"Skipped duplicate book {b_id} / ISBN {isbn} during recovery.")
            continue
        seen_book_ids.add(b_id)
        seen_isbns.add(isbn.lower())
        db.add(
            BookModel(
                id=b_id,
                isbn=isbn,
                title=title,
                author=author,
                category=sanitize_text(b.get("category") or "General", 80),
                publisher=sanitize_text(b.get("publisher") or "Academic Press", 120),
                publication_year=year if 1450 <= year <= 2030 else 2022,
                shelf_location=sanitize_text(b.get("shelf_location") or "GEN-A1-01", 40),
                description=sanitize_text(b.get("description"), 1000),
                cover_image=sanitize_text(b.get("cover_image"), 300) or None,
                total_copies=total,
                available_copies=avail,
                created_at=sanitize_text(b.get("created_at"), 60) or ts,
                updated_at=sanitize_text(b.get("updated_at"), 60) or ts,
            )
        )
        books_loaded += 1

    if books_loaded == 0:
        db.rollback()
        return False

    seen_member_ids = set()
    seen_emails = set()
    for m in members_raw:
        m_id = sanitize_text(m.get("id"), 30).upper()
        name = sanitize_text(m.get("full_name"), 120)
        email = sanitize_text(m.get("email"), 150).lower()
        if not m_id or not name or "@" not in email:
            continue
        if m_id in seen_member_ids or email in seen_emails:
            continue
        seen_member_ids.add(m_id)
        seen_emails.add(email)
        try:
            limit = max(1, min(20, int(m.get("max_borrow_limit", 5))))
        except (TypeError, ValueError):
            limit = 5
        db.add(
            MemberModel(
                id=m_id,
                full_name=name,
                email=email,
                phone=sanitize_text(m.get("phone") or "+1 (555) 000-0000", 40),
                department=sanitize_text(m.get("department") or "General", 100),
                course=sanitize_text(m.get("course") or "General Studies", 120),
                member_type=sanitize_text(m.get("member_type") or "Student", 40),
                status=sanitize_text(m.get("status") or "Active", 40),
                max_borrow_limit=limit,
                joined_at=sanitize_text(m.get("joined_at"), 60) or ts,
                updated_at=sanitize_text(m.get("updated_at"), 60) or ts,
            )
        )

    seen_tx_ids = set()
    for t in tx_raw:
        t_id = sanitize_text(t.get("id"), 30).upper()
        b_id = sanitize_text(t.get("book_id"), 30).upper()
        m_id = sanitize_text(t.get("member_id"), 30).upper()
        if not t_id or t_id in seen_tx_ids or b_id not in seen_book_ids or m_id not in seen_member_ids:
            continue
        seen_tx_ids.add(t_id)
        ret_raw = t.get("return_date")
        ret_val = sanitize_text(ret_raw, 20) if ret_raw not in (None, "") else None
        try:
            fine = float(t.get("fine_amount") or 0.0)
        except (TypeError, ValueError):
            fine = 0.0
        db.add(
            TransactionModel(
                id=t_id,
                book_id=b_id,
                member_id=m_id,
                issue_date=sanitize_text(t.get("issue_date"), 20),
                due_date=sanitize_text(t.get("due_date"), 20),
                return_date=ret_val,
                status=sanitize_text(t.get("status") or ("Returned" if ret_val else "Issued"), 20),
                fine_amount=fine,
                notes=sanitize_text(t.get("notes"), 300),
                created_at=sanitize_text(t.get("created_at"), 60) or ts,
                updated_at=sanitize_text(t.get("updated_at"), 60) or ts,
            )
        )

    db.commit()
    return True


def _serialize_csv(fields: List[str], records: List[Dict[str, Any]]) -> str:
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for rec in records:
        row = {k: ("" if rec.get(k) is None else rec.get(k)) for k in fields}
        writer.writerow(row)
    return buf.getvalue()


def sync_all_files(db: Session, storage_dir: Optional[Path] = None) -> Dict[str, Any]:
    target_dir = storage_dir or resolve_storage_dir()

    books = [
        {
            "id": b.id,
            "isbn": b.isbn,
            "title": b.title,
            "author": b.author,
            "category": b.category,
            "publisher": b.publisher,
            "publication_year": b.publication_year,
            "shelf_location": b.shelf_location,
            "description": b.description or "",
            "cover_image": b.cover_image,
            "total_copies": b.total_copies,
            "available_copies": b.available_copies,
            "created_at": b.created_at,
            "updated_at": b.updated_at,
        }
        for b in db.query(BookModel).order_by(BookModel.id.asc()).all()
    ]
    members = [
        {
            "id": m.id,
            "full_name": m.full_name,
            "email": m.email,
            "phone": m.phone,
            "department": m.department,
            "course": m.course,
            "member_type": m.member_type,
            "status": m.status,
            "max_borrow_limit": m.max_borrow_limit,
            "joined_at": m.joined_at,
            "updated_at": m.updated_at,
        }
        for m in db.query(MemberModel).order_by(MemberModel.id.asc()).all()
    ]
    transactions = [
        {
            "id": t.id,
            "book_id": t.book_id,
            "member_id": t.member_id,
            "issue_date": t.issue_date,
            "due_date": t.due_date,
            "return_date": t.return_date,
            "status": t.status,
            "fine_amount": float(t.fine_amount or 0.0),
            "notes": t.notes or "",
            "created_at": t.created_at,
            "updated_at": t.updated_at,
        }
        for t in db.query(TransactionModel).order_by(TransactionModel.id.asc()).all()
    ]

    try:
        _atomic_write_text(target_dir / "books.json", json.dumps(books, indent=2))
        _atomic_write_text(target_dir / "books.csv", _serialize_csv(BOOK_FIELDS, books))
        _atomic_write_text(target_dir / "members.json", json.dumps(members, indent=2))
        _atomic_write_text(target_dir / "members.csv", _serialize_csv(MEMBER_FIELDS, members))
        _atomic_write_text(target_dir / "transactions.json", json.dumps(transactions, indent=2))
        _atomic_write_text(target_dir / "transactions.csv", _serialize_csv(TRANSACTION_FIELDS, transactions))
    except SyncError as exc:
        _LAST_SYNC_STATE["status"] = "failed"
        _LAST_SYNC_STATE["warnings"] = list(_LAST_SYNC_STATE.get("warnings", [])) + [exc.message]
        raise

    ts = datetime.now(timezone.utc).isoformat()
    _LAST_SYNC_STATE.update(
        {
            "status": "synchronized",
            "last_synced_at": ts,
            "storage_dir": str(target_dir),
            "files": {
                "books.csv": len(books),
                "books.json": len(books),
                "members.csv": len(members),
                "members.json": len(members),
                "transactions.csv": len(transactions),
                "transactions.json": len(transactions),
            },
        }
    )
    return dict(_LAST_SYNC_STATE)


def initialize_storage(db: Session, *, allow_seed: bool = True, storage_dir: Optional[Path] = None) -> Dict[str, Any]:
    target_dir = storage_dir or resolve_storage_dir()
    warnings: List[str] = []

    stale = _cleanup_stale_temps(target_dir)
    if stale:
        warnings.append(f"Recovered from interrupted temporary file(s): {', '.join(stale)}")

    seed_default_settings(db)

    # Validate existing files on startup (preserving corrupted backups rather than overwriting silently)
    books_json = _read_json_records(target_dir / "books.json", warnings)
    books_csv = _read_csv_records(target_dir / "books.csv", ("id", "isbn", "title"), warnings)
    members_json = _read_json_records(target_dir / "members.json", warnings)
    members_csv = _read_csv_records(target_dir / "members.csv", ("id", "full_name", "email"), warnings)
    tx_json = _read_json_records(target_dir / "transactions.json", warnings)
    tx_csv = _read_csv_records(target_dir / "transactions.csv", ("id", "book_id", "member_id"), warnings)

    if db.query(BookModel).count() == 0:
        b_src = books_json if books_json else (books_csv if books_csv else [])
        m_src = members_json if members_json else (members_csv if members_csv else [])
        t_src = tx_json if tx_json else (tx_csv if tx_csv else [])
        hydrated = _hydrate_sqlite_from_files(db, b_src, m_src, t_src, warnings) if b_src else False
        if not hydrated and allow_seed:
            seed_initial_data_if_empty(db)

    if allow_seed:
        seed_initial_requests_if_empty(db)

    _LAST_SYNC_STATE["warnings"] = warnings
    sync_state = sync_all_files(db, storage_dir=target_dir)
    sync_state["warnings"] = warnings
    return sync_state


def get_sync_status() -> Dict[str, Any]:
    return dict(_LAST_SYNC_STATE)
