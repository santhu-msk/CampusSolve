import csv
import io
import json
import re
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from sqlalchemy.orm import Session, joinedload

from .models import (
    ActivityLogModel,
    BookModel,
    MemberModel,
    MemberRequestModel,
    NotificationStateModel,
    SettingModel,
    TransactionModel,
)
from .persistence import sync_all_files
from .validators import (
    ServiceError,
    compute_overdue_days,
    sanitize_text,
    validate_book_fields,
    validate_email,
    validate_isbn,
    validate_iso_date,
    validate_issue_dates,
    validate_member_fields,
    validate_record_id,
)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def today_str() -> str:
    return date.today().isoformat()


def next_id(db: Session, model: Any, prefix: str, start: int) -> str:
    rows = db.query(model.id).all()
    max_num = start - 1
    for (item_id,) in rows:
        match = re.search(r"(\d+)$", str(item_id))
        if match:
            num = int(match.group(1))
            if num > max_num:
                max_num = num
    return f"{prefix}-{max_num + 1}"


def log_activity(
    db: Session,
    action_type: str,
    entity_type: str,
    entity_id: str,
    summary: str,
    actor: str = "Dr. Eleanor Vance",
) -> None:
    db.add(
        ActivityLogModel(
            action_type=action_type,
            entity_type=entity_type,
            entity_id=entity_id,
            summary=summary,
            actor=actor,
            created_at=now_iso(),
        )
    )


def get_settings_typed(db: Session) -> Dict[str, Any]:
    rows = db.query(SettingModel).all()
    raw = {r.key: r.value for r in rows}
    return {
        "library_name": raw.get("library_name", "CampusSolve Central Library"),
        "institution_name": raw.get("institution_name", "Northbridge Institute of Technology"),
        "default_loan_days": int(float(raw.get("default_loan_days", "14"))),
        "daily_fine_rate": float(raw.get("daily_fine_rate", "2.50")),
        "warning_threshold_days": int(float(raw.get("warning_threshold_days", "3"))),
        "critical_overdue_days": int(float(raw.get("critical_overdue_days", "14"))),
        "default_borrow_limit": int(float(raw.get("default_borrow_limit", "5"))),
        "currency_symbol": raw.get("currency_symbol", "$"),
    }


def availability_status(available: int, total: int) -> str:
    if available <= 0:
        return "Out of Stock"
    if total > 0 and available <= max(1, total // 4):
        return "Low Stock"
    return "Available"


def serialize_book(book: BookModel, active_issues_count: Optional[int] = None) -> Dict[str, Any]:
    active_cnt = active_issues_count if active_issues_count is not None else max(0, book.total_copies - book.available_copies)
    return {
        "id": book.id,
        "isbn": book.isbn,
        "title": book.title,
        "author": book.author,
        "category": book.category,
        "publisher": book.publisher,
        "publication_year": book.publication_year,
        "shelf_location": book.shelf_location,
        "description": book.description or "",
        "cover_image": book.cover_image,
        "total_copies": book.total_copies,
        "available_copies": book.available_copies,
        "availability_status": availability_status(book.available_copies, book.total_copies),
        "active_issues_count": active_cnt,
        "created_at": book.created_at,
        "updated_at": book.updated_at,
    }


def serialize_member(
    member: MemberModel,
    active_count: int = 0,
    total_count: int = 0,
    overdue_count: int = 0,
) -> Dict[str, Any]:
    return {
        "id": member.id,
        "full_name": member.full_name,
        "email": member.email,
        "phone": member.phone,
        "department": member.department,
        "course": member.course,
        "member_type": member.member_type,
        "status": member.status,
        "max_borrow_limit": member.max_borrow_limit,
        "active_issues_count": active_count,
        "total_borrows_count": total_count,
        "overdue_count": overdue_count,
        "joined_at": member.joined_at,
        "updated_at": member.updated_at,
    }


def serialize_transaction(tx: TransactionModel, daily_fine_rate: float) -> Dict[str, Any]:
    days_overdue = (
        compute_overdue_days(tx.due_date, tx.return_date)
        if tx.return_date
        else compute_overdue_days(tx.due_date)
    )
    if tx.return_date:
        computed_status = "Returned"
        effective_fine = float(tx.fine_amount or 0.0)
    elif days_overdue > 0 or tx.status == "Overdue":
        computed_status = "Overdue"
        effective_fine = round(days_overdue * daily_fine_rate, 2) if days_overdue > 0 else float(tx.fine_amount or 0.0)
    else:
        computed_status = "Issued"
        effective_fine = float(tx.fine_amount or 0.0)

    return {
        "id": tx.id,
        "book_id": tx.book_id,
        "member_id": tx.member_id,
        "book_title": tx.book.title if tx.book else None,
        "book_isbn": tx.book.isbn if tx.book else None,
        "book_author": tx.book.author if tx.book else None,
        "book_category": tx.book.category if tx.book else None,
        "member_name": tx.member.full_name if tx.member else None,
        "member_email": tx.member.email if tx.member else None,
        "member_department": tx.member.department if tx.member else None,
        "issue_date": tx.issue_date,
        "due_date": tx.due_date,
        "return_date": tx.return_date,
        "status": computed_status,
        "days_overdue": days_overdue,
        "fine_amount": effective_fine,
        "notes": tx.notes or "",
        "created_at": tx.created_at,
        "updated_at": tx.updated_at,
    }


def to_csv(headers: List[str], rows: List[Dict[str, Any]]) -> str:
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(headers)
    for row in rows:
        writer.writerow([row.get(h, "") for h in headers])
    return buf.getvalue()


def _member_stats(db: Session) -> Dict[str, Dict[str, int]]:
    stats: Dict[str, Dict[str, int]] = {}
    today = today_str()
    for m_id, ret_date, due_date in db.query(
        TransactionModel.member_id, TransactionModel.return_date, TransactionModel.due_date
    ).all():
        entry = stats.setdefault(m_id, {"active": 0, "total": 0, "overdue": 0})
        entry["total"] += 1
        if ret_date is None:
            entry["active"] += 1
            if due_date < today:
                entry["overdue"] += 1
    return stats


# ---------------- BOOKS ----------------
def list_books(
    db: Session,
    *,
    search: Optional[str] = None,
    category: Optional[str] = None,
    availability: Optional[str] = None,
    sort_by: str = "created_at",
    sort_dir: str = "desc",
) -> List[Dict[str, Any]]:
    books = db.query(BookModel).order_by(BookModel.created_at.desc(), BookModel.id.asc()).all()
    active_counts: Dict[str, int] = {}
    for (b_id,) in db.query(TransactionModel.book_id).filter(TransactionModel.return_date.is_(None)).all():
        active_counts[b_id] = active_counts.get(b_id, 0) + 1

    result = [serialize_book(b, active_counts.get(b.id, 0)) for b in books]

    if search and search.strip():
        q = search.strip().lower()
        result = [
            b
            for b in result
            if q in b["id"].lower()
            or q in b["isbn"].lower()
            or q in b["title"].lower()
            or q in b["author"].lower()
            or q in b["publisher"].lower()
            or q in b["category"].lower()
            or q in b["description"].lower()
        ]
    if category and category != "All":
        result = [b for b in result if b["category"] == category]
    if availability and availability != "All":
        result = [b for b in result if b["availability_status"] == availability]

    if sort_by in ("id", "title", "author", "category", "publication_year", "total_copies", "available_copies", "created_at"):
        reverse = sort_dir.lower() == "desc"
        result.sort(key=lambda x: str(x.get(sort_by, "")).lower() if isinstance(x.get(sort_by), str) else x.get(sort_by, 0), reverse=reverse)

    return result


def get_book_detail(db: Session, book_id: str) -> Dict[str, Any]:
    clean_id = sanitize_text(book_id, 40).upper()
    book = db.query(BookModel).filter(BookModel.id == clean_id).first()
    if not book:
        raise ServiceError(f'Book "{book_id}" not found.', status_code=404)

    settings = get_settings_typed(db)
    tx_rows = (
        db.query(TransactionModel)
        .options(joinedload(TransactionModel.book), joinedload(TransactionModel.member))
        .filter(TransactionModel.book_id == clean_id)
        .order_by(TransactionModel.issue_date.desc(), TransactionModel.created_at.desc())
        .all()
    )
    active_cnt = sum(1 for t in tx_rows if t.return_date is None)
    return {
        "book": serialize_book(book, active_cnt),
        "transactions": [serialize_transaction(t, settings["daily_fine_rate"]) for t in tx_rows],
    }


def create_book(db: Session, payload: Dict[str, Any], actor: str = "Dr. Eleanor Vance") -> Dict[str, Any]:
    validated = validate_book_fields(payload, is_create=True)
    custom_id = validate_record_id(payload.get("id"), "Book ID")
    book_id = custom_id or next_id(db, BookModel, "BK", 1001)

    if db.query(BookModel).filter(BookModel.id == book_id).first():
        raise ServiceError(f'A book with ID "{book_id}" already exists.', status_code=409)
    if db.query(BookModel).filter(BookModel.isbn.ilike(validated["isbn"])).first():
        raise ServiceError(
            f'A book with ISBN "{validated["isbn"]}" already exists in the catalogue.',
            status_code=409,
        )

    ts = now_iso()
    book = BookModel(
        id=book_id,
        isbn=validated["isbn"],
        title=validated["title"],
        author=validated["author"],
        category=validated["category"],
        publisher=validated["publisher"],
        publication_year=validated["publication_year"],
        shelf_location=validated["shelf_location"],
        description=validated["description"],
        cover_image=validated["cover_image"],
        total_copies=validated["total_copies"],
        available_copies=validated["available_copies"],
        created_at=ts,
        updated_at=ts,
    )
    db.add(book)
    log_activity(
        db,
        "BOOK_ADDED",
        "Book",
        book_id,
        f'Added "{validated["title"]}" ({book_id}, ISBN {validated["isbn"]}) · {validated["total_copies"]} copies',
        actor=actor,
    )
    db.commit()
    db.refresh(book)
    sync_all_files(db)
    return serialize_book(book, max(0, validated["total_copies"] - validated["available_copies"]))


def update_book(db: Session, book_id: str, payload: Dict[str, Any], actor: str = "Dr. Eleanor Vance") -> Dict[str, Any]:
    clean_id = sanitize_text(book_id, 40).upper()
    book = db.query(BookModel).filter(BookModel.id == clean_id).first()
    if not book:
        raise ServiceError(f'Book "{book_id}" not found.', status_code=404)

    active_issues = (
        db.query(TransactionModel)
        .filter(TransactionModel.book_id == clean_id, TransactionModel.return_date.is_(None))
        .count()
    )
    validated = validate_book_fields(
        payload,
        is_create=False,
        existing_total=book.total_copies,
        existing_available=book.available_copies,
        active_issues=active_issues,
    )

    if "isbn" in validated:
        dup = db.query(BookModel).filter(BookModel.isbn.ilike(validated["isbn"]), BookModel.id != clean_id).first()
        if dup:
            raise ServiceError(f'Another book already uses ISBN "{validated["isbn"]}".', status_code=409)
        book.isbn = validated["isbn"]

    for field in (
        "title",
        "author",
        "category",
        "publisher",
        "publication_year",
        "shelf_location",
        "description",
        "cover_image",
        "total_copies",
        "available_copies",
    ):
        if field in validated:
            setattr(book, field, validated[field])

    book.updated_at = now_iso()
    log_activity(db, "BOOK_UPDATED", "Book", clean_id, f'Updated book "{book.title}" ({clean_id})', actor=actor)
    db.commit()
    db.refresh(book)
    sync_all_files(db)
    return serialize_book(book, active_issues)


def delete_book(db: Session, book_id: str, actor: str = "Dr. Eleanor Vance") -> Dict[str, Any]:
    clean_id = sanitize_text(book_id, 40).upper()
    book = db.query(BookModel).filter(BookModel.id == clean_id).first()
    if not book:
        raise ServiceError(f'Book "{book_id}" not found.', status_code=404)

    active_issues = (
        db.query(TransactionModel)
        .filter(TransactionModel.book_id == clean_id, TransactionModel.return_date.is_(None))
        .count()
    )
    if active_issues > 0:
        raise ServiceError(
            f'Cannot delete "{book.title}" because {active_issues} copy/copies are currently issued.',
            status_code=409,
        )

    total_tx = db.query(TransactionModel).filter(TransactionModel.book_id == clean_id).count()
    if total_tx > 0:
        raise ServiceError(
            f'Cannot delete "{book.title}" because it has {total_tx} historical audit transaction(s).',
            status_code=409,
        )

    title = book.title
    db.delete(book)
    log_activity(db, "BOOK_DELETED", "Book", clean_id, f'Deleted book "{title}" ({clean_id})', actor=actor)
    db.commit()
    sync_all_files(db)
    return {"deleted": True, "id": clean_id}


# ---------------- MEMBERS ----------------
def list_members(
    db: Session,
    *,
    search: Optional[str] = None,
    status: Optional[str] = None,
    department: Optional[str] = None,
    sort_by: str = "joined_at",
    sort_dir: str = "desc",
) -> List[Dict[str, Any]]:
    members = db.query(MemberModel).order_by(MemberModel.joined_at.desc()).all()
    stats = _member_stats(db)
    result = []
    for m in members:
        s = stats.get(m.id, {"active": 0, "total": 0, "overdue": 0})
        result.append(serialize_member(m, s["active"], s["total"], s["overdue"]))

    if search and search.strip():
        q = search.strip().lower()
        result = [
            m
            for m in result
            if q in m["id"].lower()
            or q in m["full_name"].lower()
            or q in m["email"].lower()
            or q in m["department"].lower()
            or q in m["course"].lower()
            or q in m["phone"].lower()
        ]
    if status and status != "All":
        result = [m for m in result if m["status"] == status]
    if department and department != "All":
        result = [m for m in result if m["department"] == department]

    if sort_by in ("id", "full_name", "email", "department", "status", "active_issues_count", "total_borrows_count", "joined_at"):
        reverse = sort_dir.lower() == "desc"
        result.sort(key=lambda x: str(x.get(sort_by, "")).lower() if isinstance(x.get(sort_by), str) else x.get(sort_by, 0), reverse=reverse)

    return result


def get_member_detail(db: Session, member_id: str) -> Dict[str, Any]:
    clean_id = sanitize_text(member_id, 40).upper()
    member = db.query(MemberModel).filter(MemberModel.id == clean_id).first()
    if not member:
        raise ServiceError(f'Member "{member_id}" not found.', status_code=404)

    settings = get_settings_typed(db)
    tx_rows = (
        db.query(TransactionModel)
        .options(joinedload(TransactionModel.book), joinedload(TransactionModel.member))
        .filter(TransactionModel.member_id == clean_id)
        .order_by(TransactionModel.issue_date.desc(), TransactionModel.created_at.desc())
        .all()
    )
    today = today_str()
    active_cnt = sum(1 for t in tx_rows if t.return_date is None)
    overdue_cnt = sum(1 for t in tx_rows if t.return_date is None and t.due_date < today)
    return {
        "member": serialize_member(member, active_cnt, len(tx_rows), overdue_cnt),
        "transactions": [serialize_transaction(t, settings["daily_fine_rate"]) for t in tx_rows],
    }


def create_member(db: Session, payload: Dict[str, Any], actor: str = "Dr. Eleanor Vance") -> Dict[str, Any]:
    validated = validate_member_fields(payload, is_create=True)
    custom_id = validate_record_id(payload.get("id"), "Member ID")
    member_id = custom_id or next_id(db, MemberModel, "MEM", 2001)

    if db.query(MemberModel).filter(MemberModel.id == member_id).first():
        raise ServiceError(f'A member with ID "{member_id}" already exists.', status_code=409)
    if db.query(MemberModel).filter(MemberModel.email.ilike(validated["email"])).first():
        raise ServiceError(f'A member with email "{validated["email"]}" is already registered.', status_code=409)

    ts = now_iso()
    member = MemberModel(
        id=member_id,
        full_name=validated["full_name"],
        email=validated["email"],
        phone=validated["phone"],
        department=validated["department"],
        course=validated["course"],
        member_type=validated["member_type"],
        status=validated["status"],
        max_borrow_limit=validated["max_borrow_limit"],
        joined_at=ts,
        updated_at=ts,
    )
    db.add(member)
    log_activity(
        db,
        "MEMBER_REGISTERED",
        "Member",
        member_id,
        f'Registered {validated["member_type"].lower()} "{validated["full_name"]}" ({member_id}) · {validated["department"]}',
        actor=actor,
    )
    db.commit()
    db.refresh(member)
    sync_all_files(db)
    return serialize_member(member, 0, 0, 0)


def update_member(db: Session, member_id: str, payload: Dict[str, Any], actor: str = "Dr. Eleanor Vance") -> Dict[str, Any]:
    clean_id = sanitize_text(member_id, 40).upper()
    member = db.query(MemberModel).filter(MemberModel.id == clean_id).first()
    if not member:
        raise ServiceError(f'Member "{member_id}" not found.', status_code=404)

    validated = validate_member_fields(payload, is_create=False)
    if "email" in validated:
        dup = db.query(MemberModel).filter(MemberModel.email.ilike(validated["email"]), MemberModel.id != clean_id).first()
        if dup:
            raise ServiceError(f'Another member already uses email "{validated["email"]}".', status_code=409)
        member.email = validated["email"]

    for field in ("full_name", "phone", "department", "course", "member_type", "status", "max_borrow_limit"):
        if field in validated:
            setattr(member, field, validated[field])

    member.updated_at = now_iso()
    log_activity(
        db,
        "MEMBER_UPDATED",
        "Member",
        clean_id,
        f'Updated member profile "{member.full_name}" ({clean_id})',
        actor=actor,
    )
    db.commit()
    db.refresh(member)
    sync_all_files(db)
    s = _member_stats(db).get(clean_id, {"active": 0, "total": 0, "overdue": 0})
    return serialize_member(member, s["active"], s["total"], s["overdue"])


def delete_member(db: Session, member_id: str, actor: str = "Dr. Eleanor Vance") -> Dict[str, Any]:
    clean_id = sanitize_text(member_id, 40).upper()
    member = db.query(MemberModel).filter(MemberModel.id == clean_id).first()
    if not member:
        raise ServiceError(f'Member "{member_id}" not found.', status_code=404)

    active_issues = (
        db.query(TransactionModel)
        .filter(TransactionModel.member_id == clean_id, TransactionModel.return_date.is_(None))
        .count()
    )
    if active_issues > 0:
        raise ServiceError(
            f'Cannot delete "{member.full_name}" with {active_issues} active unreturned book(s).',
            status_code=409,
        )

    total_tx = db.query(TransactionModel).filter(TransactionModel.member_id == clean_id).count()
    if total_tx > 0:
        raise ServiceError(
            f'Cannot delete "{member.full_name}" because {total_tx} historical loan record(s) reference this member.',
            status_code=409,
        )

    name = member.full_name
    db.delete(member)
    log_activity(db, "MEMBER_DELETED", "Member", clean_id, f'Deleted member "{name}" ({clean_id})', actor=actor)
    db.commit()
    sync_all_files(db)
    return {"deleted": True, "id": clean_id}


# ---------------- ISSUES & RETURNS ----------------
def list_active_issues(db: Session) -> List[Dict[str, Any]]:
    settings = get_settings_typed(db)
    rows = (
        db.query(TransactionModel)
        .options(joinedload(TransactionModel.book), joinedload(TransactionModel.member))
        .filter(TransactionModel.return_date.is_(None))
        .order_by(TransactionModel.due_date.asc())
        .all()
    )
    return [serialize_transaction(t, settings["daily_fine_rate"]) for t in rows]


def issue_book(db: Session, payload: Dict[str, Any], actor: str = "Dr. Eleanor Vance") -> Dict[str, Any]:
    member_id = sanitize_text(payload.get("member_id"), 40).upper()
    book_id = sanitize_text(payload.get("book_id"), 40).upper()
    issue_d, due_d = validate_issue_dates(payload.get("issue_date"), payload.get("due_date"))

    member = db.query(MemberModel).filter(MemberModel.id == member_id).first()
    if not member:
        raise ServiceError(f'Member ID "{member_id}" does not exist.', status_code=404)
    if member.status != "Active":
        raise ServiceError(
            f'Member "{member.full_name}" ({member_id}) is currently {member.status} and cannot borrow books.',
            status_code=422,
        )

    book = db.query(BookModel).filter(BookModel.id == book_id).first()
    if not book:
        raise ServiceError(f'Book ID "{book_id}" does not exist.', status_code=404)
    if book.available_copies <= 0:
        raise ServiceError(
            f'No available copies left for "{book.title}" ({book_id}). All {book.total_copies} copies are currently checked out.',
            status_code=422,
        )

    active_count = (
        db.query(TransactionModel)
        .filter(TransactionModel.member_id == member.id, TransactionModel.return_date.is_(None))
        .count()
    )
    if active_count >= member.max_borrow_limit:
        raise ServiceError(
            f'Member "{member.full_name}" has reached their maximum borrowing limit ({active_count}/{member.max_borrow_limit} active books).',
            status_code=422,
        )

    dup = (
        db.query(TransactionModel)
        .filter(
            TransactionModel.member_id == member.id,
            TransactionModel.book_id == book.id,
            TransactionModel.return_date.is_(None),
        )
        .first()
    )
    if dup:
        raise ServiceError(
            f'Duplicate active borrowing prevented: "{member.full_name}" already has "{book.title}" checked out (Transaction {dup.id}).',
            status_code=409,
        )

    txn_id = next_id(db, TransactionModel, "TXN", 3001)
    ts = now_iso()
    txn = TransactionModel(
        id=txn_id,
        book_id=book.id,
        member_id=member.id,
        issue_date=issue_d,
        due_date=due_d,
        return_date=None,
        status="Overdue" if due_d < today_str() else "Issued",
        fine_amount=0.0,
        notes=sanitize_text(payload.get("notes"), 300),
        created_at=ts,
        updated_at=ts,
    )
    book.available_copies -= 1
    book.updated_at = ts
    db.add(txn)
    log_activity(
        db,
        "BOOK_ISSUED",
        "Transaction",
        txn_id,
        f'Issued "{book.title}" ({book.id}) to {member.full_name} ({member.id}) · Due {due_d}',
        actor=actor,
    )
    db.commit()
    sync_all_files(db)

    created = (
        db.query(TransactionModel)
        .options(joinedload(TransactionModel.book), joinedload(TransactionModel.member))
        .filter(TransactionModel.id == txn_id)
        .first()
    )
    settings = get_settings_typed(db)
    return serialize_transaction(created, settings["daily_fine_rate"])


def list_recent_returns(db: Session, limit: int = 100) -> List[Dict[str, Any]]:
    settings = get_settings_typed(db)
    rows = (
        db.query(TransactionModel)
        .options(joinedload(TransactionModel.book), joinedload(TransactionModel.member))
        .filter(TransactionModel.return_date.isnot(None))
        .order_by(TransactionModel.return_date.desc(), TransactionModel.updated_at.desc())
        .limit(limit)
        .all()
    )
    return [serialize_transaction(t, settings["daily_fine_rate"]) for t in rows]


def return_book(db: Session, payload: Dict[str, Any], actor: str = "Dr. Eleanor Vance") -> Dict[str, Any]:
    txn_id = sanitize_text(payload.get("transaction_id"), 40).upper()
    ret_date = validate_iso_date(payload.get("return_date"), "Return date")
    waive_fine = bool(payload.get("waive_fine", False))
    notes = sanitize_text(payload.get("notes"), 300)

    txn = (
        db.query(TransactionModel)
        .options(joinedload(TransactionModel.book), joinedload(TransactionModel.member))
        .filter(TransactionModel.id == txn_id)
        .first()
    )
    if not txn:
        raise ServiceError(f'Transaction "{txn_id}" not found.', status_code=404)
    if txn.return_date is not None:
        raise ServiceError(f'Transaction "{txn_id}" was already returned on {txn.return_date}.', status_code=409)
    if ret_date < txn.issue_date:
        raise ServiceError(
            f"Return date ({ret_date}) cannot be earlier than issue date ({txn.issue_date}).",
            status_code=400,
        )

    settings = get_settings_typed(db)
    overdue_days = compute_overdue_days(txn.due_date, ret_date)
    fine = 0.0 if waive_fine else round(overdue_days * settings["daily_fine_rate"], 2)

    ts = now_iso()
    txn.return_date = ret_date
    txn.status = "Returned"
    txn.fine_amount = fine
    if notes:
        txn.notes = notes
    txn.updated_at = ts

    book = txn.book
    if book:
        book.available_copies = min(book.total_copies, book.available_copies + 1)
        book.updated_at = ts

    fine_msg = f" ({overdue_days}d overdue, fine {fine:.2f})" if fine > 0 else ""
    member_name = txn.member.full_name if txn.member else txn.member_id
    book_title = book.title if book else txn.book_id
    log_activity(
        db,
        "BOOK_RETURNED",
        "Transaction",
        txn.id,
        f'Returned "{book_title}" ({txn.book_id}) from {member_name} ({txn.member_id}){fine_msg}',
        actor=actor,
    )
    db.commit()
    db.refresh(txn)
    sync_all_files(db)
    return {
        "transaction": serialize_transaction(txn, settings["daily_fine_rate"]),
        "overdue_days": overdue_days,
        "fine_amount": fine,
    }


def list_transactions(
    db: Session,
    *,
    search: Optional[str] = None,
    status: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    sort_by: str = "issue_date",
    sort_dir: str = "desc",
) -> List[Dict[str, Any]]:
    settings = get_settings_typed(db)
    rows = (
        db.query(TransactionModel)
        .options(joinedload(TransactionModel.book), joinedload(TransactionModel.member))
        .order_by(TransactionModel.issue_date.desc(), TransactionModel.created_at.desc())
        .all()
    )
    txs = [serialize_transaction(t, settings["daily_fine_rate"]) for t in rows]

    if search and search.strip():
        q = search.strip().lower()
        txs = [
            t
            for t in txs
            if q in t["id"].lower()
            or q in t["book_id"].lower()
            or q in t["member_id"].lower()
            or q in (t["book_title"] or "").lower()
            or q in (t["member_name"] or "").lower()
            or q in (t["book_isbn"] or "").lower()
            or q in (t["book_author"] or "").lower()
        ]
    if status and status != "All":
        txs = [t for t in txs if t["status"] == status]
    if start_date and start_date.strip():
        s_clean = validate_iso_date(start_date, "Start date")
        txs = [t for t in txs if t["issue_date"] >= s_clean]
    if end_date and end_date.strip():
        e_clean = validate_iso_date(end_date, "End date")
        txs = [t for t in txs if t["issue_date"] <= e_clean]

    if sort_by in ("id", "issue_date", "due_date", "return_date", "status", "fine_amount", "days_overdue"):
        reverse = sort_dir.lower() == "desc"
        txs.sort(
            key=lambda x: (x.get(sort_by) or "") if not isinstance(x.get(sort_by), (int, float)) else x.get(sort_by, 0),
            reverse=reverse,
        )

    return txs


# ---------------- OVERDUE & THRESHOLD WARNINGS ----------------
def list_overdue(
    db: Session,
    *,
    min_days: int = 1,
    severity: Optional[str] = None,
    search: Optional[str] = None,
) -> Dict[str, Any]:
    settings = get_settings_typed(db)
    today = today_str()
    rows = (
        db.query(TransactionModel)
        .options(joinedload(TransactionModel.book), joinedload(TransactionModel.member))
        .filter(TransactionModel.return_date.is_(None), TransactionModel.due_date < today)
        .order_by(TransactionModel.due_date.asc())
        .all()
    )

    records = []
    for t in rows:
        base = serialize_transaction(t, settings["daily_fine_rate"])
        days = base["days_overdue"]
        if days < min_days:
            continue
        if days >= settings["critical_overdue_days"]:
            sev = "Critical"
        elif days > settings["warning_threshold_days"]:
            sev = "High"
        else:
            sev = "Warning"
        records.append(
            {
                **base,
                "severity": sev,
                "estimated_fine": base["fine_amount"],
                "member_phone": t.member.phone if t.member else None,
            }
        )

    if severity and severity != "All":
        records = [r for r in records if r["severity"] == severity]
    if search and search.strip():
        q = search.strip().lower()
        records = [
            r
            for r in records
            if q in r["id"].lower()
            or q in (r["book_title"] or "").lower()
            or q in (r["member_name"] or "").lower()
            or q in (r["member_department"] or "").lower()
        ]

    total_fines = round(sum(r["estimated_fine"] for r in records), 2)
    critical_count = sum(1 for r in records if r["severity"] == "Critical")
    return {
        "records": records,
        "summary": {
            "totalOverdue": len(records),
            "criticalCount": critical_count,
            "totalFines": total_fines,
            "dailyFineRate": settings["daily_fine_rate"],
            "warningThresholdDays": settings["warning_threshold_days"],
            "criticalOverdueDays": settings["critical_overdue_days"],
        },
    }


def compute_warnings(db: Session) -> Dict[str, Any]:
    settings = get_settings_typed(db)
    today = date.today()
    today_iso = today.isoformat()
    warn_cutoff = (today + timedelta(days=settings["warning_threshold_days"])).isoformat()

    overdue_data = list_overdue(db, min_days=1)

    # Approaching due dates (0..warning_threshold_days from today)
    active_txs = (
        db.query(TransactionModel)
        .options(joinedload(TransactionModel.book), joinedload(TransactionModel.member))
        .filter(
            TransactionModel.return_date.is_(None),
            TransactionModel.due_date >= today_iso,
            TransactionModel.due_date <= warn_cutoff,
        )
        .order_by(TransactionModel.due_date.asc())
        .all()
    )
    approaching_due = []
    for t in active_txs:
        days_left = (date.fromisoformat(t.due_date) - today).days
        serialized = serialize_transaction(t, settings["daily_fine_rate"])
        approaching_due.append({**serialized, "days_remaining": days_left})

    # Books: unavailable & anomalous quantities
    books = db.query(BookModel).all()
    active_per_book: Dict[str, int] = defaultdict(int)
    for (b_id,) in db.query(TransactionModel.book_id).filter(TransactionModel.return_date.is_(None)).all():
        active_per_book[b_id] += 1

    unavailable_books = []
    low_stock_books = []
    anomalous_quantities = []
    for b in books:
        active_cnt = active_per_book.get(b.id, 0)
        sb = serialize_book(b, active_cnt)
        if b.available_copies < 0 or b.total_copies < 0 or b.available_copies > b.total_copies or active_cnt > b.total_copies:
            anomalous_quantities.append(
                {
                    **sb,
                    "anomaly": f"total={b.total_copies}, available={b.available_copies}, active_loans={active_cnt}",
                }
            )
        elif b.available_copies == 0:
            unavailable_books.append(sb)
        elif sb["availability_status"] == "Low Stock":
            low_stock_books.append(sb)

    # Members at or above borrowing limit
    stats = _member_stats(db)
    borrow_limit_breaches = []
    for m in db.query(MemberModel).all():
        s = stats.get(m.id, {"active": 0, "total": 0, "overdue": 0})
        if s["active"] >= m.max_borrow_limit:
            borrow_limit_breaches.append(serialize_member(m, s["active"], s["total"], s["overdue"]))

    total_alerts = (
        len(overdue_data["records"])
        + len(approaching_due)
        + len(unavailable_books)
        + len(anomalous_quantities)
        + len(borrow_limit_breaches)
    )

    return {
        "thresholds": {
            "warning_threshold_days": settings["warning_threshold_days"],
            "critical_overdue_days": settings["critical_overdue_days"],
            "daily_fine_rate": settings["daily_fine_rate"],
        },
        "totalAlerts": total_alerts,
        "overdue": overdue_data["records"],
        "approachingDue": approaching_due,
        "unavailableBooks": unavailable_books,
        "lowStockBooks": low_stock_books,
        "anomalousQuantities": anomalous_quantities,
        "borrowLimitBreaches": borrow_limit_breaches,
    }


# ---------------- UNIFIED RECORD SEARCH ----------------
def search_records(
    db: Session,
    *,
    query: Optional[str] = None,
    scope: str = "all",
    category: Optional[str] = None,
    status: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    sort_by: str = "relevance",
    sort_dir: str = "asc",
    page: int = 1,
    page_size: int = 20,
) -> Dict[str, Any]:
    books = (
        list_books(db, search=query, category=category, availability=status if status in ("Available", "Low Stock", "Out of Stock") else None)
        if scope in ("all", "books")
        else []
    )
    members = (
        list_members(db, search=query, status=status if status in ("Active", "Suspended", "Inactive") else None)
        if scope in ("all", "members")
        else []
    )
    tx_status = status if status in ("Issued", "Returned", "Overdue") else None
    transactions = (
        list_transactions(db, search=query, status=tx_status, start_date=start_date, end_date=end_date)
        if scope in ("all", "transactions")
        else []
    )

    if start_date and start_date.strip():
        s_clean = validate_iso_date(start_date, "Start date")
        if scope in ("all", "books") and books:
            books = [b for b in books if b["created_at"][:10] >= s_clean]
        if scope in ("all", "members") and members:
            members = [m for m in members if m["joined_at"][:10] >= s_clean]
    if end_date and end_date.strip():
        e_clean = validate_iso_date(end_date, "End date")
        if scope in ("all", "books") and books:
            books = [b for b in books if b["created_at"][:10] <= e_clean]
        if scope in ("all", "members") and members:
            members = [m for m in members if m["joined_at"][:10] <= e_clean]

    reverse = sort_dir.lower() == "desc"
    if sort_by == "title":
        books.sort(key=lambda b: b["title"].lower(), reverse=reverse)
        members.sort(key=lambda m: m["full_name"].lower(), reverse=reverse)
        transactions.sort(key=lambda t: (t["book_title"] or "").lower(), reverse=reverse)
    elif sort_by == "date":
        books.sort(key=lambda b: b["created_at"], reverse=reverse)
        members.sort(key=lambda m: m["joined_at"], reverse=reverse)
        transactions.sort(key=lambda t: t["issue_date"], reverse=reverse)
    elif sort_by == "id":
        books.sort(key=lambda b: b["id"], reverse=reverse)
        members.sort(key=lambda m: m["id"], reverse=reverse)
        transactions.sort(key=lambda t: t["id"], reverse=reverse)

    total_matches = len(books) + len(members) + len(transactions)
    safe_page = max(1, page)
    safe_size = max(1, min(100, page_size))

    return {
        "query": query or "",
        "scope": scope,
        "counts": {
            "total": total_matches,
            "books": len(books),
            "members": len(members),
            "transactions": len(transactions),
        },
        "page": safe_page,
        "pageSize": safe_size,
        "books": books,
        "members": members,
        "transactions": transactions,
    }


# ---------------- ANALYTICS & EXECUTIVE SUMMARY ----------------
def build_analytics(db: Session, range_val: str = "6m", category_filter: str = "All") -> Dict[str, Any]:
    settings = get_settings_typed(db)
    book_query = db.query(BookModel)
    if category_filter and category_filter != "All":
        book_query = book_query.filter(BookModel.category == category_filter)
    books = book_query.all()

    total_members = db.query(MemberModel).count()
    active_members_count = db.query(MemberModel).filter(MemberModel.status == "Active").count()

    tx_query = db.query(TransactionModel).options(
        joinedload(TransactionModel.book), joinedload(TransactionModel.member)
    )
    if category_filter and category_filter != "All":
        tx_query = tx_query.join(BookModel).filter(BookModel.category == category_filter)

    days_map = {"30d": 30, "90d": 90, "6m": 185, "1y": 365}
    if range_val in days_map:
        cutoff = (date.today() - timedelta(days=days_map[range_val])).isoformat()
        tx_query = tx_query.filter(TransactionModel.issue_date >= cutoff)

    tx_rows = tx_query.all()
    txs = [serialize_transaction(t, settings["daily_fine_rate"]) for t in tx_rows]

    total_books = len(books)
    total_copies = sum(b.total_copies for b in books)
    available_copies = sum(b.available_copies for b in books)
    issued_books = sum(max(0, b.total_copies - b.available_copies) for b in books)
    active_tx = [t for t in txs if t["status"] != "Returned"]
    returned_tx = [t for t in txs if t["status"] == "Returned"]
    overdue_tx = [t for t in txs if t["status"] == "Overdue"]
    utilization_rate = round((issued_books / total_copies) * 100, 1) if total_copies > 0 else 0.0
    total_fines = round(sum(t["fine_amount"] for t in overdue_tx), 2)

    # Monthly buckets (always 6 recent months or all spanned months)
    now_dt = datetime.now(timezone.utc)
    month_buckets = []
    for i in range(5, -1, -1):
        year = now_dt.year
        month = now_dt.month - i
        while month <= 0:
            month += 12
            year -= 1
        d = date(year, month, 1)
        ym = d.strftime("%Y-%m")
        label = d.strftime("%b %y")
        month_buckets.append({"month": ym, "label": label, "issued": 0, "returned": 0, "overdue": 0})
    bucket_map = {b["month"]: b for b in month_buckets}

    active_months = set()
    for t in txs:
        ym_issue = t["issue_date"][:7]
        active_months.add(ym_issue)
        if ym_issue in bucket_map:
            bucket_map[ym_issue]["issued"] += 1
            if t["status"] == "Overdue":
                bucket_map[ym_issue]["overdue"] += 1
        if t["return_date"]:
            ym_ret = t["return_date"][:7]
            if ym_ret in bucket_map:
                bucket_map[ym_ret]["returned"] += 1

    months_divisor = max(len(month_buckets), len(active_months), 1)
    avg_issued_per_month = round(len(txs) / months_divisor, 2) if txs else 0.0

    availability_dist = [
        {"name": "Available Copies", "value": available_copies, "color": "#10D9A0"},
        {"name": "Issued (On-Time)", "value": max(0, len(active_tx) - len(overdue_tx)), "color": "#4388FF"},
        {"name": "Overdue Copies", "value": len(overdue_tx), "color": "#FF6485"},
    ]

    cat_agg: Dict[str, Dict[str, Any]] = {}
    for b in books:
        entry = cat_agg.setdefault(
            b.category,
            {"category": b.category, "titles": 0, "totalCopies": 0, "availableCopies": 0, "borrowCount": 0},
        )
        entry["titles"] += 1
        entry["totalCopies"] += b.total_copies
        entry["availableCopies"] += b.available_copies
    for t in txs:
        cat = t["book_category"] or "Other"
        if cat in cat_agg:
            cat_agg[cat]["borrowCount"] += 1
    category_distribution = sorted(cat_agg.values(), key=lambda x: x["borrowCount"], reverse=True)

    book_borrows: Dict[str, int] = {}
    for t in txs:
        book_borrows[t["book_id"]] = book_borrows.get(t["book_id"], 0) + 1
    top_books = sorted(
        [
            {
                "id": b.id,
                "title": b.title,
                "author": b.author,
                "category": b.category,
                "borrowCount": book_borrows.get(b.id, 0),
                "availableCopies": b.available_copies,
                "totalCopies": b.total_copies,
            }
            for b in books
        ],
        key=lambda x: x["borrowCount"],
        reverse=True,
    )[:7]

    all_members = db.query(MemberModel).all()
    m_tx_map: Dict[str, Dict[str, int]] = {}
    for t in txs:
        cur = m_tx_map.setdefault(t["member_id"], {"total": 0, "active": 0, "overdue": 0})
        cur["total"] += 1
        if t["status"] != "Returned":
            cur["active"] += 1
        if t["status"] == "Overdue":
            cur["overdue"] += 1
    active_members = sorted(
        [
            {
                "id": m.id,
                "full_name": m.full_name,
                "department": m.department,
                "member_type": m.member_type,
                "totalBorrows": m_tx_map.get(m.id, {}).get("total", 0),
                "activeIssues": m_tx_map.get(m.id, {}).get("active", 0),
                "overdueCount": m_tx_map.get(m.id, {}).get("overdue", 0),
            }
            for m in all_members
        ],
        key=lambda x: (x["totalBorrows"], x["activeIssues"]),
        reverse=True,
    )[:8]

    overdue_buckets = [
        {"bucket": "1–3 Days", "count": 0, "totalFine": 0.0},
        {"bucket": "4–7 Days", "count": 0, "totalFine": 0.0},
        {"bucket": "8–14 Days", "count": 0, "totalFine": 0.0},
        {"bucket": "15+ Days", "count": 0, "totalFine": 0.0},
    ]
    for t in overdue_tx:
        d = t["days_overdue"]
        idx = 0 if d <= 3 else 1 if d <= 7 else 2 if d <= 14 else 3
        overdue_buckets[idx]["count"] += 1
        overdue_buckets[idx]["totalFine"] = round(overdue_buckets[idx]["totalFine"] + t["fine_amount"], 2)

    growth_buckets = [
        {"month": b["month"], "label": b["label"], "newMembers": 0, "cumulativeMembers": 0}
        for b in month_buckets
    ]
    growth_map = {g["month"]: g for g in growth_buckets}
    first_month = growth_buckets[0]["month"] if growth_buckets else ""
    base_count = 0
    for m in all_members:
        ym = m.joined_at[:7]
        if ym < first_month:
            base_count += 1
        elif ym in growth_map:
            growth_map[ym]["newMembers"] += 1
    running = base_count
    for g in growth_buckets:
        running += g["newMembers"]
        g["cumulativeMembers"] = running

    return {
        "kpis": {
            "totalBooks": total_books,
            "totalCopies": total_copies,
            "availableCopies": available_copies,
            "issuedBooks": issued_books,
            "totalMembers": total_members,
            "activeMembers": active_members_count,
            "overdueBooks": len(overdue_tx),
            "totalTransactions": len(txs),
            "totalReturns": len(returned_tx),
            "avgBooksIssuedPerMonth": avg_issued_per_month,
            "utilizationRate": utilization_rate,
            "totalFinesOutstanding": total_fines,
        },
        "monthlyTrends": month_buckets,
        "availabilityDistribution": availability_dist,
        "categoryDistribution": category_distribution,
        "topBooks": top_books,
        "activeMembers": active_members,
        "overdueBreakdown": overdue_buckets,
        "membershipGrowth": growth_buckets,
    }


# ---------------- REPORTS ----------------
def generate_report(
    db: Session,
    *,
    report_type: str = "executive",
    fmt: str = "json",
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    actor: str = "Dr. Eleanor Vance",
) -> Dict[str, Any]:
    settings = get_settings_typed(db)
    fmt_clean = fmt.lower()
    if fmt_clean not in ("json", "csv", "markdown", "txt"):
        raise ServiceError('Report format must be "json", "csv", "markdown", or "txt".', status_code=400)

    if start_date and start_date.strip():
        start_date = validate_iso_date(start_date, "Start date")
    else:
        start_date = None
    if end_date and end_date.strip():
        end_date = validate_iso_date(end_date, "End date")
    else:
        end_date = None
    if start_date and end_date and end_date < start_date:
        raise ServiceError("End date cannot be earlier than start date.", status_code=400)

    generated_at = now_iso()
    title = "CampusSolve Executive Summary Report"
    rows: List[Dict[str, Any]] = []
    summary_metrics: Dict[str, Any] = {}

    if report_type == "inventory":
        title = "Book Inventory Report"
        books = db.query(BookModel).order_by(BookModel.category, BookModel.title).all()
        rows = [
            {
                "id": b.id,
                "isbn": b.isbn,
                "title": b.title,
                "author": b.author,
                "category": b.category,
                "publisher": b.publisher,
                "year": b.publication_year,
                "shelf_location": b.shelf_location,
                "total_copies": b.total_copies,
                "available_copies": b.available_copies,
                "status": availability_status(b.available_copies, b.total_copies),
            }
            for b in books
        ]
        summary_metrics = {
            "total_titles": len(books),
            "total_copies": sum(b.total_copies for b in books),
            "available_copies": sum(b.available_copies for b in books),
            "out_of_stock_titles": sum(1 for b in books if b.available_copies == 0),
        }
    elif report_type == "members":
        title = "Library Membership Report"
        members = db.query(MemberModel).order_by(MemberModel.department, MemberModel.full_name).all()
        stats = _member_stats(db)
        rows = [
            {
                "id": m.id,
                "full_name": m.full_name,
                "email": m.email,
                "department": m.department,
                "course": m.course,
                "member_type": m.member_type,
                "status": m.status,
                "active_issues": stats.get(m.id, {}).get("active", 0),
                "total_borrows": stats.get(m.id, {}).get("total", 0),
                "max_borrow_limit": m.max_borrow_limit,
            }
            for m in members
        ]
        summary_metrics = {
            "total_members": len(rows),
            "active_members": sum(1 for r in rows if r["status"] == "Active"),
            "suspended_members": sum(1 for r in rows if r["status"] == "Suspended"),
        }
    elif report_type == "audit":
        title = "System Audit Log Report"
        logs = db.query(ActivityLogModel).order_by(ActivityLogModel.created_at.desc(), ActivityLogModel.id.desc()).limit(250).all()
        filtered_logs = []
        for a in logs:
            day = a.created_at[:10]
            if start_date and day < start_date:
                continue
            if end_date and day > end_date:
                continue
            filtered_logs.append(a)
        rows = [
            {
                "log_id": a.id,
                "timestamp": a.created_at,
                "action_type": a.action_type,
                "entity_type": a.entity_type,
                "entity_id": a.entity_id,
                "actor": a.actor,
                "summary": a.summary,
            }
            for a in filtered_logs
        ]
        summary_metrics = {
            "total_events": len(rows),
            "distinct_actions": len({r["action_type"] for r in rows}),
        }
    elif report_type in ("issues", "returns", "overdue", "transactions"):
        title_map = {
            "issues": "Active Book Issues Report",
            "returns": "Completed Book Returns Report",
            "overdue": "Overdue Monitoring & Fine Assessment Report",
            "transactions": "Full Circulation Transactions Report",
        }
        title = title_map[report_type]
        tx_rows = (
            db.query(TransactionModel)
            .options(joinedload(TransactionModel.book), joinedload(TransactionModel.member))
            .order_by(TransactionModel.issue_date.desc())
            .all()
        )
        all_tx = [serialize_transaction(t, settings["daily_fine_rate"]) for t in tx_rows]
        filtered = []
        for t in all_tx:
            if start_date and t["issue_date"] < start_date:
                continue
            if end_date and t["issue_date"] > end_date:
                continue
            if report_type == "issues" and t["return_date"] is not None:
                continue
            if report_type == "returns" and t["return_date"] is None:
                continue
            if report_type == "overdue" and t["status"] != "Overdue":
                continue
            filtered.append(t)
        rows = [
            {
                "transaction_id": t["id"],
                "book_id": t["book_id"],
                "book_title": t["book_title"],
                "member_id": t["member_id"],
                "member_name": t["member_name"],
                "department": t["member_department"],
                "issue_date": t["issue_date"],
                "due_date": t["due_date"],
                "return_date": t["return_date"] or "Active",
                "status": t["status"],
                "days_overdue": t["days_overdue"],
                "fine_amount": t["fine_amount"],
            }
            for t in filtered
        ]
        summary_metrics = {
            "total_records": len(rows),
            "total_fines": round(sum(t["fine_amount"] for t in filtered), 2),
            "overdue_records": sum(1 for t in filtered if t["status"] == "Overdue"),
        }
    else:
        analytics = build_analytics(db, "all", "All")
        summary_metrics = dict(analytics["kpis"])
        rows = [
            {
                "category": c["category"],
                "unique_titles": c["titles"],
                "total_copies": c["totalCopies"],
                "available_copies": c["availableCopies"],
                "total_borrows": c["borrowCount"],
            }
            for c in analytics["categoryDistribution"]
        ]

    log_activity(db, "REPORT_GENERATED", "Report", report_type.upper(), f"Generated {title} ({fmt_clean.upper()})", actor=actor)
    db.commit()

    period_label = f"{start_date or 'Beginning'} to {end_date or 'Present'}" if (start_date or end_date) else "All Time"

    if fmt_clean == "csv":
        headers = list(rows[0].keys()) if rows else list(summary_metrics.keys())
        content = to_csv(headers, rows if rows else [summary_metrics])
    elif fmt_clean == "markdown":
        lines = [
            f"# {title}",
            f"**Institution:** {settings['institution_name']} · **Library:** {settings['library_name']}",
            f"**Generated:** {generated_at} · **Period:** {period_label}",
            "",
            "## Summary Metrics",
            *[f"- **{k.replace('_', ' ')}:** {v}" for k, v in summary_metrics.items()],
            "",
        ]
        if rows:
            cols = list(rows[0].keys())
            lines.extend(["## Detailed Records", "", f"| {' | '.join(cols)} |", f"| {' | '.join(['---'] * len(cols))} |"])
            for r in rows:
                lines.append(f"| {' | '.join(str(r.get(c, '')) for c in cols)} |")
        content = "\n".join(lines)
    elif fmt_clean == "txt":
        lines = [
            "====================================================================",
            f"CAMPUSSOLVE — {title.upper()}",
            f"Institution: {settings['institution_name']}",
            f"Library: {settings['library_name']}",
            f"Generated: {generated_at} | Period: {period_label}",
            "====================================================================",
            "",
            "SUMMARY METRICS:",
            *[f"  - {k.replace('_', ' ')}: {v}" for k, v in summary_metrics.items()],
            "",
            f"RECORDS ({len(rows)}):",
            *[f"  [{i + 1}] " + " | ".join(f"{k}={v}" for k, v in r.items()) for i, r in enumerate(rows)],
        ]
        content = "\n".join(lines)
    else:
        payload = {
            "title": title,
            "reportType": report_type,
            "format": "json",
            "generatedAt": generated_at,
            "periodLabel": period_label,
            "institution": settings["institution_name"],
            "library": settings["library_name"],
            "summaryMetrics": summary_metrics,
            "rows": rows,
        }
        content = json.dumps(payload, indent=2)

    return {
        "title": title,
        "reportType": report_type,
        "format": fmt_clean,
        "generatedAt": generated_at,
        "periodLabel": period_label,
        "institution": settings["institution_name"],
        "library": settings["library_name"],
        "summaryMetrics": summary_metrics,
        "rows": rows,
        "content": content,
    }


# ---------------- IMPORT & EXPORT ----------------
def validate_import(db: Session, entity: str, fmt: str, content: str) -> Dict[str, Any]:
    if not content or not content.strip():
        raise ServiceError("File content is empty.", status_code=400)

    raw_rows: List[Dict[str, Any]] = []
    if fmt == "json":
        try:
            parsed = json.loads(content)
        except json.JSONDecodeError as exc:
            raise ServiceError("Invalid JSON syntax in uploaded payload.", status_code=400) from exc
        if not isinstance(parsed, list):
            raise ServiceError("JSON import must contain a top-level array of records.", status_code=400)
        raw_rows = [item if isinstance(item, dict) else {} for item in parsed]
        if not raw_rows:
            raise ServiceError("JSON array contains zero records.", status_code=400)
    else:
        reader = csv.DictReader(io.StringIO(content))
        if not reader.fieldnames:
            raise ServiceError("CSV file must include a header row and at least one data row.", status_code=400)
        clean_headers = [str(h).strip().lower().replace(" ", "_") for h in reader.fieldnames if h is not None]
        if entity == "books":
            if not any(c in clean_headers for c in ("title", "book_title")) or "isbn" not in clean_headers:
                raise ServiceError(
                    "CSV header missing required book columns (must include 'isbn' and 'title').",
                    status_code=400,
                )
        else:
            if not any(c in clean_headers for c in ("full_name", "name")) or "email" not in clean_headers:
                raise ServiceError(
                    "CSV header missing required member columns (must include 'full_name' and 'email').",
                    status_code=400,
                )
        for r in reader:
            normalized_raw = {
                str(k).strip().lower().replace(" ", "_"): (v.strip() if isinstance(v, str) else v)
                for k, v in r.items()
                if k is not None
            }
            if any(str(val).strip() for val in normalized_raw.values()):
                raw_rows.append(normalized_raw)
        if not raw_rows:
            raise ServiceError("CSV file must include at least one data row.", status_code=400)

    detected_columns = list(dict.fromkeys(k for r in raw_rows for k in r.keys()))
    existing_isbns = {b[0].lower() for b in db.query(BookModel.isbn).all()}
    existing_book_ids = {b[0].upper() for b in db.query(BookModel.id).all()}
    existing_emails = {m[0].lower() for m in db.query(MemberModel.email).all()}
    existing_member_ids = {m[0].upper() for m in db.query(MemberModel.id).all()}
    seen_batch = set()
    seen_ids = set()
    rows_out = []

    for idx, raw in enumerate(raw_rows, start=1):
        errors: List[str] = []
        is_duplicate = False
        if entity == "books":
            custom_id = sanitize_text(raw.get("id") or raw.get("book_id"), 30).upper()
            isbn_raw = sanitize_text(raw.get("isbn") or raw.get("ISBN"), 40)
            title = sanitize_text(raw.get("title") or raw.get("book_title"), 200)
            author = sanitize_text(raw.get("author"), 150)
            category = sanitize_text(raw.get("category") or "Computer Science", 80) or "Computer Science"
            publisher = sanitize_text(raw.get("publisher") or "Academic Press", 120) or "Academic Press"
            shelf = sanitize_text(raw.get("shelf_location") or raw.get("shelf") or "GEN-A1", 40) or "GEN-A1"
            description = sanitize_text(raw.get("description"), 500)

            try:
                year_num = int(raw.get("publication_year") or raw.get("year") or 2022)
            except (TypeError, ValueError):
                year_num = -1
            try:
                total_raw = raw.get("total_copies") if raw.get("total_copies") not in (None, "") else raw.get("copies")
                total_copies = int(total_raw) if total_raw not in (None, "") else 1
            except (TypeError, ValueError):
                total_copies = -999
            try:
                avail_raw = raw.get("available_copies")
                avail_copies = int(avail_raw) if avail_raw not in (None, "") else total_copies
            except (TypeError, ValueError):
                avail_copies = -999

            try:
                isbn = validate_isbn(isbn_raw, required=True)
            except ServiceError:
                isbn = isbn_raw
                errors.append("Missing or invalid ISBN (must be 10 or 13 digits)")

            if not title:
                errors.append("Missing book title")
            if not author:
                errors.append("Missing author name")
            if year_num < 1450 or year_num > 2030:
                errors.append("Invalid publication year (1450–2030)")
            if total_copies < 0:
                errors.append("Total copies must be an integer >= 0")
            if avail_copies < 0 or (total_copies >= 0 and avail_copies > total_copies):
                errors.append("Available copies must be between 0 and total copies")

            if custom_id and (custom_id in existing_book_ids or custom_id in seen_ids):
                is_duplicate = True
                errors.append(f"Duplicate Book ID ({custom_id})")
            if custom_id:
                seen_ids.add(custom_id)

            key = isbn.lower()
            if key and (key in existing_isbns or key in seen_batch):
                is_duplicate = True
                errors.append(f"Duplicate ISBN ({isbn})")
            if key:
                seen_batch.add(key)

            normalized = {
                "id": custom_id or None,
                "isbn": isbn,
                "title": title,
                "author": author,
                "category": category,
                "publisher": publisher,
                "publication_year": year_num if 1450 <= year_num <= 2030 else 2022,
                "shelf_location": shelf,
                "description": description,
                "total_copies": total_copies if total_copies >= 0 else 1,
                "available_copies": avail_copies if avail_copies >= 0 else 1,
            }
        else:
            custom_id = sanitize_text(raw.get("id") or raw.get("member_id"), 30).upper()
            full_name = sanitize_text(raw.get("full_name") or raw.get("name"), 120)
            email = sanitize_text(raw.get("email"), 150).lower()
            phone = sanitize_text(raw.get("phone") or "+1 (555) 000-0000", 40) or "+1 (555) 000-0000"
            department = sanitize_text(raw.get("department"), 100)
            course = sanitize_text(raw.get("course") or "General Studies", 120) or "General Studies"
            raw_type = sanitize_text(raw.get("member_type") or raw.get("type") or "Student", 40)
            member_type = raw_type if raw_type in ("Student", "Faculty", "Researcher", "Staff") else "Student"
            raw_status = sanitize_text(raw.get("status") or "Active", 40)
            status = raw_status if raw_status in ("Active", "Suspended", "Inactive") else "Active"
            try:
                max_limit = int(raw.get("max_borrow_limit") or 5)
            except (TypeError, ValueError):
                max_limit = -1

            if len(full_name) < 2:
                errors.append("Missing or invalid full_name")
            try:
                email = validate_email(email)
            except ServiceError:
                errors.append("Invalid email address")
            if not department:
                errors.append("Missing department")
            if max_limit < 1 or max_limit > 20:
                errors.append("max_borrow_limit must be 1–20")

            if custom_id and (custom_id in existing_member_ids or custom_id in seen_ids):
                is_duplicate = True
                errors.append(f"Duplicate Member ID ({custom_id})")
            if custom_id:
                seen_ids.add(custom_id)

            if email and (email in existing_emails or email in seen_batch):
                is_duplicate = True
                errors.append(f"Duplicate email ({email})")
            if email:
                seen_batch.add(email)

            normalized = {
                "id": custom_id or None,
                "full_name": full_name,
                "email": email,
                "phone": phone,
                "department": department,
                "course": course,
                "member_type": member_type,
                "status": status,
                "max_borrow_limit": max_limit if 1 <= max_limit <= 20 else 5,
            }

        rows_out.append(
            {
                "rowNumber": idx,
                "raw": raw,
                "valid": len(errors) == 0,
                "isDuplicate": is_duplicate,
                "errors": errors,
                "normalized": normalized,
            }
        )

    valid_rows = sum(1 for r in rows_out if r["valid"])
    dup_rows = sum(1 for r in rows_out if r["isDuplicate"])
    return {
        "entity": entity,
        "format": fmt,
        "totalRows": len(rows_out),
        "validRows": valid_rows,
        "duplicateRows": dup_rows,
        "invalidRows": len(rows_out) - valid_rows,
        "detectedColumns": detected_columns,
        "rows": rows_out,
    }


def commit_import(db: Session, entity: str, fmt: str, content: str, actor: str = "Dr. Eleanor Vance") -> Dict[str, Any]:
    preview = validate_import(db, entity, fmt, content)
    valid_rows = [r for r in preview["rows"] if r["valid"]]
    if not valid_rows:
        raise ServiceError("No valid non-duplicate rows found to import.", status_code=400)

    ts = now_iso()
    imported_count = 0
    if entity == "books":
        next_num = int(next_id(db, BookModel, "BK", 1001).split("-")[-1])
        for row in valid_rows:
            n = row["normalized"]
            if n.get("id"):
                rec_id = n["id"]
            else:
                rec_id = f"BK-{next_num}"
                next_num += 1
            db.add(
                BookModel(
                    id=rec_id,
                    isbn=n["isbn"],
                    title=n["title"],
                    author=n["author"],
                    category=n["category"],
                    publisher=n["publisher"],
                    publication_year=n["publication_year"],
                    shelf_location=n["shelf_location"],
                    description=n["description"],
                    cover_image=None,
                    total_copies=n["total_copies"],
                    available_copies=n["available_copies"],
                    created_at=ts,
                    updated_at=ts,
                )
            )
            imported_count += 1
    else:
        next_num = int(next_id(db, MemberModel, "MEM", 2001).split("-")[-1])
        for row in valid_rows:
            n = row["normalized"]
            if n.get("id"):
                rec_id = n["id"]
            else:
                rec_id = f"MEM-{next_num}"
                next_num += 1
            db.add(
                MemberModel(
                    id=rec_id,
                    full_name=n["full_name"],
                    email=n["email"],
                    phone=n["phone"],
                    department=n["department"],
                    course=n["course"],
                    member_type=n["member_type"],
                    status=n["status"],
                    max_borrow_limit=n["max_borrow_limit"],
                    joined_at=ts,
                    updated_at=ts,
                )
            )
            imported_count += 1

    log_activity(
        db,
        "DATA_IMPORTED",
        "Book" if entity == "books" else "Member",
        "BATCH",
        f"Imported {imported_count} {entity} record(s) via {fmt.upper()} ({preview['invalidRows']} skipped)",
        actor=actor,
    )
    db.commit()
    sync_all_files(db)
    return {
        "importedCount": imported_count,
        "skippedCount": preview["invalidRows"],
        "preview": preview,
    }


def export_data(db: Session, entity: str = "books", fmt: str = "csv") -> Dict[str, Any]:
    settings = get_settings_typed(db)
    fmt_clean = fmt.lower()
    records: List[Dict[str, Any]] = []

    if entity == "books":
        books = db.query(BookModel).order_by(BookModel.id.asc()).all()
        records = [
            {
                "id": b.id,
                "isbn": b.isbn,
                "title": b.title,
                "author": b.author,
                "category": b.category,
                "publisher": b.publisher,
                "publication_year": b.publication_year,
                "shelf_location": b.shelf_location,
                "total_copies": b.total_copies,
                "available_copies": b.available_copies,
                "availability_status": availability_status(b.available_copies, b.total_copies),
            }
            for b in books
        ]
    elif entity == "members":
        members = db.query(MemberModel).order_by(MemberModel.id.asc()).all()
        records = [
            {
                "id": m.id,
                "full_name": m.full_name,
                "email": m.email,
                "phone": m.phone,
                "department": m.department,
                "course": m.course,
                "member_type": m.member_type,
                "status": m.status,
                "max_borrow_limit": m.max_borrow_limit,
                "joined_at": m.joined_at,
            }
            for m in members
        ]
    elif entity == "overdue":
        today = today_str()
        rows = (
            db.query(TransactionModel)
            .options(joinedload(TransactionModel.book), joinedload(TransactionModel.member))
            .filter(TransactionModel.return_date.is_(None), TransactionModel.due_date < today)
            .all()
        )
        for r in rows:
            t = serialize_transaction(r, settings["daily_fine_rate"])
            records.append(
                {
                    "transaction_id": t["id"],
                    "book_id": t["book_id"],
                    "book_title": t["book_title"],
                    "member_id": t["member_id"],
                    "member_name": t["member_name"],
                    "member_email": t["member_email"],
                    "issue_date": t["issue_date"],
                    "due_date": t["due_date"],
                    "days_overdue": t["days_overdue"],
                    "fine_amount": t["fine_amount"],
                }
            )
    else:
        rows = (
            db.query(TransactionModel)
            .options(joinedload(TransactionModel.book), joinedload(TransactionModel.member))
            .order_by(TransactionModel.issue_date.desc())
            .all()
        )
        for r in rows:
            t = serialize_transaction(r, settings["daily_fine_rate"])
            records.append(
                {
                    "id": t["id"],
                    "book_id": t["book_id"],
                    "book_title": t["book_title"],
                    "member_id": t["member_id"],
                    "member_name": t["member_name"],
                    "issue_date": t["issue_date"],
                    "due_date": t["due_date"],
                    "return_date": t["return_date"] or "",
                    "status": t["status"],
                    "days_overdue": t["days_overdue"],
                    "fine_amount": t["fine_amount"],
                }
            )

    if fmt_clean == "json":
        return {"entity": entity, "format": "json", "count": len(records), "content": json.dumps(records, indent=2)}

    headers = list(records[0].keys()) if records else ["empty"]
    return {"entity": entity, "format": "csv", "count": len(records), "content": to_csv(headers, records)}


def update_settings(db: Session, payload: Dict[str, Any], actor: str = "Dr. Eleanor Vance") -> Dict[str, Any]:
    for key, val in payload.items():
        row = db.query(SettingModel).filter(SettingModel.key == key).first()
        str_val = f"{float(val):.2f}" if key == "daily_fine_rate" else str(val)
        if row:
            row.value = str_val
        else:
            db.add(SettingModel(key=key, value=str_val))
    log_activity(db, "SETTINGS_UPDATED", "Settings", "SYSTEM", "Updated library circulation policies & overdue thresholds", actor=actor)
    db.commit()
    return get_settings_typed(db)


def build_backup_payload(db: Session, actor: str = "Dr. Eleanor Vance") -> Dict[str, Any]:
    settings = get_settings_typed(db)
    books = [serialize_book(b) for b in db.query(BookModel).all()]
    members = [serialize_member(m) for m in db.query(MemberModel).all()]
    txs = [
        serialize_transaction(t, settings["daily_fine_rate"])
        for t in db.query(TransactionModel)
        .options(joinedload(TransactionModel.book), joinedload(TransactionModel.member))
        .all()
    ]
    logs = [
        {
            "id": a.id,
            "action_type": a.action_type,
            "entity_type": a.entity_type,
            "entity_id": a.entity_id,
            "summary": a.summary,
            "actor": a.actor,
            "created_at": a.created_at,
        }
        for a in db.query(ActivityLogModel).order_by(ActivityLogModel.id.desc()).limit(500).all()
    ]
    log_activity(db, "BACKUP_EXPORTED", "System", "DB", "Exported full SQLite database snapshot", actor=actor)
    db.commit()
    return {
        "exported_at": now_iso(),
        "schema_version": "2.0",
        "settings": settings,
        "books": books,
        "members": members,
        "transactions": txs,
        "activity_logs": logs,
    }


def list_activity(
    db: Session,
    *,
    action_type: Optional[str] = None,
    search: Optional[str] = None,
    limit: int = 60,
) -> List[Dict[str, Any]]:
    rows = (
        db.query(ActivityLogModel)
        .order_by(ActivityLogModel.created_at.desc(), ActivityLogModel.id.desc())
        .limit(limit)
        .all()
    )
    items = [
        {
            "id": r.id,
            "action_type": r.action_type,
            "entity_type": r.entity_type,
            "entity_id": r.entity_id,
            "summary": r.summary,
            "actor": r.actor,
            "created_at": r.created_at,
        }
        for r in rows
    ]
    if action_type and action_type != "All":
        items = [i for i in items if i["action_type"] == action_type]
    if search and search.strip():
        q = search.strip().lower()
        items = [
            i
            for i in items
            if q in i["summary"].lower()
            or q in i["entity_id"].lower()
            or q in i["action_type"].lower()
        ]
    return items


# ---------------- URGENT MEMBER REQUESTS & REAL-TIME NOTIFICATIONS ----------------
def serialize_member_request(req: MemberRequestModel) -> Dict[str, Any]:
    return {
        "id": req.id,
        "member_id": req.member_id,
        "member_name": req.member.full_name if req.member else req.member_id,
        "member_email": req.member.email if req.member else None,
        "member_department": req.member.department if req.member else None,
        "book_id": req.book_id,
        "book_title": req.book.title if req.book else None,
        "request_type": req.request_type,
        "urgency": req.urgency,
        "title": req.title,
        "notes": req.notes or "",
        "status": req.status,
        "created_at": req.created_at,
        "updated_at": req.updated_at,
    }


def list_member_requests(
    db: Session,
    *,
    status: Optional[str] = None,
    urgency: Optional[str] = None,
) -> List[Dict[str, Any]]:
    rows = (
        db.query(MemberRequestModel)
        .options(joinedload(MemberRequestModel.member), joinedload(MemberRequestModel.book))
        .order_by(MemberRequestModel.created_at.desc(), MemberRequestModel.id.desc())
        .all()
    )
    items = [serialize_member_request(r) for r in rows]
    if status and status != "All":
        items = [r for r in items if r["status"] == status]
    if urgency and urgency != "All":
        items = [r for r in items if r["urgency"] == urgency]
    return items


def create_member_request(
    db: Session,
    payload: Dict[str, Any],
    actor: str = "Dr. Eleanor Vance",
) -> Dict[str, Any]:
    member_id = sanitize_text(payload.get("member_id"), 40).upper()
    member = db.query(MemberModel).filter(MemberModel.id == member_id).first()
    if not member:
        raise ServiceError(f'Member "{member_id}" not found.', status_code=404)

    book_id_raw = payload.get("book_id")
    book_id: Optional[str] = None
    book_title: Optional[str] = None
    if book_id_raw and str(book_id_raw).strip():
        book_id = sanitize_text(book_id_raw, 40).upper()
        book = db.query(BookModel).filter(BookModel.id == book_id).first()
        if not book:
            raise ServiceError(f'Book "{book_id}" not found.', status_code=404)
        book_title = book.title

    req_type = sanitize_text(payload.get("request_type") or "Urgent Hold", 40)
    urgency = sanitize_text(payload.get("urgency") or "Urgent", 20)
    title = sanitize_text(payload.get("title"), 160)
    notes = sanitize_text(payload.get("notes"), 500)
    if not title:
        raise ServiceError("Request title is required.", status_code=400)

    req_id = next_id(db, MemberRequestModel, "REQ", 4001)
    ts = now_iso()
    record = MemberRequestModel(
        id=req_id,
        member_id=member.id,
        book_id=book_id,
        request_type=req_type,
        urgency=urgency,
        title=title,
        notes=notes,
        status="Pending",
        created_at=ts,
        updated_at=ts,
    )
    db.add(record)
    book_ctx = f' for "{book_title}"' if book_title else ""
    log_activity(
        db,
        "MEMBER_REQUEST_CREATED",
        "MemberRequest",
        req_id,
        f'{urgency} {req_type} from {member.full_name} ({member.id}){book_ctx}: {title}',
        actor=actor,
    )
    db.commit()

    created = (
        db.query(MemberRequestModel)
        .options(joinedload(MemberRequestModel.member), joinedload(MemberRequestModel.book))
        .filter(MemberRequestModel.id == req_id)
        .first()
    )
    return serialize_member_request(created)


def update_member_request(
    db: Session,
    request_id: str,
    payload: Dict[str, Any],
    actor: str = "Dr. Eleanor Vance",
) -> Dict[str, Any]:
    clean_id = sanitize_text(request_id, 40).upper()
    record = (
        db.query(MemberRequestModel)
        .options(joinedload(MemberRequestModel.member), joinedload(MemberRequestModel.book))
        .filter(MemberRequestModel.id == clean_id)
        .first()
    )
    if not record:
        raise ServiceError(f'Member request "{request_id}" not found.', status_code=404)

    if payload.get("status"):
        record.status = sanitize_text(payload["status"], 30)
    if payload.get("urgency"):
        record.urgency = sanitize_text(payload["urgency"], 20)
    if payload.get("notes") is not None:
        record.notes = sanitize_text(payload["notes"], 500)
    record.updated_at = now_iso()

    # Keep matching notification state aligned when request is resolved
    notif_id = f"req-{record.id}"
    state = db.query(NotificationStateModel).filter(NotificationStateModel.notification_id == notif_id).first()
    if record.status in ("Approved", "Dismissed"):
        if state:
            state.is_read = 1
            state.is_dismissed = 1
            state.acknowledged_at = record.updated_at
            state.updated_at = record.updated_at
        else:
            db.add(
                NotificationStateModel(
                    notification_id=notif_id,
                    is_read=1,
                    is_dismissed=1,
                    acknowledged_at=record.updated_at,
                    updated_at=record.updated_at,
                )
            )

    log_activity(
        db,
        "MEMBER_REQUEST_UPDATED",
        "MemberRequest",
        clean_id,
        f'Updated member request {clean_id} ({record.title}) -> {record.status}',
        actor=actor,
    )
    db.commit()
    db.refresh(record)
    return serialize_member_request(record)


def _format_due_countdown(days_remaining: int) -> str:
    if days_remaining <= 0:
        return "Due today"
    if days_remaining == 1:
        return "Due tomorrow"
    return f"Due in {days_remaining} days"


def build_notifications_payload(db: Session) -> Dict[str, Any]:
    warnings = compute_warnings(db)
    states = {
        s.notification_id: s
        for s in db.query(NotificationStateModel).all()
    }

    pending_requests = (
        db.query(MemberRequestModel)
        .options(joinedload(MemberRequestModel.member), joinedload(MemberRequestModel.book))
        .filter(MemberRequestModel.status.in_(["Pending", "In Review"]))
        .order_by(MemberRequestModel.created_at.desc())
        .all()
    )

    raw_items: List[Dict[str, Any]] = []

    # 1. Urgent & Pending Member Requests
    for req in pending_requests:
        sev = "critical" if req.urgency == "Critical" else ("high" if req.urgency == "Urgent" else "info")
        member_name = req.member.full_name if req.member else req.member_id
        book_title = req.book.title if req.book else None
        raw_items.append(
            {
                "id": f"req-{req.id}",
                "category": "urgent_request",
                "severity": sev,
                "title": f"{req.urgency} {req.request_type}: {req.title}",
                "message": req.notes or f"Submitted by {member_name}",
                "entity_type": "MemberRequest",
                "entity_id": req.id,
                "book_id": req.book_id,
                "book_title": book_title,
                "member_id": req.member_id,
                "member_name": member_name,
                "due_date": None,
                "days_remaining": None,
                "request_type": req.request_type,
                "request_status": req.status,
                "action_url": f"/members/{req.member_id}",
                "created_at": req.created_at,
            }
        )

    # 2. Upcoming Book Due Dates (within threshold_days)
    for ap in warnings["approachingDue"]:
        days_rem = int(ap.get("days_remaining", 0))
        sev = "critical" if days_rem == 0 else ("high" if days_rem == 1 else "warning")
        countdown = _format_due_countdown(days_rem)
        raw_items.append(
            {
                "id": f"due-{ap['id']}",
                "category": "due_soon",
                "severity": sev,
                "title": f"{countdown}: {ap.get('book_title') or ap['book_id']}",
                "message": f"Borrowed by {ap.get('member_name') or ap['member_id']} · Due {ap['due_date']}",
                "entity_type": "Transaction",
                "entity_id": ap["id"],
                "book_id": ap["book_id"],
                "book_title": ap.get("book_title"),
                "member_id": ap["member_id"],
                "member_name": ap.get("member_name"),
                "due_date": ap["due_date"],
                "days_remaining": days_rem,
                "request_type": None,
                "request_status": None,
                "action_url": "/return",
                "created_at": ap.get("updated_at") or ap.get("created_at") or now_iso(),
            }
        )

    # 3. Overdue Book Alerts
    for ov in warnings["overdue"]:
        sev = "critical" if ov.get("severity") == "Critical" else ("high" if ov.get("severity") == "High" else "warning")
        raw_items.append(
            {
                "id": f"overdue-{ov['id']}",
                "category": "overdue",
                "severity": sev,
                "title": f"Overdue ({ov['days_overdue']}d late): {ov.get('book_title') or ov['book_id']}",
                "message": f"Borrower: {ov.get('member_name') or ov['member_id']} · Accrued fine ${float(ov.get('estimated_fine', 0.0)):.2f}",
                "entity_type": "Transaction",
                "entity_id": ov["id"],
                "book_id": ov["book_id"],
                "book_title": ov.get("book_title"),
                "member_id": ov["member_id"],
                "member_name": ov.get("member_name"),
                "due_date": ov["due_date"],
                "days_remaining": -int(ov["days_overdue"]),
                "request_type": None,
                "request_status": None,
                "action_url": "/overdue",
                "created_at": ov.get("updated_at") or ov.get("created_at") or now_iso(),
            }
        )

    # 4. Out-of-Stock / Low-Stock Book Alerts
    for bk in (warnings["unavailableBooks"] + warnings["lowStockBooks"])[:4]:
        is_oos = bk["available_copies"] == 0
        raw_items.append(
            {
                "id": f"stock-{bk['id']}",
                "category": "inventory",
                "severity": "high" if is_oos else "warning",
                "title": f"{'Out of Stock' if is_oos else 'Low Stock'}: {bk['title']}",
                "message": f"{bk['available_copies']} of {bk['total_copies']} copies available on shelf {bk['shelf_location']}",
                "entity_type": "Book",
                "entity_id": bk["id"],
                "book_id": bk["id"],
                "book_title": bk["title"],
                "member_id": None,
                "member_name": None,
                "due_date": None,
                "days_remaining": None,
                "request_type": None,
                "request_status": None,
                "action_url": f"/books/{bk['id']}",
                "created_at": bk.get("updated_at") or now_iso(),
            }
        )

    # 5. Borrow Limit Reached Alerts
    for mem in warnings["borrowLimitBreaches"][:3]:
        raw_items.append(
            {
                "id": f"limit-{mem['id']}",
                "category": "member_limit",
                "severity": "info",
                "title": f"Borrow Limit Reached: {mem['full_name']}",
                "message": f"{mem['active_issues_count']}/{mem['max_borrow_limit']} active loans ({mem['department']})",
                "entity_type": "Member",
                "entity_id": mem["id"],
                "book_id": None,
                "book_title": None,
                "member_id": mem["id"],
                "member_name": mem["full_name"],
                "due_date": None,
                "days_remaining": None,
                "request_type": None,
                "request_status": None,
                "action_url": f"/members/{mem['id']}",
                "created_at": mem.get("updated_at") or now_iso(),
            }
        )

    notifications: List[Dict[str, Any]] = []
    for item in raw_items:
        st = states.get(item["id"])
        is_dismissed = bool(st and st.is_dismissed)
        if is_dismissed:
            continue
        is_read = bool(st and st.is_read)
        notifications.append({**item, "is_read": is_read, "is_dismissed": False})

    sev_rank = {"critical": 0, "high": 1, "warning": 2, "info": 3}
    cat_rank = {"urgent_request": 0, "due_soon": 1, "overdue": 2, "inventory": 3, "member_limit": 4}
    notifications.sort(
        key=lambda n: (
            1 if n["is_read"] else 0,
            sev_rank.get(n["severity"], 9),
            cat_rank.get(n["category"], 9),
            n["created_at"],
        )
    )

    unread_count = sum(1 for n in notifications if not n["is_read"])
    urgent_req_count = sum(1 for n in notifications if n["category"] == "urgent_request")
    due_soon_count = sum(1 for n in notifications if n["category"] == "due_soon")
    overdue_count = sum(1 for n in notifications if n["category"] == "overdue")

    return {
        "notifications": notifications,
        "totalCount": len(notifications),
        "unreadCount": unread_count,
        "urgentRequestCount": urgent_req_count,
        "dueSoonCount": due_soon_count,
        "overdueCount": overdue_count,
        "warningThresholdDays": warnings["thresholds"]["warning_threshold_days"],
        "generatedAt": now_iso(),
    }


def mark_notification_state(
    db: Session,
    notification_id: str,
    *,
    is_read: Optional[bool] = None,
    is_dismissed: Optional[bool] = None,
) -> Dict[str, Any]:
    clean_id = sanitize_text(notification_id, 80)
    if not clean_id:
        raise ServiceError("Notification ID is required.", status_code=400)
    ts = now_iso()
    st = db.query(NotificationStateModel).filter(NotificationStateModel.notification_id == clean_id).first()
    if not st:
        st = NotificationStateModel(
            notification_id=clean_id,
            is_read=1 if is_read else 0,
            is_dismissed=1 if is_dismissed else 0,
            acknowledged_at=ts if (is_read or is_dismissed) else None,
            updated_at=ts,
        )
        db.add(st)
    else:
        if is_read is not None:
            st.is_read = 1 if is_read else 0
        if is_dismissed is not None:
            st.is_dismissed = 1 if is_dismissed else 0
        if is_read or is_dismissed:
            st.acknowledged_at = ts
        st.updated_at = ts
    db.commit()
    return build_notifications_payload(db)


def mark_all_notifications_read(db: Session) -> Dict[str, Any]:
    current = build_notifications_payload(db)
    ts = now_iso()
    for n in current["notifications"]:
        nid = n["id"]
        st = db.query(NotificationStateModel).filter(NotificationStateModel.notification_id == nid).first()
        if not st:
            db.add(
                NotificationStateModel(
                    notification_id=nid,
                    is_read=1,
                    is_dismissed=0,
                    acknowledged_at=ts,
                    updated_at=ts,
                )
            )
        elif not st.is_read:
            st.is_read = 1
            st.acknowledged_at = ts
            st.updated_at = ts
    db.commit()
    return build_notifications_payload(db)

