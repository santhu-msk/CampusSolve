import re
from datetime import date
from typing import Any, Dict, Optional, Tuple


class ServiceError(Exception):
    def __init__(self, message: str, status_code: int = 400, details: Any = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.details = details


class SyncError(ServiceError):
    def __init__(self, message: str, details: Any = None):
        super().__init__(message, status_code=500, details=details)


VALID_BOOK_CATEGORIES = (
    "Computer Science",
    "Natural Sciences",
    "Mathematics",
    "Humanities & Arts",
    "Economics & Law",
    "Engineering",
    "General",
)

VALID_MEMBER_TYPES = ("Student", "Faculty", "Researcher", "Staff")
VALID_MEMBER_STATUSES = ("Active", "Suspended", "Inactive")

_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{1,29}$")
_EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]{2,}$")


def sanitize_text(val: Any, max_len: int = 400) -> str:
    if val is None:
        return ""
    return re.sub(r"\s+", " ", str(val).strip())[:max_len]


def validate_record_id(record_id: Optional[str], label: str = "ID") -> Optional[str]:
    if record_id is None:
        return None
    cleaned = sanitize_text(record_id, 30).upper()
    if not cleaned:
        return None
    if not _ID_RE.match(cleaned):
        raise ServiceError(
            f'{label} "{record_id}" is invalid. Use 2–30 alphanumeric characters, hyphens, or underscores.',
            status_code=400,
        )
    return cleaned


def validate_isbn(isbn: Any, required: bool = True) -> str:
    cleaned = sanitize_text(isbn, 40)
    if not cleaned:
        if required:
            raise ServiceError("ISBN is required.", status_code=400)
        return ""

    compact = re.sub(r"[-\s]", "", cleaned).upper()
    is_isbn10 = bool(re.match(r"^\d{9}[\dX]$", compact))
    is_isbn13 = bool(re.match(r"^(978|979)\d{10}$", compact))
    is_legacy_13 = bool(re.match(r"^\d{13}$", compact))
    if not (is_isbn10 or is_isbn13 or is_legacy_13):
        raise ServiceError(
            f'Invalid ISBN "{cleaned}". Provide a valid 10-digit or 13-digit ISBN (e.g. 978-0262046305).',
            status_code=400,
        )
    return cleaned


def validate_email(email: Any) -> str:
    cleaned = sanitize_text(email, 150).lower()
    if not cleaned or not _EMAIL_RE.match(cleaned):
        raise ServiceError(f'Invalid email address "{email}".', status_code=400)
    return cleaned


def validate_phone(phone: Any) -> str:
    cleaned = sanitize_text(phone, 40)
    digits = re.sub(r"\D", "", cleaned)
    if len(digits) < 7 or len(digits) > 15 or not re.match(r"^[+\d\s().-]+$", cleaned):
        raise ServiceError(
            f'Invalid phone number "{phone}". Include 7–15 digits.',
            status_code=400,
        )
    return cleaned


def validate_iso_date(date_str: Any, field_name: str = "Date") -> str:
    cleaned = sanitize_text(date_str, 20)
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", cleaned):
        raise ServiceError(f"{field_name} must use YYYY-MM-DD format.", status_code=400)
    try:
        date.fromisoformat(cleaned)
    except ValueError as exc:
        raise ServiceError(f"{field_name} ({cleaned}) is not a valid calendar date.", status_code=400) from exc
    return cleaned


def compute_overdue_days(due_date_str: str, ref_date_str: Optional[str] = None) -> int:
    try:
        due = date.fromisoformat(due_date_str)
        ref = date.fromisoformat(ref_date_str) if ref_date_str else date.today()
        return max(0, (ref - due).days)
    except ValueError:
        return 0


def validate_book_fields(
    data: Dict[str, Any],
    *,
    is_create: bool = True,
    existing_total: Optional[int] = None,
    existing_available: Optional[int] = None,
    active_issues: int = 0,
) -> Dict[str, Any]:
    out: Dict[str, Any] = {}

    if is_create or "isbn" in data:
        out["isbn"] = validate_isbn(data.get("isbn"), required=True)

    if is_create or "title" in data:
        title = sanitize_text(data.get("title"), 200)
        if not title:
            raise ServiceError("Book title cannot be empty.", status_code=400)
        out["title"] = title

    if is_create or "author" in data:
        author = sanitize_text(data.get("author"), 150)
        if not author:
            raise ServiceError("Author name cannot be empty.", status_code=400)
        out["author"] = author

    if is_create or "category" in data:
        category = sanitize_text(data.get("category"), 80)
        if not category:
            raise ServiceError("Book category cannot be empty.", status_code=400)
        out["category"] = category

    if is_create or "publisher" in data:
        publisher = sanitize_text(data.get("publisher"), 120)
        if not publisher:
            raise ServiceError("Publisher name cannot be empty.", status_code=400)
        out["publisher"] = publisher

    if is_create or "publication_year" in data:
        try:
            year = int(data.get("publication_year"))  # type: ignore[arg-type]
        except (TypeError, ValueError) as exc:
            raise ServiceError("Publication year must be a valid integer.", status_code=400) from exc
        if year < 1450 or year > 2030:
            raise ServiceError("Publication year must be between 1450 and 2030.", status_code=400)
        out["publication_year"] = year

    if is_create or "shelf_location" in data:
        out["shelf_location"] = sanitize_text(data.get("shelf_location"), 40) or "GEN-A1-01"

    if is_create or "description" in data:
        out["description"] = sanitize_text(data.get("description"), 1000)

    if is_create or "cover_image" in data:
        cover = sanitize_text(data.get("cover_image"), 300)
        out["cover_image"] = cover or None

    raw_total = data.get("total_copies", existing_total)
    if raw_total is None:
        raise ServiceError("Total copies is required.", status_code=400)
    try:
        total_copies = int(raw_total)
    except (TypeError, ValueError) as exc:
        raise ServiceError("Total copies must be an integer.", status_code=400) from exc
    if total_copies < 0 or total_copies > 500:
        raise ServiceError("Total copies must be between 0 and 500.", status_code=400)
    if total_copies < active_issues:
        raise ServiceError(
            f"Total copies ({total_copies}) cannot be less than currently issued copies ({active_issues}).",
            status_code=400,
        )

    if "available_copies" in data and data["available_copies"] is not None:
        try:
            avail_copies = int(data["available_copies"])
        except (TypeError, ValueError) as exc:
            raise ServiceError("Available copies must be an integer.", status_code=400) from exc
    elif is_create:
        avail_copies = total_copies
    elif "total_copies" in data:
        avail_copies = max(0, total_copies - active_issues)
    else:
        avail_copies = existing_available if existing_available is not None else total_copies

    if avail_copies < 0:
        raise ServiceError("Available copies cannot be negative.", status_code=400)
    if avail_copies > total_copies:
        raise ServiceError("Available copies cannot exceed total copies.", status_code=400)

    out["total_copies"] = total_copies
    out["available_copies"] = avail_copies
    return out


def validate_member_fields(data: Dict[str, Any], *, is_create: bool = True) -> Dict[str, Any]:
    out: Dict[str, Any] = {}

    if is_create or "full_name" in data:
        name = sanitize_text(data.get("full_name"), 120)
        if len(name) < 2:
            raise ServiceError("Member full name must be at least 2 characters.", status_code=400)
        out["full_name"] = name

    if is_create or "email" in data:
        out["email"] = validate_email(data.get("email"))

    if is_create or "phone" in data:
        out["phone"] = validate_phone(data.get("phone"))

    if is_create or "department" in data:
        dept = sanitize_text(data.get("department"), 100)
        if not dept:
            raise ServiceError("Department is required.", status_code=400)
        out["department"] = dept

    if is_create or "course" in data:
        course = sanitize_text(data.get("course"), 120)
        if not course:
            raise ServiceError("Course / program is required.", status_code=400)
        out["course"] = course

    if is_create or "member_type" in data:
        m_type = sanitize_text(data.get("member_type") or "Student", 40)
        if m_type not in VALID_MEMBER_TYPES:
            raise ServiceError(
                f'Member type "{m_type}" is invalid. Choose from: {", ".join(VALID_MEMBER_TYPES)}.',
                status_code=400,
            )
        out["member_type"] = m_type

    if is_create or "status" in data:
        status = sanitize_text(data.get("status") or "Active", 40)
        if status not in VALID_MEMBER_STATUSES:
            raise ServiceError(
                f'Member status "{status}" is invalid. Choose from: {", ".join(VALID_MEMBER_STATUSES)}.',
                status_code=400,
            )
        out["status"] = status

    if is_create or "max_borrow_limit" in data:
        raw_lim = data.get("max_borrow_limit", 5)
        try:
            limit = int(raw_lim)
        except (TypeError, ValueError) as exc:
            raise ServiceError("Borrow limit must be an integer.", status_code=400) from exc
        if limit < 1 or limit > 20:
            raise ServiceError("Borrow limit must be between 1 and 20.", status_code=400)
        out["max_borrow_limit"] = limit

    return out


def validate_issue_dates(issue_date: Any, due_date: Any) -> Tuple[str, str]:
    iss = validate_iso_date(issue_date, "Issue date")
    due = validate_iso_date(due_date, "Due date")
    if due < iss:
        raise ServiceError("Due date cannot be earlier than the issue date.", status_code=400)
    return iss, due
