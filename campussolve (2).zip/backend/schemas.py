from typing import Any, Literal, Optional
from pydantic import BaseModel, EmailStr, Field, field_validator


class BookCreate(BaseModel):
    id: Optional[str] = Field(default=None, max_length=30)
    isbn: str = Field(..., min_length=5, max_length=40)
    title: str = Field(..., min_length=1, max_length=200)
    author: str = Field(..., min_length=1, max_length=150)
    category: str = Field(..., min_length=1, max_length=80)
    publisher: str = Field(..., min_length=1, max_length=120)
    publication_year: int = Field(..., ge=1450, le=2030)
    shelf_location: str = Field(default="GEN-A1-01", max_length=40)
    description: str = Field(default="", max_length=1000)
    cover_image: Optional[str] = Field(default=None, max_length=300)
    total_copies: int = Field(..., ge=0, le=500)
    available_copies: Optional[int] = Field(default=None, ge=0, le=500)


class BookUpdate(BaseModel):
    isbn: Optional[str] = Field(default=None, min_length=5, max_length=40)
    title: Optional[str] = Field(default=None, min_length=1, max_length=200)
    author: Optional[str] = Field(default=None, min_length=1, max_length=150)
    category: Optional[str] = Field(default=None, min_length=1, max_length=80)
    publisher: Optional[str] = Field(default=None, min_length=1, max_length=120)
    publication_year: Optional[int] = Field(default=None, ge=1450, le=2030)
    shelf_location: Optional[str] = Field(default=None, max_length=40)
    description: Optional[str] = Field(default=None, max_length=1000)
    cover_image: Optional[str] = Field(default=None, max_length=300)
    total_copies: Optional[int] = Field(default=None, ge=0, le=500)
    available_copies: Optional[int] = Field(default=None, ge=0, le=500)


class MemberCreate(BaseModel):
    id: Optional[str] = Field(default=None, max_length=30)
    full_name: str = Field(..., min_length=1, max_length=120)
    email: EmailStr
    phone: str = Field(..., min_length=5, max_length=40)
    department: str = Field(..., min_length=1, max_length=100)
    course: str = Field(..., min_length=1, max_length=120)
    member_type: Literal["Student", "Faculty", "Researcher", "Staff"] = "Student"
    status: Literal["Active", "Suspended", "Inactive"] = "Active"
    max_borrow_limit: int = Field(default=5, ge=1, le=20)


class MemberUpdate(BaseModel):
    full_name: Optional[str] = Field(default=None, min_length=1, max_length=120)
    email: Optional[EmailStr] = None
    phone: Optional[str] = Field(default=None, min_length=5, max_length=40)
    department: Optional[str] = Field(default=None, min_length=1, max_length=100)
    course: Optional[str] = Field(default=None, min_length=1, max_length=120)
    member_type: Optional[Literal["Student", "Faculty", "Researcher", "Staff"]] = None
    status: Optional[Literal["Active", "Suspended", "Inactive"]] = None
    max_borrow_limit: Optional[int] = Field(default=None, ge=1, le=20)


class IssueCreate(BaseModel):
    book_id: str = Field(..., min_length=2, max_length=40)
    member_id: str = Field(..., min_length=2, max_length=40)
    issue_date: str = Field(..., pattern=r"^\d{4}-\d{2}-\d{2}$")
    due_date: str = Field(..., pattern=r"^\d{4}-\d{2}-\d{2}$")
    notes: str = Field(default="", max_length=300)

    @field_validator("due_date")
    @classmethod
    def check_due_after_issue(cls, v, info):
        issue = info.data.get("issue_date")
        if issue and v < issue:
            raise ValueError("Due date cannot be earlier than the issue date.")
        return v


class ReturnCreate(BaseModel):
    transaction_id: str = Field(..., min_length=2, max_length=40)
    return_date: str = Field(..., pattern=r"^\d{4}-\d{2}-\d{2}$")
    waive_fine: bool = False
    notes: str = Field(default="", max_length=300)


class SettingsUpdate(BaseModel):
    library_name: str = Field(..., min_length=2, max_length=120)
    institution_name: str = Field(..., min_length=2, max_length=150)
    default_loan_days: int = Field(..., ge=1, le=180)
    daily_fine_rate: float = Field(..., ge=0.0, le=100.0)
    warning_threshold_days: int = Field(..., ge=1, le=90)
    critical_overdue_days: int = Field(..., ge=1, le=365)
    default_borrow_limit: int = Field(..., ge=1, le=20)
    currency_symbol: str = Field(default="$", min_length=1, max_length=5)

    @field_validator("critical_overdue_days")
    @classmethod
    def check_critical_ge_warning(cls, v, info):
        warn = info.data.get("warning_threshold_days")
        if warn is not None and v < warn:
            raise ValueError("Critical overdue threshold must be >= warning threshold.")
        return v


class ImportRequest(BaseModel):
    entity: Literal["books", "members"] = "books"
    format: Literal["csv", "json"] = "csv"
    content: str = Field(..., min_length=1)


class MemberRequestCreate(BaseModel):
    member_id: str = Field(..., min_length=2, max_length=40)
    book_id: Optional[str] = Field(default=None, max_length=40)
    request_type: Literal["Urgent Hold", "Loan Extension", "Course Reserve", "Replacement"] = "Urgent Hold"
    urgency: Literal["Critical", "Urgent", "Normal"] = "Urgent"
    title: str = Field(..., min_length=2, max_length=160)
    notes: str = Field(default="", max_length=500)


class MemberRequestUpdate(BaseModel):
    status: Optional[Literal["Pending", "In Review", "Approved", "Dismissed"]] = None
    urgency: Optional[Literal["Critical", "Urgent", "Normal"]] = None
    notes: Optional[str] = Field(default=None, max_length=500)


class ApiErrorResponse(BaseModel):
    error: str
    status: int
    details: Optional[Any] = None
