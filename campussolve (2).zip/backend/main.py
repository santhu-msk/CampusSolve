import asyncio
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI, HTTPException, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

from . import services
from .database import Base, SessionLocal, engine, get_db
from .models import BookModel
from .persistence import get_sync_status, initialize_storage
from .realtime import hub
from .schemas import (
    BookCreate,
    BookUpdate,
    ImportRequest,
    IssueCreate,
    MemberCreate,
    MemberRequestCreate,
    MemberRequestUpdate,
    MemberUpdate,
    ReturnCreate,
    SettingsUpdate,
)
from .validators import ServiceError


@asynccontextmanager
async def lifespan(_app: FastAPI):
    hub.set_loop(asyncio.get_running_loop())
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        initialize_storage(db, allow_seed=True)
    finally:
        db.close()
    yield


app = FastAPI(
    title="CampusSolve API",
    description="Smart Library Management Ecosystem REST API (FastAPI + SQLAlchemy + SQLite + Synchronized CSV/JSON)",
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(ServiceError)
async def service_error_handler(_request: Request, exc: ServiceError):
    payload = {"error": exc.message, "status": exc.status_code}
    if exc.details is not None:
        payload["details"] = exc.details
    return JSONResponse(status_code=exc.status_code, content=payload)


@app.exception_handler(HTTPException)
async def http_exception_handler(_request: Request, exc: HTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": exc.detail, "status": exc.status_code},
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(_request: Request, exc: RequestValidationError):
    errors = []
    for e in exc.errors():
        loc = ".".join(str(x) for x in e.get("loc", []) if x != "body")
        errors.append(f"{loc}: {e.get('msg')}" if loc else str(e.get("msg")))
    return JSONResponse(
        status_code=400,
        content={
            "error": "; ".join(errors) or "Validation failed",
            "status": 400,
            "details": jsonable_encoder(exc.errors(), custom_encoder={Exception: str}),
        },
    )


@app.get("/api/health")
def health(db: Session = Depends(get_db)):
    sync = get_sync_status()
    return {
        "status": "ok",
        "database": "sqlite",
        "backend": "fastapi",
        "booksCount": db.query(BookModel).count(),
        "syncStatus": sync.get("status", "unknown"),
        "timestamp": services.now_iso(),
    }


@app.get("/api/sync/status")
def sync_status():
    return get_sync_status()


# ---------------- BOOKS ----------------
@app.get("/api/books")
def list_books(
    search: Optional[str] = Query(default=None),
    category: Optional[str] = Query(default=None),
    availability: Optional[str] = Query(default=None),
    sort_by: str = Query(default="created_at"),
    sort_dir: str = Query(default="desc"),
    db: Session = Depends(get_db),
):
    result = services.list_books(
        db,
        search=search,
        category=category,
        availability=availability,
        sort_by=sort_by,
        sort_dir=sort_dir,
    )
    return {"books": result, "total": len(result)}


@app.get("/api/books/{book_id}")
def get_book(book_id: str, db: Session = Depends(get_db)):
    return services.get_book_detail(db, book_id)


@app.post("/api/books", status_code=201)
def create_book(payload: BookCreate, db: Session = Depends(get_db)):
    book = services.create_book(db, payload.model_dump())
    hub.schedule_publish("book:created")
    return {"book": book}


@app.put("/api/books/{book_id}")
def update_book(book_id: str, payload: BookUpdate, db: Session = Depends(get_db)):
    book = services.update_book(db, book_id, payload.model_dump(exclude_unset=True))
    hub.schedule_publish("book:updated")
    return {"book": book}


@app.delete("/api/books/{book_id}")
def delete_book(book_id: str, db: Session = Depends(get_db)):
    res = services.delete_book(db, book_id)
    hub.schedule_publish("book:deleted")
    return res


# ---------------- MEMBERS ----------------
@app.get("/api/members")
def list_members(
    search: Optional[str] = Query(default=None),
    status: Optional[str] = Query(default=None),
    department: Optional[str] = Query(default=None),
    sort_by: str = Query(default="joined_at"),
    sort_dir: str = Query(default="desc"),
    db: Session = Depends(get_db),
):
    result = services.list_members(
        db,
        search=search,
        status=status,
        department=department,
        sort_by=sort_by,
        sort_dir=sort_dir,
    )
    return {"members": result, "total": len(result)}


@app.get("/api/members/{member_id}")
def get_member(member_id: str, db: Session = Depends(get_db)):
    return services.get_member_detail(db, member_id)


@app.post("/api/members", status_code=201)
def create_member(payload: MemberCreate, db: Session = Depends(get_db)):
    member = services.create_member(db, payload.model_dump())
    return {"member": member}


@app.put("/api/members/{member_id}")
def update_member(member_id: str, payload: MemberUpdate, db: Session = Depends(get_db)):
    member = services.update_member(db, member_id, payload.model_dump(exclude_unset=True))
    hub.schedule_publish("member:updated")
    return {"member": member}


@app.delete("/api/members/{member_id}")
def delete_member(member_id: str, db: Session = Depends(get_db)):
    return services.delete_member(db, member_id)


# ---------------- ISSUES & RETURNS ----------------
@app.get("/api/issues")
def list_active_issues(db: Session = Depends(get_db)):
    return {"issues": services.list_active_issues(db)}


@app.post("/api/issues", status_code=201)
def issue_book(payload: IssueCreate, db: Session = Depends(get_db)):
    txn = services.issue_book(db, payload.model_dump())
    hub.schedule_publish(
        "book:issued",
        alert={
            "id": f"due-{txn['id']}",
            "title": f"Book Issued: {txn.get('book_title') or txn['book_id']}",
            "message": f"Issued to {txn.get('member_name') or txn['member_id']} · Due {txn['due_date']}",
            "due_date": txn["due_date"],
        },
    )
    return {"transaction": txn}


@app.get("/api/returns")
def list_recent_returns(db: Session = Depends(get_db)):
    return {"returns": services.list_recent_returns(db)}


@app.post("/api/returns")
def return_book(payload: ReturnCreate, db: Session = Depends(get_db)):
    res = services.return_book(db, payload.model_dump())
    hub.schedule_publish("book:returned")
    return res


# ---------------- TRANSACTIONS, OVERDUE & WARNINGS ----------------
@app.get("/api/transactions")
def list_transactions(
    search: Optional[str] = Query(default=None),
    status: Optional[str] = Query(default=None),
    start_date: Optional[str] = Query(default=None),
    end_date: Optional[str] = Query(default=None),
    sort_by: str = Query(default="issue_date"),
    sort_dir: str = Query(default="desc"),
    db: Session = Depends(get_db),
):
    txs = services.list_transactions(
        db,
        search=search,
        status=status,
        start_date=start_date,
        end_date=end_date,
        sort_by=sort_by,
        sort_dir=sort_dir,
    )
    return {"transactions": txs, "total": len(txs)}


@app.get("/api/overdue")
def list_overdue(
    min_days: int = Query(default=1, ge=0),
    severity: Optional[str] = Query(default=None),
    search: Optional[str] = Query(default=None),
    db: Session = Depends(get_db),
):
    return services.list_overdue(db, min_days=min_days, severity=severity, search=search)


@app.get("/api/warnings")
def get_warnings(db: Session = Depends(get_db)):
    return services.compute_warnings(db)


@app.get("/api/search")
def search_records(
    q: Optional[str] = Query(default=None),
    scope: str = Query(default="all"),
    category: Optional[str] = Query(default=None),
    status: Optional[str] = Query(default=None),
    start_date: Optional[str] = Query(default=None),
    end_date: Optional[str] = Query(default=None),
    sort_by: str = Query(default="relevance"),
    sort_dir: str = Query(default="asc"),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    return services.search_records(
        db,
        query=q,
        scope=scope,
        category=category,
        status=status,
        start_date=start_date,
        end_date=end_date,
        sort_by=sort_by,
        sort_dir=sort_dir,
        page=page,
        page_size=page_size,
    )


# ---------------- ANALYTICS & REPORTS ----------------
@app.get("/api/analytics")
def get_analytics(
    range: str = Query(default="6m"),
    category: str = Query(default="All"),
    db: Session = Depends(get_db),
):
    return services.build_analytics(db, range, category)


@app.get("/api/reports")
def generate_report(
    type: str = Query(default="executive"),
    format: str = Query(default="json"),
    start_date: Optional[str] = Query(default=None),
    end_date: Optional[str] = Query(default=None),
    db: Session = Depends(get_db),
):
    return services.generate_report(
        db,
        report_type=type,
        fmt=format,
        start_date=start_date,
        end_date=end_date,
    )


# ---------------- IMPORT & EXPORT ----------------
@app.get("/api/import/sample")
def get_sample_dataset(entity: str = Query(default="books")):
    data_dir = Path(__file__).resolve().parent.parent / "data"
    if entity == "members":
        p = data_dir / "sample_members_35.json"
        return {
            "entity": "members",
            "format": "json",
            "filename": p.name,
            "content": p.read_text(encoding="utf-8"),
        }
    p = data_dir / "sample_books_35.csv"
    return {
        "entity": "books",
        "format": "csv",
        "filename": p.name,
        "content": p.read_text(encoding="utf-8"),
    }


@app.post("/api/import/preview")
def preview_import(payload: ImportRequest, db: Session = Depends(get_db)):
    return services.validate_import(db, payload.entity, payload.format, payload.content)


@app.post("/api/import", status_code=201)
def commit_import(payload: ImportRequest, db: Session = Depends(get_db)):
    res = services.commit_import(db, payload.entity, payload.format, payload.content)
    hub.schedule_publish("data:imported")
    return res


@app.get("/api/export")
def export_data(
    entity: str = Query(default="books"),
    format: str = Query(default="csv"),
    db: Session = Depends(get_db),
):
    return services.export_data(db, entity=entity, fmt=format)


# ---------------- SETTINGS, BACKUP & ACTIVITY ----------------
@app.get("/api/settings")
def get_settings(db: Session = Depends(get_db)):
    return {"settings": services.get_settings_typed(db)}


@app.put("/api/settings")
def update_settings(payload: SettingsUpdate, db: Session = Depends(get_db)):
    updated = services.update_settings(db, payload.model_dump())
    hub.schedule_publish("settings:updated")
    return {"settings": updated}


@app.get("/api/backup")
def download_backup(db: Session = Depends(get_db)):
    return services.build_backup_payload(db)


@app.get("/api/activity")
def list_activity(
    action_type: Optional[str] = Query(default=None),
    search: Optional[str] = Query(default=None),
    limit: int = Query(default=60, ge=1, le=200),
    db: Session = Depends(get_db),
):
    return {"activities": services.list_activity(db, action_type=action_type, search=search, limit=limit)}


# ---------------- URGENT MEMBER REQUESTS & REAL-TIME NOTIFICATIONS ----------------
@app.get("/api/requests")
def list_requests(
    status: Optional[str] = Query(default=None),
    urgency: Optional[str] = Query(default=None),
    db: Session = Depends(get_db),
):
    reqs = services.list_member_requests(db, status=status, urgency=urgency)
    return {"requests": reqs, "total": len(reqs)}


@app.post("/api/requests", status_code=201)
def create_request(payload: MemberRequestCreate, db: Session = Depends(get_db)):
    req = services.create_member_request(db, payload.model_dump())
    hub.schedule_publish(
        "request:created",
        alert={
            "id": f"req-{req['id']}",
            "title": f"{req['urgency']} {req['request_type']}: {req['title']}",
            "message": f"From {req['member_name']} ({req['member_id']})",
            "urgency": req["urgency"],
        },
    )
    return {"request": req}


@app.patch("/api/requests/{request_id}")
def update_request(request_id: str, payload: MemberRequestUpdate, db: Session = Depends(get_db)):
    req = services.update_member_request(db, request_id, payload.model_dump(exclude_unset=True))
    hub.schedule_publish("request:updated")
    return {"request": req}


@app.get("/api/notifications")
def get_notifications(db: Session = Depends(get_db)):
    return services.build_notifications_payload(db)


@app.post("/api/notifications/read-all")
def read_all_notifications(db: Session = Depends(get_db)):
    payload = services.mark_all_notifications_read(db)
    hub.schedule_publish("notification:read_all")
    return payload


@app.post("/api/notifications/{notification_id}/read")
def mark_notification_read(notification_id: str, db: Session = Depends(get_db)):
    payload = services.mark_notification_state(db, notification_id, is_read=True)
    hub.schedule_publish("notification:read")
    return payload


@app.post("/api/notifications/{notification_id}/dismiss")
def dismiss_notification(notification_id: str, db: Session = Depends(get_db)):
    payload = services.mark_notification_state(db, notification_id, is_read=True, is_dismissed=True)
    hub.schedule_publish("notification:dismissed")
    return payload


@app.websocket("/api/ws/notifications")
async def websocket_notifications(websocket: WebSocket):
    await hub.connect(websocket)
    try:
        db = SessionLocal()
        try:
            initial_payload = services.build_notifications_payload(db)
        finally:
            db.close()

        await websocket.send_json({"type": "notification:init", "payload": initial_payload})

        while True:
            raw = await websocket.receive_json()
            msg_type = raw.get("type") if isinstance(raw, dict) else None
            if msg_type == "ping":
                await websocket.send_json({"type": "pong", "timestamp": services.now_iso()})
            elif msg_type == "refresh":
                db = SessionLocal()
                try:
                    fresh = services.build_notifications_payload(db)
                finally:
                    db.close()
                await websocket.send_json({"type": "notification:sync", "event": "manual_refresh", "payload": fresh})
    except WebSocketDisconnect:
        await hub.disconnect(websocket)
    except Exception:
        await hub.disconnect(websocket)
