from __future__ import annotations

import os
import sys
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from sqlalchemy.orm import Session

from . import services
from .database import Base, SessionLocal, engine
from .persistence import get_sync_status, initialize_storage, resolve_storage_dir
from .validators import (
    ServiceError,
    VALID_MEMBER_STATUSES,
    VALID_MEMBER_TYPES,
    sanitize_text,
    validate_email,
    validate_isbn,
    validate_iso_date,
    validate_phone,
    validate_record_id,
)

BANNER = """==========================================
               CAMPUSSOLVE
         SMART LIBRARY MANAGEMENT
=========================================="""

MENU_TEXT = """
[ 1] Dashboard Summary
[ 2] Add Book
[ 3] View All Books
[ 4] Search Books / Records
[ 5] Update Book
[ 6] Delete Book
[ 7] Register Member
[ 8] Issue Book
[ 9] Return Book
[10] Overdue & Threshold Warnings
[11] Executive Summary
[12] Generate & Save Reports
[13] Bulk Import CSV Dataset
[ 0] Exit Safely
"""


def _trunc(val: Any, width: int) -> str:
    text = str("" if val is None else val).replace("\n", " ")
    if len(text) <= width:
        return text
    if width <= 3:
        return text[:width]
    return text[: width - 3] + "..."


def format_table(headers: Sequence[str], rows: Sequence[Sequence[Any]], widths: Sequence[int]) -> str:
    sep = "+-" + "-+-".join("-" * w for w in widths) + "-+"
    header_line = "| " + " | ".join(_trunc(h, w).ljust(w) for h, w in zip(headers, widths)) + " |"
    lines = [sep, header_line, sep]
    if not rows:
        empty_span = sum(widths) + 3 * (len(widths) - 1)
        lines.append("| " + "No matching records found.".center(empty_span) + " |")
    else:
        for row in rows:
            lines.append("| " + " | ".join(_trunc(cell, w).ljust(w) for cell, w in zip(row, widths)) + " |")
    lines.append(sep)
    return "\n".join(lines)


class CampusSolveCLI:
    def __init__(
        self,
        session_factory: Callable[[], Session] = SessionLocal,
        input_fn: Callable[[str], str] = input,
        output_fn: Callable[[str], None] = print,
    ) -> None:
        self.session_factory = session_factory
        self.input_fn = input_fn
        self.output_fn = output_fn

    def out(self, msg: str = "") -> None:
        self.output_fn(msg)

    def ask(self, prompt: str) -> str:
        return self.input_fn(prompt).strip()

    def ask_validated(
        self,
        prompt: str,
        validator: Callable[[str], Any],
        *,
        default: Optional[str] = None,
        allow_cancel: bool = True,
    ) -> Any:
        while True:
            suffix = f" [{default}]" if default is not None else ""
            hint = " (or 'cancel')" if allow_cancel else ""
            raw = self.ask(f"{prompt}{suffix}{hint}: ")
            if allow_cancel and raw.lower() in ("cancel", ":q"):
                raise KeyboardInterrupt("Operation cancelled by user.")
            if not raw and default is not None:
                raw = default
            try:
                return validator(raw)
            except ServiceError as exc:
                self.out(f"  [!] {exc.message}")
            except ValueError as exc:
                self.out(f"  [!] {exc}")

    def ask_int(
        self,
        prompt: str,
        *,
        min_val: int = 0,
        max_val: int = 10000,
        default: Optional[int] = None,
        allow_cancel: bool = True,
    ) -> int:
        def _parse(val: str) -> int:
            if not val:
                raise ValueError(f"Please enter an integer between {min_val} and {max_val}.")
            try:
                num = int(val)
            except ValueError as exc:
                raise ValueError("Please enter a valid whole number.") from exc
            if num < min_val or num > max_val:
                raise ValueError(f"Value must be between {min_val} and {max_val}.")
            return num

        return self.ask_validated(
            prompt,
            _parse,
            default=str(default) if default is not None else None,
            allow_cancel=allow_cancel,
        )

    def ask_confirm(self, prompt: str, default_yes: bool = False) -> bool:
        hint = "[Y/n]" if default_yes else "[y/N]"
        while True:
            ans = self.ask(f"{prompt} {hint}: ").lower()
            if not ans:
                return default_yes
            if ans in ("y", "yes"):
                return True
            if ans in ("n", "no"):
                return False
            self.out("  [!] Please enter 'y' or 'n'.")

    def paginate_table(
        self,
        title: str,
        headers: Sequence[str],
        rows: Sequence[Sequence[Any]],
        widths: Sequence[int],
        page_size: int = 10,
    ) -> None:
        total = len(rows)
        if total == 0:
            self.out(f"\n--- {title} (0 records) ---")
            self.out(format_table(headers, [], widths))
            return

        total_pages = max(1, (total + page_size - 1) // page_size)
        page = 1
        while True:
            start = (page - 1) * page_size
            end = min(total, start + page_size)
            self.out(f"\n--- {title} | Page {page}/{total_pages} | Showing {start + 1}–{end} of {total} ---")
            self.out(format_table(headers, rows[start:end], widths))
            if total_pages == 1:
                break
            cmd = self.ask("Navigation: [N]ext, [P]rev, [Q]uit view: ").lower()
            if cmd in ("n", "next"):
                if page < total_pages:
                    page += 1
                else:
                    self.out("  Already on the last page.")
            elif cmd in ("p", "prev"):
                if page > 1:
                    page -= 1
                else:
                    self.out("  Already on the first page.")
            elif cmd in ("q", "quit", ""):
                break
            else:
                self.out("  [!] Enter N, P, or Q.")

    def _with_db(self, fn: Callable[[Session], Any]) -> Any:
        db = self.session_factory()
        try:
            return fn(db)
        finally:
            db.close()

    # ---------------- MENU HANDLERS ----------------
    def handle_dashboard(self) -> None:
        def _run(db: Session):
            analytics = services.build_analytics(db, "6m", "All")
            warnings = services.compute_warnings(db)
            sync = get_sync_status()
            return analytics, warnings, sync

        analytics, warnings, sync = self._with_db(_run)
        kpis = analytics["kpis"]
        self.out("\n" + "=" * 64)
        self.out("  CAMPUSSOLVE — DASHBOARD SUMMARY")
        self.out("=" * 64)
        self.out(f"  Books (Titles / Copies)   : {kpis['totalBooks']} titles / {kpis['totalCopies']} copies")
        self.out(f"  Available / Issued Copies : {kpis['availableCopies']} available / {kpis['issuedBooks']} issued ({kpis['utilizationRate']}%)")
        self.out(f"  Members (Total / Active)  : {kpis['totalMembers']} total / {kpis['activeMembers']} active")
        self.out(f"  Transactions / Returns    : {kpis['totalTransactions']} total / {kpis['totalReturns']} returned")
        self.out(f"  Avg Issued / Month        : {kpis['avgBooksIssuedPerMonth']}")
        self.out(f"  Overdue Loans / Fines     : {kpis['overdueBooks']} overdue / ${kpis['totalFinesOutstanding']:.2f}")
        self.out(f"  CSV/JSON Persistence Sync : {sync.get('status', 'unknown')} (last: {sync.get('last_synced_at') or 'n/a'})")
        self.out("-" * 64)
        self.out(
            f"  THRESHOLD WARNINGS ({warnings['totalAlerts']} active): "
            f"Overdue={len(warnings['overdue'])} | "
            f"Approaching Due={len(warnings['approachingDue'])} | "
            f"Out of Stock={len(warnings['unavailableBooks'])} | "
            f"Borrow Limit Reached={len(warnings['borrowLimitBreaches'])}"
        )
        self.out("=" * 64)

    def handle_add_book(self) -> None:
        self.out("\n--- ADD NEW BOOK (type 'cancel' at any prompt to abort) ---")
        try:
            custom_id = self.ask_validated(
                "Book ID (leave blank to auto-generate)",
                lambda v: validate_record_id(v, "Book ID") if v else None,
                default="",
            )
            isbn = self.ask_validated("ISBN (10 or 13 digits)", lambda v: validate_isbn(v, required=True))
            title = self.ask_validated(
                "Title",
                lambda v: sanitize_text(v, 200) or (_ for _ in ()).throw(ServiceError("Book title cannot be empty.")),
            )
            author = self.ask_validated(
                "Author",
                lambda v: sanitize_text(v, 150) or (_ for _ in ()).throw(ServiceError("Author name cannot be empty.")),
            )
            category = self.ask_validated(
                "Category",
                lambda v: sanitize_text(v, 80) or (_ for _ in ()).throw(ServiceError("Category cannot be empty.")),
                default="Computer Science",
            )
            publisher = self.ask_validated(
                "Publisher",
                lambda v: sanitize_text(v, 120) or (_ for _ in ()).throw(ServiceError("Publisher cannot be empty.")),
                default="Academic Press",
            )
            year = self.ask_int("Publication Year", min_val=1450, max_val=2030, default=2024)
            shelf = self.ask("Shelf Location [GEN-A1-01]: ") or "GEN-A1-01"
            total_copies = self.ask_int("Total Copies", min_val=0, max_val=500, default=3)
            avail_copies = self.ask_int("Available Copies", min_val=0, max_val=total_copies, default=total_copies)
            description = self.ask("Description (optional): ")

            payload = {
                "id": custom_id,
                "isbn": isbn,
                "title": title,
                "author": author,
                "category": category,
                "publisher": publisher,
                "publication_year": year,
                "shelf_location": shelf,
                "total_copies": total_copies,
                "available_copies": avail_copies,
                "description": description,
            }
            book = self._with_db(lambda db: services.create_book(db, payload, actor="Terminal CLI"))
            self.out(f"\n  [OK] Book added & synced: {book['id']} — \"{book['title']}\" ({book['available_copies']}/{book['total_copies']} available)")
        except KeyboardInterrupt:
            self.out("\n  [Cancelled] Book creation aborted.")
        except ServiceError as exc:
            self.out(f"\n  [Error] {exc.message}")

    def handle_view_books(self) -> None:
        books = self._with_db(lambda db: services.list_books(db, sort_by="id", sort_dir="asc"))
        rows = [
            [
                b["id"],
                b["isbn"],
                b["title"],
                b["author"],
                b["category"],
                f"{b['available_copies']}/{b['total_copies']}",
                b["availability_status"],
            ]
            for b in books
        ]
        self.paginate_table(
            "ALL LIBRARY BOOKS",
            ["ID", "ISBN", "Title", "Author", "Category", "Copies", "Status"],
            rows,
            [9, 15, 28, 20, 17, 7, 12],
        )

    def handle_search_records(self) -> None:
        self.out("\n--- SEARCH LIBRARY RECORDS ---")
        query = self.ask("Search keyword (blank for all): ")
        scope_raw = (self.ask("Scope [all / books / members / transactions] (default: all): ") or "all").lower()
        scope = scope_raw if scope_raw in ("all", "books", "members", "transactions") else "all"
        sort_raw = (self.ask("Sort by [relevance / title / date / id] (default: relevance): ") or "relevance").lower()
        sort_by = sort_raw if sort_raw in ("relevance", "title", "date", "id") else "relevance"
        start_date = self.ask("Start date filter YYYY-MM-DD (optional): ")
        end_date = self.ask("End date filter YYYY-MM-DD (optional): ")

        try:
            res = self._with_db(
                lambda db: services.search_records(
                    db,
                    query=query or None,
                    scope=scope,
                    start_date=start_date or None,
                    end_date=end_date or None,
                    sort_by=sort_by,
                )
            )
        except ServiceError as exc:
            self.out(f"  [Error] {exc.message}")
            return

        counts = res["counts"]
        self.out(
            f"\n  Matches -> Total: {counts['total']} | Books: {counts['books']} | "
            f"Members: {counts['members']} | Transactions: {counts['transactions']}"
        )
        if res["books"]:
            rows = [
                [b["id"], b["title"], b["author"], b["category"], f"{b['available_copies']}/{b['total_copies']}"]
                for b in res["books"]
            ]
            self.paginate_table("MATCHING BOOKS", ["ID", "Title", "Author", "Category", "Copies"], rows, [9, 30, 22, 18, 8])
        if res["members"]:
            rows = [
                [m["id"], m["full_name"], m["email"], m["department"], m["status"]]
                for m in res["members"]
            ]
            self.paginate_table("MATCHING MEMBERS", ["ID", "Full Name", "Email", "Department", "Status"], rows, [9, 22, 26, 18, 10])
        if res["transactions"]:
            rows = [
                [t["id"], t["book_title"] or t["book_id"], t["member_name"] or t["member_id"], t["issue_date"], t["due_date"], t["status"]]
                for t in res["transactions"]
            ]
            self.paginate_table("MATCHING TRANSACTIONS", ["TXN ID", "Book", "Member", "Issued", "Due", "Status"], rows, [9, 26, 20, 11, 11, 10])

    def handle_update_book(self) -> None:
        self.out("\n--- UPDATE BOOK ---")
        try:
            book_id = self.ask_validated(
                "Enter Book ID (e.g. BK-1001)",
                lambda v: validate_record_id(v, "Book ID") or (_ for _ in ()).throw(ServiceError("Book ID is required.")),
            )
            detail = self._with_db(lambda db: services.get_book_detail(db, book_id))
            book = detail["book"]
            self.out(f"  Editing: {book['id']} — {book['title']} by {book['author']} ({book['available_copies']}/{book['total_copies']} copies)")
            self.out("  Press Enter to keep current values.")

            updates: Dict[str, Any] = {}
            new_title = self.ask(f"Title [{book['title']}]: ")
            if new_title:
                updates["title"] = new_title
            new_author = self.ask(f"Author [{book['author']}]: ")
            if new_author:
                updates["author"] = new_author
            new_cat = self.ask(f"Category [{book['category']}]: ")
            if new_cat:
                updates["category"] = new_cat
            new_shelf = self.ask(f"Shelf [{book['shelf_location']}]: ")
            if new_shelf:
                updates["shelf_location"] = new_shelf

            total_in = self.ask(f"Total Copies [{book['total_copies']}]: ")
            if total_in:
                updates["total_copies"] = int(total_in)
            avail_in = self.ask(f"Available Copies [{book['available_copies']}]: ")
            if avail_in:
                updates["available_copies"] = int(avail_in)

            if not updates:
                self.out("  No changes entered.")
                return

            updated = self._with_db(lambda db: services.update_book(db, book["id"], updates, actor="Terminal CLI"))
            self.out(f"  [OK] Updated {updated['id']} — \"{updated['title']}\" ({updated['available_copies']}/{updated['total_copies']} available)")
        except KeyboardInterrupt:
            self.out("\n  [Cancelled] Update aborted.")
        except (ServiceError, ValueError) as exc:
            msg = exc.message if isinstance(exc, ServiceError) else str(exc)
            self.out(f"  [Error] {msg}")

    def handle_delete_book(self) -> None:
        self.out("\n--- DELETE BOOK ---")
        try:
            book_id = self.ask_validated(
                "Enter Book ID to delete",
                lambda v: validate_record_id(v, "Book ID") or (_ for _ in ()).throw(ServiceError("Book ID is required.")),
            )
            detail = self._with_db(lambda db: services.get_book_detail(db, book_id))
            book = detail["book"]
            self.out(f"  Target: {book['id']} — \"{book['title']}\" by {book['author']} ({book['available_copies']}/{book['total_copies']} available)")
            if not self.ask_confirm("Confirm permanent deletion?", default_yes=False):
                self.out("  [Cancelled] Deletion aborted.")
                return
            self._with_db(lambda db: services.delete_book(db, book["id"], actor="Terminal CLI"))
            self.out(f"  [OK] Deleted book {book['id']} and synchronized storage files.")
        except KeyboardInterrupt:
            self.out("\n  [Cancelled] Deletion aborted.")
        except ServiceError as exc:
            self.out(f"  [Error] {exc.message}")

    def handle_register_member(self) -> None:
        self.out("\n--- REGISTER MEMBER (type 'cancel' at any prompt to abort) ---")
        try:
            custom_id = self.ask_validated(
                "Member ID (leave blank to auto-generate)",
                lambda v: validate_record_id(v, "Member ID") if v else None,
                default="",
            )
            full_name = self.ask_validated(
                "Full Name",
                lambda v: sanitize_text(v, 120) if len(sanitize_text(v, 120)) >= 2 else (_ for _ in ()).throw(ServiceError("Name must be at least 2 characters.")),
            )
            email = self.ask_validated("Email Address", validate_email)
            phone = self.ask_validated("Phone Number", validate_phone, default="+1 (555) 200-1000")
            dept = self.ask_validated(
                "Department",
                lambda v: sanitize_text(v, 100) or (_ for _ in ()).throw(ServiceError("Department is required.")),
                default="Computer Science",
            )
            course = self.ask_validated(
                "Course / Program",
                lambda v: sanitize_text(v, 120) or (_ for _ in ()).throw(ServiceError("Course is required.")),
                default="B.Tech CS",
            )
            m_type = self.ask_validated(
                f"Member Type ({'/'.join(VALID_MEMBER_TYPES)})",
                lambda v: v if v in VALID_MEMBER_TYPES else (_ for _ in ()).throw(ServiceError(f"Choose from {', '.join(VALID_MEMBER_TYPES)}.")),
                default="Student",
            )
            status = self.ask_validated(
                f"Status ({'/'.join(VALID_MEMBER_STATUSES)})",
                lambda v: v if v in VALID_MEMBER_STATUSES else (_ for _ in ()).throw(ServiceError(f"Choose from {', '.join(VALID_MEMBER_STATUSES)}.")),
                default="Active",
            )
            limit = self.ask_int("Max Borrow Limit", min_val=1, max_val=20, default=5)

            payload = {
                "id": custom_id,
                "full_name": full_name,
                "email": email,
                "phone": phone,
                "department": dept,
                "course": course,
                "member_type": m_type,
                "status": status,
                "max_borrow_limit": limit,
            }
            member = self._with_db(lambda db: services.create_member(db, payload, actor="Terminal CLI"))
            self.out(f"\n  [OK] Member registered & synced: {member['id']} — {member['full_name']} ({member['email']})")
        except KeyboardInterrupt:
            self.out("\n  [Cancelled] Member registration aborted.")
        except ServiceError as exc:
            self.out(f"\n  [Error] {exc.message}")

    def handle_issue_book(self) -> None:
        self.out("\n--- ISSUE BOOK (type 'cancel' at any prompt to abort) ---")
        try:
            default_loan_days = self._with_db(lambda db: services.get_settings_typed(db)["default_loan_days"])
            book_id = self.ask_validated(
                "Book ID (e.g. BK-1001)",
                lambda v: validate_record_id(v, "Book ID") or (_ for _ in ()).throw(ServiceError("Book ID is required.")),
            )
            member_id = self.ask_validated(
                "Member ID (e.g. MEM-2001)",
                lambda v: validate_record_id(v, "Member ID") or (_ for _ in ()).throw(ServiceError("Member ID is required.")),
            )
            today_iso = date.today().isoformat()
            default_due = (date.today() + timedelta(days=default_loan_days)).isoformat()
            issue_date = self.ask_validated("Issue Date (YYYY-MM-DD)", lambda v: validate_iso_date(v, "Issue date"), default=today_iso)
            due_date = self.ask_validated("Due Date (YYYY-MM-DD)", lambda v: validate_iso_date(v, "Due date"), default=default_due)
            notes = self.ask("Notes (optional): ")

            txn = self._with_db(
                lambda db: services.issue_book(
                    db,
                    {
                        "book_id": book_id,
                        "member_id": member_id,
                        "issue_date": issue_date,
                        "due_date": due_date,
                        "notes": notes,
                    },
                    actor="Terminal CLI",
                )
            )
            self.out(
                f"\n  [OK] Issued {txn['id']}: \"{txn['book_title']}\" ({txn['book_id']}) -> "
                f"{txn['member_name']} ({txn['member_id']}) | Due {txn['due_date']}"
            )
        except KeyboardInterrupt:
            self.out("\n  [Cancelled] Book issue aborted.")
        except ServiceError as exc:
            self.out(f"\n  [Error] {exc.message}")

    def handle_return_book(self) -> None:
        self.out("\n--- RETURN BOOK ---")
        try:
            active = self._with_db(services.list_active_issues)
            if active:
                preview_rows = [
                    [t["id"], t["book_id"], t["book_title"] or "", t["member_name"] or t["member_id"], t["due_date"], t["status"]]
                    for t in active[:10]
                ]
                self.out(format_table(["TXN ID", "Book ID", "Title", "Member", "Due Date", "Status"], preview_rows, [9, 9, 26, 20, 11, 10]))
            txn_id = self.ask_validated(
                "Transaction ID to return (e.g. TXN-3001)",
                lambda v: validate_record_id(v, "Transaction ID") or (_ for _ in ()).throw(ServiceError("Transaction ID is required.")),
            )
            ret_date = self.ask_validated(
                "Return Date (YYYY-MM-DD)",
                lambda v: validate_iso_date(v, "Return date"),
                default=date.today().isoformat(),
            )
            waive = self.ask_confirm("Waive overdue fine if applicable?", default_yes=False)
            notes = self.ask("Notes (optional): ")

            res = self._with_db(
                lambda db: services.return_book(
                    db,
                    {"transaction_id": txn_id, "return_date": ret_date, "waive_fine": waive, "notes": notes},
                    actor="Terminal CLI",
                )
            )
            txn = res["transaction"]
            self.out(
                f"\n  [OK] Returned {txn['id']} ({txn['book_title']}) | "
                f"Overdue Days: {res['overdue_days']} | Fine: ${res['fine_amount']:.2f}"
            )
        except KeyboardInterrupt:
            self.out("\n  [Cancelled] Book return aborted.")
        except ServiceError as exc:
            self.out(f"\n  [Error] {exc.message}")

    def handle_warnings(self) -> None:
        w = self._with_db(services.compute_warnings)
        self.out("\n" + "=" * 68)
        self.out(f"  OVERDUE & THRESHOLD WARNINGS (Total Alerts: {w['totalAlerts']})")
        self.out(f"  Policy: Warning <= {w['thresholds']['warning_threshold_days']}d to due | Critical >= {w['thresholds']['critical_overdue_days']}d overdue | Fine ${w['thresholds']['daily_fine_rate']:.2f}/day")
        self.out("=" * 68)

        overdue_rows = [
            [r["id"], r["book_title"] or r["book_id"], r["member_name"] or r["member_id"], r["due_date"], r["days_overdue"], f"${r['estimated_fine']:.2f}", r["severity"]]
            for r in w["overdue"]
        ]
        self.out("\n[Overdue Loans]")
        self.out(format_table(["TXN", "Book", "Member", "Due", "Days", "Fine", "Severity"], overdue_rows, [9, 24, 18, 11, 5, 8, 9]))

        soon_rows = [
            [r["id"], r["book_title"] or r["book_id"], r["member_name"] or r["member_id"], r["due_date"], r["days_remaining"]]
            for r in w["approachingDue"]
        ]
        self.out(f"\n[Approaching Due Dates (Next {w['thresholds']['warning_threshold_days']} Days)]")
        self.out(format_table(["TXN", "Book", "Member", "Due", "Days Left"], soon_rows, [9, 28, 22, 11, 9]))

        unavail_rows = [
            [b["id"], b["title"], b["category"], f"{b['available_copies']}/{b['total_copies']}"]
            for b in w["unavailableBooks"]
        ]
        self.out("\n[Unavailable / Out-of-Stock Books]")
        self.out(format_table(["ID", "Title", "Category", "Copies"], unavail_rows, [9, 34, 20, 8]))

        if w["anomalousQuantities"]:
            anom_rows = [[b["id"], b["title"], b["anomaly"]] for b in w["anomalousQuantities"]]
            self.out("\n[Anomalous Inventory Quantities]")
            self.out(format_table(["ID", "Title", "Anomaly"], anom_rows, [9, 28, 36]))

        limit_rows = [
            [m["id"], m["full_name"], f"{m['active_issues_count']}/{m['max_borrow_limit']}", m["status"]]
            for m in w["borrowLimitBreaches"]
        ]
        self.out("\n[Members At/Above Borrowing Limit]")
        self.out(format_table(["ID", "Member", "Active/Limit", "Status"], limit_rows, [9, 26, 12, 10]))

    def handle_executive_summary(self) -> None:
        analytics = self._with_db(lambda db: services.build_analytics(db, "all", "All"))
        kpis = analytics["kpis"]
        self.out("\n" + "=" * 64)
        self.out("  EXECUTIVE SUMMARY — ALL-TIME LIBRARY INTELLIGENCE")
        self.out("=" * 64)
        self.out(f"  Total Titles                 : {kpis['totalBooks']}")
        self.out(f"  Total / Available Copies     : {kpis['totalCopies']} / {kpis['availableCopies']}")
        self.out(f"  Currently Issued             : {kpis['issuedBooks']} ({kpis['utilizationRate']}% utilization)")
        self.out(f"  Total / Active Members       : {kpis['totalMembers']} / {kpis['activeMembers']}")
        self.out(f"  Total Issues / Returns       : {kpis['totalTransactions']} / {kpis['totalReturns']}")
        self.out(f"  Avg Books Issued / Month     : {kpis['avgBooksIssuedPerMonth']}")
        self.out(f"  Overdue Count / Fines        : {kpis['overdueBooks']} / ${kpis['totalFinesOutstanding']:.2f}")
        self.out("")
        cat_rows = [
            [c["category"], c["titles"], c["totalCopies"], c["availableCopies"], c["borrowCount"]]
            for c in analytics["categoryDistribution"]
        ]
        self.out(format_table(["Category", "Titles", "Total", "Avail", "Borrows"], cat_rows, [22, 8, 8, 8, 9]))

    def handle_generate_report(self) -> None:
        self.out("\n--- GENERATE & SAVE REPORT ---")
        valid_types = ("executive", "inventory", "members", "issues", "returns", "overdue", "transactions", "audit")
        valid_fmts = ("markdown", "csv", "json", "txt")
        self.out(f"  Types  : {', '.join(valid_types)}")
        self.out(f"  Formats: {', '.join(valid_fmts)}")
        r_type = (self.ask("Report Type [executive]: ") or "executive").lower()
        if r_type not in valid_types:
            self.out(f"  [!] Unknown type '{r_type}'. Using 'executive'.")
            r_type = "executive"
        fmt = (self.ask("Format [markdown]: ") or "markdown").lower()
        if fmt not in valid_fmts:
            self.out(f"  [!] Unknown format '{fmt}'. Using 'markdown'.")
            fmt = "markdown"
        start_d = self.ask("Start date YYYY-MM-DD (optional): ")
        end_d = self.ask("End date YYYY-MM-DD (optional): ")

        try:
            report = self._with_db(
                lambda db: services.generate_report(
                    db,
                    report_type=r_type,
                    fmt=fmt,
                    start_date=start_d or None,
                    end_date=end_d or None,
                    actor="Terminal CLI",
                )
            )
            ext = {"markdown": "md", "csv": "csv", "json": "json", "txt": "txt"}[fmt]
            reports_dir = resolve_storage_dir() / "reports"
            reports_dir.mkdir(parents=True, exist_ok=True)
            ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            out_path = reports_dir / f"campussolve_{r_type}_{ts}.{ext}"
            out_path.write_text(report["content"], encoding="utf-8")
            self.out(f"\n  [OK] Report generated ({len(report['rows'])} row(s)) and saved to: {out_path}")
            preview_lines = report["content"].splitlines()[:18]
            self.out("\n--- PREVIEW ---")
            self.out("\n".join(preview_lines))
        except ServiceError as exc:
            self.out(f"  [Error] {exc.message}")

    def handle_bulk_import(self) -> None:
        self.out("\n--- BULK IMPORT CSV DATASET ---")
        default_sample = str(Path(__file__).resolve().parent.parent / "data" / "sample_books_35.csv")
        entity = (self.ask("Entity [books / members] (default: books): ") or "books").lower()
        if entity not in ("books", "members"):
            self.out("  [!] Invalid entity; defaulting to 'books'.")
            entity = "books"
        path_raw = self.ask(f"File path [{default_sample}]: ") or default_sample
        p = Path(path_raw)
        if not p.exists() or not p.is_file():
            self.out(f"  [Error] File not found: {path_raw}")
            return
        fmt = "json" if p.suffix.lower() == ".json" else "csv"
        content = p.read_text(encoding="utf-8", errors="replace")
        try:
            preview = self._with_db(lambda db: services.validate_import(db, entity, fmt, content))
            self.out(
                f"\n  Validation Preview -> Total: {preview['totalRows']} | Valid: {preview['validRows']} | "
                f"Duplicates: {preview['duplicateRows']} | Invalid/Skipped: {preview['invalidRows']}"
            )
            bad = [r for r in preview["rows"] if not r["valid"]]
            for r in bad[:8]:
                self.out(f"    Row {r['rowNumber']}: {'; '.join(r['errors'])}")
            if preview["validRows"] == 0:
                self.out("  [!] No valid rows available to import.")
                return
            if not self.ask_confirm(f"Commit {preview['validRows']} valid record(s)?", default_yes=False):
                self.out("  [Cancelled] Import aborted.")
                return
            res = self._with_db(lambda db: services.commit_import(db, entity, fmt, content, actor="Terminal CLI"))
            self.out(f"  [OK] Imported {res['importedCount']} record(s), skipped {res['skippedCount']}. CSV/JSON storage synced.")
        except ServiceError as exc:
            self.out(f"  [Error] {exc.message}")

    def run(self) -> int:
        Base.metadata.create_all(bind=engine)
        sync_info = self._with_db(lambda db: initialize_storage(db, allow_seed=True))
        self.out(BANNER)
        if sync_info.get("warnings"):
            for w in sync_info["warnings"]:
                self.out(f"  [Storage Notice] {w}")

        while True:
            self.out(MENU_TEXT)
            try:
                choice = self.ask("Select option [0-13]: ")
            except (EOFError, KeyboardInterrupt):
                self.out("\nExiting CampusSolve safely. Goodbye.")
                return 0

            if choice == "0":
                sync = get_sync_status()
                self.out(f"\nStorage status: {sync.get('status')} | Exiting CampusSolve safely. Goodbye.")
                return 0
            elif choice == "1":
                self.handle_dashboard()
            elif choice == "2":
                self.handle_add_book()
            elif choice == "3":
                self.handle_view_books()
            elif choice == "4":
                self.handle_search_records()
            elif choice == "5":
                self.handle_update_book()
            elif choice == "6":
                self.handle_delete_book()
            elif choice == "7":
                self.handle_register_member()
            elif choice == "8":
                self.handle_issue_book()
            elif choice == "9":
                self.handle_return_book()
            elif choice == "10":
                self.handle_warnings()
            elif choice == "11":
                self.handle_executive_summary()
            elif choice == "12":
                self.handle_generate_report()
            elif choice == "13":
                self.handle_bulk_import()
            else:
                self.out(f"  [!] Invalid selection '{choice}'. Please enter a number between 0 and 13.")


def main() -> int:
    cli = CampusSolveCLI()
    return cli.run()


if __name__ == "__main__":
    sys.exit(main())
