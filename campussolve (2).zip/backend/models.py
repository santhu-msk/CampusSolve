from sqlalchemy import Column, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship
from .database import Base


class BookModel(Base):
    __tablename__ = "books"

    id = Column(String, primary_key=True, index=True)
    isbn = Column(String, unique=True, nullable=False, index=True)
    title = Column(String, nullable=False, index=True)
    author = Column(String, nullable=False)
    category = Column(String, nullable=False, index=True)
    publisher = Column(String, nullable=False)
    publication_year = Column(Integer, nullable=False)
    shelf_location = Column(String, nullable=False)
    description = Column(Text, nullable=False, default="")
    cover_image = Column(String, nullable=True)
    total_copies = Column(Integer, nullable=False)
    available_copies = Column(Integer, nullable=False)
    created_at = Column(String, nullable=False)
    updated_at = Column(String, nullable=False)

    transactions = relationship("TransactionModel", back_populates="book")


class MemberModel(Base):
    __tablename__ = "members"

    id = Column(String, primary_key=True, index=True)
    full_name = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False, index=True)
    phone = Column(String, nullable=False)
    department = Column(String, nullable=False, index=True)
    course = Column(String, nullable=False)
    member_type = Column(String, nullable=False)
    status = Column(String, nullable=False, default="Active")
    max_borrow_limit = Column(Integer, nullable=False, default=5)
    joined_at = Column(String, nullable=False)
    updated_at = Column(String, nullable=False)

    transactions = relationship("TransactionModel", back_populates="member")


class TransactionModel(Base):
    __tablename__ = "transactions"

    id = Column(String, primary_key=True, index=True)
    book_id = Column(String, ForeignKey("books.id", ondelete="RESTRICT"), nullable=False, index=True)
    member_id = Column(String, ForeignKey("members.id", ondelete="RESTRICT"), nullable=False, index=True)
    issue_date = Column(String, nullable=False)
    due_date = Column(String, nullable=False)
    return_date = Column(String, nullable=True)
    status = Column(String, nullable=False, index=True)
    fine_amount = Column(Float, nullable=False, default=0.0)
    notes = Column(Text, nullable=False, default="")
    created_at = Column(String, nullable=False)
    updated_at = Column(String, nullable=False)

    book = relationship("BookModel", back_populates="transactions")
    member = relationship("MemberModel", back_populates="transactions")


class ActivityLogModel(Base):
    __tablename__ = "activity_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    action_type = Column(String, nullable=False)
    entity_type = Column(String, nullable=False)
    entity_id = Column(String, nullable=False)
    summary = Column(Text, nullable=False)
    actor = Column(String, nullable=False, default="Dr. Eleanor Vance")
    created_at = Column(String, nullable=False)


class SettingModel(Base):
    __tablename__ = "settings"

    key = Column(String, primary_key=True)
    value = Column(String, nullable=False)


class MemberRequestModel(Base):
    __tablename__ = "member_requests"

    id = Column(String, primary_key=True, index=True)
    member_id = Column(String, ForeignKey("members.id", ondelete="CASCADE"), nullable=False, index=True)
    book_id = Column(String, ForeignKey("books.id", ondelete="SET NULL"), nullable=True, index=True)
    request_type = Column(String, nullable=False, default="Urgent Hold")
    urgency = Column(String, nullable=False, default="Urgent", index=True)
    title = Column(String, nullable=False)
    notes = Column(Text, nullable=False, default="")
    status = Column(String, nullable=False, default="Pending", index=True)
    created_at = Column(String, nullable=False)
    updated_at = Column(String, nullable=False)

    member = relationship("MemberModel")
    book = relationship("BookModel")


class NotificationStateModel(Base):
    __tablename__ = "notification_states"

    notification_id = Column(String, primary_key=True, index=True)
    is_read = Column(Integer, nullable=False, default=0)
    is_dismissed = Column(Integer, nullable=False, default=0)
    acknowledged_at = Column(String, nullable=True)
    updated_at = Column(String, nullable=False)

