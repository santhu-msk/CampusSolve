import os
import tempfile
import pytest
from fastapi.testclient import TestClient

# Point tests to an isolated temporary SQLite database
_tmp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_tmp_db.close()
os.environ["CAMPUSSOLVE_DATABASE_URL"] = f"sqlite:///{_tmp_db.name}"

from backend.main import app  # noqa: E402


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def test_health_and_seeded_analytics(client: TestClient):
    res = client.get("/api/health")
    assert res.status_code == 200
    body = res.json()
    assert body["status"] == "ok"
    assert body["backend"] == "fastapi"
    assert body["booksCount"] == 32

    an = client.get("/api/analytics?range=6m")
    assert an.status_code == 200
    kpis = an.json()["kpis"]
    assert kpis["totalBooks"] == 32
    assert kpis["totalMembers"] == 24
    assert kpis["overdueBooks"] >= 1


def test_books_crud_and_validation(client: TestClient):
    # Duplicate ISBN rejected
    dup = client.post(
        "/api/books",
        json={
            "isbn": "978-0262046305",
            "title": "Duplicate ISBN Test",
            "author": "Test",
            "category": "Computer Science",
            "publisher": "MIT Press",
            "publication_year": 2024,
            "total_copies": 2,
        },
    )
    assert dup.status_code == 409

    # Create valid book
    created = client.post(
        "/api/books",
        json={
            "isbn": "978-9999990001",
            "title": "FastAPI Architecture Manual",
            "author": "Dr. Test",
            "category": "Computer Science",
            "publisher": "O'Reilly Media",
            "publication_year": 2025,
            "shelf_location": "CS-Z1-01",
            "total_copies": 3,
        },
    )
    assert created.status_code == 201
    book_id = created.json()["book"]["id"]

    # Get single book
    detail = client.get(f"/api/books/{book_id}")
    assert detail.status_code == 200
    assert detail.json()["book"]["available_copies"] == 3

    # Update book
    updated = client.put(f"/api/books/{book_id}", json={"total_copies": 5, "available_copies": 5})
    assert updated.status_code == 200
    assert updated.json()["book"]["total_copies"] == 5


def test_issue_validation_and_return_workflow(client: TestClient):
    # Register a new active member
    m_res = client.post(
        "/api/members",
        json={
            "full_name": "Pytest Student",
            "email": "pytest.student@northbridge.edu",
            "phone": "+1 555-888-1234",
            "department": "Computer Science",
            "course": "B.Tech CS",
            "member_type": "Student",
            "status": "Active",
            "max_borrow_limit": 5,
        },
    )
    assert m_res.status_code == 201
    member_id = m_res.json()["member"]["id"]

    # Invalid member rejected
    bad_member = client.post(
        "/api/issues",
        json={
            "member_id": "MEM-9999",
            "book_id": "BK-1001",
            "issue_date": "2026-11-10",
            "due_date": "2026-11-24",
        },
    )
    assert bad_member.status_code == 404

    # Suspended member rejected (MEM-2017 is seeded as Suspended)
    suspended = client.post(
        "/api/issues",
        json={
            "member_id": "MEM-2017",
            "book_id": "BK-1001",
            "issue_date": "2026-11-10",
            "due_date": "2026-11-24",
        },
    )
    assert suspended.status_code == 422

    # Due date before issue date rejected
    bad_date = client.post(
        "/api/issues",
        json={
            "member_id": member_id,
            "book_id": "BK-1003",
            "issue_date": "2026-11-15",
            "due_date": "2026-11-10",
        },
    )
    assert bad_date.status_code == 400

    # Valid issue succeeds
    before_avail = client.get("/api/books/BK-1003").json()["book"]["available_copies"]
    issued = client.post(
        "/api/issues",
        json={
            "member_id": member_id,
            "book_id": "BK-1003",
            "issue_date": "2026-11-01",
            "due_date": "2026-11-10",
        },
    )
    assert issued.status_code == 201
    txn_id = issued.json()["transaction"]["id"]
    after_avail = client.get("/api/books/BK-1003").json()["book"]["available_copies"]
    assert after_avail == before_avail - 1

    # Duplicate active borrow prevented
    dup_borrow = client.post(
        "/api/issues",
        json={
            "member_id": member_id,
            "book_id": "BK-1003",
            "issue_date": "2026-11-02",
            "due_date": "2026-11-16",
        },
    )
    assert dup_borrow.status_code == 409

    # Return book calculates overdue days & restores copy
    returned = client.post(
        "/api/returns",
        json={"transaction_id": txn_id, "return_date": "2026-11-14"},
    )
    assert returned.status_code == 200
    assert returned.json()["overdue_days"] == 4
    assert returned.json()["fine_amount"] == 10.0
    restored_avail = client.get("/api/books/BK-1003").json()["book"]["available_copies"]
    assert restored_avail == before_avail


def test_reports_import_and_settings(client: TestClient):
    rep = client.get("/api/reports?type=executive&format=markdown")
    assert rep.status_code == 200
    assert "CampusSolve Executive Summary Report" in rep.json()["content"]

    csv_payload = (
        "isbn,title,author,category,publisher,publication_year,total_copies\n"
        "978-8888880001,Imported Sample Book,Ada Lovelace,Mathematics,Cambridge University Press,2024,4\n"
        "978-0262046305,Duplicate Seeded ISBN,Thomas Cormen,Computer Science,MIT Press,2022,2\n"
    )
    prev = client.post("/api/import/preview", json={"entity": "books", "format": "csv", "content": csv_payload})
    assert prev.status_code == 200
    assert prev.json()["validRows"] == 1
    assert prev.json()["duplicateRows"] == 1

    imp = client.post("/api/import", json={"entity": "books", "format": "csv", "content": csv_payload})
    assert imp.status_code == 201
    assert imp.json()["importedCount"] == 1

    sample_books = client.get("/api/import/sample?entity=books")
    assert sample_books.status_code == 200
    assert sample_books.json()["format"] == "csv"
    assert "978-" in sample_books.json()["content"]

    sample_members = client.get("/api/import/sample?entity=members")
    assert sample_members.status_code == 200
    assert sample_members.json()["format"] == "json"

    settings = client.get("/api/settings").json()["settings"]
    assert settings["default_loan_days"] == 14


def test_search_warnings_sync_status_and_boundaries(client: TestClient):
    # Boundary: 0 total copies allowed, negative rejected
    zero_book = client.post(
        "/api/books",
        json={
            "id": "BK-9900",
            "isbn": "978-9999990099",
            "title": "Zero Copy Reference Shelf",
            "author": "Boundary Tester",
            "category": "Mathematics",
            "publisher": "Test Press",
            "publication_year": 2024,
            "total_copies": 0,
            "available_copies": 0,
        },
    )
    assert zero_book.status_code == 201
    assert zero_book.json()["book"]["availability_status"] == "Out of Stock"

    neg_book = client.post(
        "/api/books",
        json={
            "isbn": "978-9999990098",
            "title": "Negative Copy Invalid",
            "author": "Tester",
            "category": "Mathematics",
            "publisher": "Test Press",
            "publication_year": 2024,
            "total_copies": -1,
        },
    )
    assert neg_book.status_code == 400

    # Sync status endpoint reflects synchronized 6 files
    sync = client.get("/api/sync/status")
    assert sync.status_code == 200
    assert sync.json()["status"] == "synchronized"
    assert sync.json()["files"]["books.csv"] >= 33

    # Warnings endpoint detects overdue + unavailable books
    warn = client.get("/api/warnings")
    assert warn.status_code == 200
    w_body = warn.json()
    assert w_body["totalAlerts"] >= 1
    assert any(b["id"] == "BK-9900" for b in w_body["unavailableBooks"])

    # Unified search + sorting + scope
    sr = client.get("/api/search?q=Zero+Copy&scope=books&sort_by=title&sort_dir=asc")
    assert sr.status_code == 200
    assert sr.json()["counts"]["books"] == 1
    assert sr.json()["books"][0]["id"] == "BK-9900"

    # Transactions date range filter
    tx_res = client.get("/api/transactions?start_date=2000-01-01&end_date=2099-12-31")
    assert tx_res.status_code == 200
    assert tx_res.json()["total"] >= 1

    # Audit log plain-text report
    audit_rep = client.get("/api/reports?type=audit&format=txt")
    assert audit_rep.status_code == 200
    assert "SYSTEM AUDIT LOG REPORT" in audit_rep.json()["content"]

    # Analytics includes totalReturns & avgBooksIssuedPerMonth
    an = client.get("/api/analytics?range=all")
    assert an.status_code == 200
    kpis = an.json()["kpis"]
    assert "totalReturns" in kpis
    assert "avgBooksIssuedPerMonth" in kpis


def test_realtime_notifications_and_member_requests(client: TestClient):
    # Initial notifications feed includes seeded urgent requests & upcoming due dates
    notif_res = client.get("/api/notifications")
    assert notif_res.status_code == 200
    body = notif_res.json()
    assert body["urgentRequestCount"] >= 1
    assert body["dueSoonCount"] >= 1
    assert any(n["category"] == "urgent_request" for n in body["notifications"])
    assert any(n["category"] == "due_soon" for n in body["notifications"])

    # WebSocket connection delivers notification:init and responds to ping + live request broadcasts
    with client.websocket_connect("/api/ws/notifications") as ws:
        init_msg = ws.receive_json()
        assert init_msg["type"] == "notification:init"
        assert init_msg["payload"]["totalCount"] >= 2

        ws.send_json({"type": "ping"})
        pong_msg = ws.receive_json()
        assert pong_msg["type"] == "pong"

        # Creating a new urgent member request persists it and broadcasts a live WebSocket sync
        created = client.post(
            "/api/requests",
            json={
                "member_id": "MEM-2001",
                "book_id": "BK-1001",
                "request_type": "Urgent Hold",
                "urgency": "Critical",
                "title": "Immediate Capstone Reference Hold",
                "notes": "Needed for morning thesis presentation",
            },
        )
        assert created.status_code == 201
        req_id = created.json()["request"]["id"]

        sync_msg = ws.receive_json()
        assert sync_msg["type"] == "notification:sync"
        assert sync_msg["event"] == "request:created"
        assert any(
            n["entity_id"] == req_id and n["category"] == "urgent_request"
            for n in sync_msg["payload"]["notifications"]
        )

    # Mark single notification read & approve the urgent request
    read_res = client.post(f"/api/notifications/req-{req_id}/read")
    assert read_res.status_code == 200
    target = next(n for n in read_res.json()["notifications"] if n["entity_id"] == req_id)
    assert target["is_read"] is True

    approve_res = client.patch(f"/api/requests/{req_id}", json={"status": "Approved"})
    assert approve_res.status_code == 200
    assert approve_res.json()["request"]["status"] == "Approved"

    after_res = client.get("/api/notifications")
    assert after_res.status_code == 200
    assert all(n["entity_id"] != req_id for n in after_res.json()["notifications"])


