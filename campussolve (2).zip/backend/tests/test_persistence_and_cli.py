import csv
import json
from pathlib import Path

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend import persistence, services
from backend.cli import CampusSolveCLI
from backend.database import Base
from backend.models import BookModel, MemberModel, TransactionModel
from backend.validators import ServiceError, SyncError


@pytest.fixture()
def isolated_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    db_path = tmp_path / "isolated.db"
    storage_dir = tmp_path / "sync_data"
    storage_dir.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("CAMPUSSOLVE_STORAGE_DIR", str(storage_dir))

    engine = create_engine(f"sqlite:///{db_path}", connect_args={"check_same_thread": False})
    TestingSession = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    Base.metadata.create_all(bind=engine)
    return engine, TestingSession, storage_dir


def test_sync_creates_all_six_files_and_hydrates_new_db(isolated_env, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    _engine, SessionFactory, storage_dir = isolated_env
    db = SessionFactory()
    try:
        state = persistence.initialize_storage(db, allow_seed=True, storage_dir=storage_dir)
        assert state["status"] == "synchronized"
        for fname in ("books.csv", "books.json", "members.csv", "members.json", "transactions.csv", "transactions.json"):
            assert (storage_dir / fname).exists()

        # Mutate via service: add book and verify immediate CSV/JSON sync
        services.create_book(
            db,
            {
                "id": "BK-7777",
                "isbn": "978-0999888777",
                "title": "Clean Code Sync Test",
                "author": "Robert C. Martin",
                "category": "Computer Science",
                "publisher": "Prentice Hall",
                "publication_year": 2020,
                "total_copies": 4,
            },
            actor="Pytest",
        )
    finally:
        db.close()

    books_json = json.loads((storage_dir / "books.json").read_text(encoding="utf-8"))
    assert any(b["id"] == "BK-7777" for b in books_json)
    with open(storage_dir / "books.csv", encoding="utf-8") as f:
        csv_ids = {r["id"] for r in csv.DictReader(f)}
    assert "BK-7777" in csv_ids

    # Simulate fresh empty SQLite DB recovering from existing CSV/JSON files (no seed needed)
    db2_path = tmp_path / "recovered.db"
    engine2 = create_engine(f"sqlite:///{db2_path}", connect_args={"check_same_thread": False})
    Session2 = sessionmaker(autocommit=False, autoflush=False, bind=engine2)
    Base.metadata.create_all(bind=engine2)
    db2 = Session2()
    try:
        persistence.initialize_storage(db2, allow_seed=False, storage_dir=storage_dir)
        recovered = db2.query(BookModel).filter(BookModel.id == "BK-7777").first()
        assert recovered is not None
        assert recovered.title == "Clean Code Sync Test"
    finally:
        db2.close()


def test_corrupted_json_malformed_csv_and_temp_recovery(isolated_env):
    _engine, SessionFactory, storage_dir = isolated_env

    # Seed valid DB first, then corrupt books.json & members.csv + drop stale .tmp
    db = SessionFactory()
    try:
        persistence.initialize_storage(db, allow_seed=True, storage_dir=storage_dir)
    finally:
        db.close()

    (storage_dir / "books.json").write_text("{corrupted_json!!!", encoding="utf-8")
    (storage_dir / "members.csv").write_text("bad_col1,bad_col2\n1,2\n", encoding="utf-8")
    (storage_dir / "transactions.json").write_text("", encoding="utf-8")
    (storage_dir / ".books.json.9999.tmp").write_text("partial", encoding="utf-8")

    db2 = SessionFactory()
    try:
        state = persistence.initialize_storage(db2, allow_seed=True, storage_dir=storage_dir)
        assert state["status"] == "synchronized"
        assert len(state["warnings"]) >= 3
        backups = list((storage_dir / "backups").glob("corrupted_*.bak"))
        assert len(backups) >= 2
        assert not (storage_dir / ".books.json.9999.tmp").exists()
        # Verify books.json & members.csv were repaired into valid files
        assert isinstance(json.loads((storage_dir / "books.json").read_text(encoding="utf-8")), list)
    finally:
        db2.close()


def test_sync_failure_raises_explicit_error(isolated_env, monkeypatch: pytest.MonkeyPatch):
    _engine, SessionFactory, storage_dir = isolated_env
    db = SessionFactory()
    try:
        persistence.initialize_storage(db, allow_seed=True, storage_dir=storage_dir)

        def fail_write(*_args, **_kwargs):
            raise SyncError("Simulated disk I/O permission failure")

        monkeypatch.setattr(persistence, "_atomic_write_text", fail_write)
        with pytest.raises(SyncError, match="Simulated disk I/O"):
            services.create_book(
                db,
                {
                    "isbn": "978-1111111111",
                    "title": "Should Fail Sync",
                    "author": "Tester",
                    "category": "Computer Science",
                    "publisher": "Press",
                    "publication_year": 2024,
                    "total_copies": 2,
                },
            )
    finally:
        db.close()


def test_empty_dataset_analytics_and_sample_csv_import(isolated_env):
    _engine, SessionFactory, storage_dir = isolated_env
    db = SessionFactory()
    try:
        persistence.initialize_storage(db, allow_seed=False, storage_dir=storage_dir)
        # Empty DB should never raise ZeroDivisionError
        an = services.build_analytics(db, "all", "All")
        assert an["kpis"]["totalBooks"] == 0
        assert an["kpis"]["utilizationRate"] == 0.0
        assert an["kpis"]["avgBooksIssuedPerMonth"] == 0.0
        assert an["kpis"]["totalReturns"] == 0

        # Bulk sample CSV validation catches intentional duplicate + invalid rows
        sample_path = Path(__file__).resolve().parent.parent.parent / "data" / "sample_books_35.csv"
        content = sample_path.read_text(encoding="utf-8")
        prev = services.validate_import(db, "books", "csv", content)
        assert prev["totalRows"] == 38
        assert prev["validRows"] == 37  # On empty DB, 978-0262046305 isn't seeded yet, only BAD-ISBN row is invalid
        assert prev["invalidRows"] == 1
    finally:
        db.close()


def test_cli_interactive_workflow_end_to_end(isolated_env):
    _engine, SessionFactory, storage_dir = isolated_env
    # Pre-initialize seeded storage
    db = SessionFactory()
    try:
        persistence.initialize_storage(db, allow_seed=True, storage_dir=storage_dir)
    finally:
        db.close()

    # Scripted CLI session:
    # 1 -> Dashboard
    # 2 -> Add Book (includes invalid ISBN retry + invalid integer retry!)
    # 4 -> Search Books (search BK-CLI1)
    # 8 -> Issue Book (BK-CLI1 to MEM-2001)
    # 10 -> Warnings
    # 11 -> Executive Summary
    # 12 -> Generate Report (executive / markdown)
    # 0 -> Safe Exit
    scripted_inputs = iter(
        [
            "1",
            "2",
            "BK-CLI1",
            "BADISBN",          # rejected -> re-prompted!
            "978-1234567890",   # valid ISBN
            "CLI Verification Handbook",
            "Ada Engineer",
            "Computer Science",
            "Campus Press",
            "notayear",         # rejected -> re-prompted!
            "2025",
            "CS-CLI-01",
            "3",
            "3",
            "CLI created book",
            "4",
            "CLI Verification",
            "books",
            "title",
            "",
            "",
            "8",
            "BK-CLI1",
            "MEM-2001",
            "2026-11-10",
            "2026-11-24",
            "CLI issue test",
            "10",
            "11",
            "12",
            "executive",
            "markdown",
            "",
            "",
            "0",
        ]
    )
    outputs = []
    cli = CampusSolveCLI(
        session_factory=SessionFactory,
        input_fn=lambda prompt: next(scripted_inputs),
        output_fn=lambda msg="": outputs.append(str(msg)),
    )
    rc = cli.run()
    assert rc == 0

    joined = "\n".join(outputs)
    assert "CAMPUSSOLVE" in joined
    assert "Invalid ISBN" in joined
    assert "Please enter a valid whole number" in joined
    assert "[OK] Book added & synced: BK-CLI1" in joined
    assert "[OK] Issued" in joined
    assert "[OK] Report generated" in joined
    assert "Exiting CampusSolve safely" in joined

    # Verify CLI mutations synced into CSV/JSON files
    books_json = json.loads((storage_dir / "books.json").read_text(encoding="utf-8"))
    bk = next(b for b in books_json if b["id"] == "BK-CLI1")
    assert bk["available_copies"] == 2
