import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { api } from '../services/api';
import type {
  LibraryNotification,
  NotificationsPayload,
  RequestType,
  RequestUrgency,
} from '../types/library';
import { useToast } from './ToastContext';

interface CreateUrgentRequestInput {
  member_id: string;
  book_id?: string | null;
  request_type: RequestType;
  urgency: RequestUrgency;
  title: string;
  notes?: string;
}

interface NotificationContextValue {
  notifications: LibraryNotification[];
  totalCount: number;
  unreadCount: number;
  urgentRequestCount: number;
  dueSoonCount: number;
  overdueCount: number;
  warningThresholdDays: number;
  loading: boolean;
  refresh: () => Promise<void>;
  markRead: (notificationId: string) => Promise<void>;
  markAllRead: () => Promise<void>;
  dismissNotification: (notificationId: string) => Promise<void>;
  resolveMemberRequest: (requestId: string, status: 'Approved' | 'Dismissed') => Promise<void>;
  createUrgentRequest: (payload: CreateUrgentRequestInput) => Promise<void>;
}

const NotificationContext = createContext<NotificationContextValue | null>(null);

function deduplicateById(items: LibraryNotification[]): LibraryNotification[] {
  const seen = new Set<string>();
  const unique: LibraryNotification[] = [];
  for (const item of items) {
    if (!seen.has(item.id)) {
      seen.add(item.id);
      unique.push(item);
    }
  }
  return unique;
}

export function NotificationProvider({ children }: { children: React.ReactNode }) {
  const { notify } = useToast();
  const [payload, setPayload] = useState<NotificationsPayload>({
    notifications: [],
    totalCount: 0,
    unreadCount: 0,
    urgentRequestCount: 0,
    dueSoonCount: 0,
    overdueCount: 0,
    warningThresholdDays: 3,
    generatedAt: '',
  });
  const [loading, setLoading] = useState(true);

  const hydratedRef = useRef(false);
  const seenIdsRef = useRef<Set<string>>(new Set());
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimerRef = useRef<number | null>(null);
  const heartbeatTimerRef = useRef<number | null>(null);
  const attemptRef = useRef(0);
  const unmountedRef = useRef(false);

  const applyAuthoritativePayload = useCallback(
    (incoming: NotificationsPayload, eventName?: string) => {
      const cleanList = deduplicateById(incoming.notifications ?? []);
      const nextPayload: NotificationsPayload = {
        ...incoming,
        notifications: cleanList,
      };

      if (hydratedRef.current) {
        const newlyArrived = cleanList.filter(
          (item) =>
            !item.is_read &&
            !seenIdsRef.current.has(item.id) &&
            (item.category === 'urgent_request' || item.category === 'due_soon' || item.severity === 'critical')
        );
        for (const alert of newlyArrived.slice(0, 2)) {
          notify({
            type:
              alert.severity === 'critical'
                ? 'error'
                : alert.category === 'urgent_request' || alert.severity === 'high'
                  ? 'warning'
                  : 'info',
            title: alert.title,
            description: alert.message,
          });
        }
      } else if (eventName !== undefined || cleanList.length > 0) {
        hydratedRef.current = true;
      }

      const nextSeen = new Set<string>(seenIdsRef.current);
      for (const item of cleanList) {
        nextSeen.add(item.id);
      }
      seenIdsRef.current = nextSeen;
      hydratedRef.current = true;

      setPayload(nextPayload);
      setLoading(false);
    },
    [notify]
  );

  const refresh = useCallback(async () => {
    try {
      const data = await api.getNotifications();
      applyAuthoritativePayload(data, 'http_refresh');
    } catch {
      setLoading(false);
    }
  }, [applyAuthoritativePayload]);

  useEffect(() => {
    unmountedRef.current = false;

    const clearTimers = () => {
      if (reconnectTimerRef.current !== null) {
        window.clearTimeout(reconnectTimerRef.current);
        reconnectTimerRef.current = null;
      }
      if (heartbeatTimerRef.current !== null) {
        window.clearInterval(heartbeatTimerRef.current);
        heartbeatTimerRef.current = null;
      }
    };

    const connectWebSocket = () => {
      if (unmountedRef.current || typeof window === 'undefined') return;
      clearTimers();

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/api/ws/notifications`;

      try {
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          attemptRef.current = 0;
          heartbeatTimerRef.current = window.setInterval(() => {
            if (ws.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify({ type: 'ping' }));
            }
          }, 25000);
        };

        ws.onmessage = (event) => {
          try {
            const msg = JSON.parse(event.data) as {
              type?: string;
              event?: string;
              payload?: NotificationsPayload;
            };
            if ((msg.type === 'notification:init' || msg.type === 'notification:sync') && msg.payload) {
              applyAuthoritativePayload(msg.payload, msg.event);
            }
          } catch {
            // Ignore malformed keepalive frames
          }
        };

        ws.onclose = () => {
          if (heartbeatTimerRef.current !== null) {
            window.clearInterval(heartbeatTimerRef.current);
            heartbeatTimerRef.current = null;
          }
          if (wsRef.current === ws) {
            wsRef.current = null;
          }
          if (!unmountedRef.current) {
            const delay = Math.min(15000, 1000 * Math.pow(2, attemptRef.current));
            attemptRef.current += 1;
            reconnectTimerRef.current = window.setTimeout(connectWebSocket, delay);
          }
        };

        ws.onerror = () => {
          ws.close();
        };
      } catch {
        const delay = Math.min(15000, 1000 * Math.pow(2, attemptRef.current));
        attemptRef.current += 1;
        reconnectTimerRef.current = window.setTimeout(connectWebSocket, delay);
      }
    };

    void refresh();
    connectWebSocket();

    return () => {
      unmountedRef.current = true;
      clearTimers();
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [applyAuthoritativePayload, refresh]);

  const markRead = useCallback(
    async (notificationId: string) => {
      const previous = payload;
      // Optimistic update
      setPayload((prev) => {
        const updated = prev.notifications.map((n) =>
          n.id === notificationId ? { ...n, is_read: true } : n
        );
        return {
          ...prev,
          notifications: updated,
          unreadCount: updated.filter((n) => !n.is_read).length,
        };
      });
      try {
        const next = await api.markNotificationRead(notificationId);
        applyAuthoritativePayload(next);
      } catch {
        setPayload(previous);
      }
    },
    [applyAuthoritativePayload, payload]
  );

  const markAllRead = useCallback(async () => {
    const previous = payload;
    setPayload((prev) => ({
      ...prev,
      notifications: prev.notifications.map((n) => ({ ...n, is_read: true })),
      unreadCount: 0,
    }));
    try {
      const next = await api.markAllNotificationsRead();
      applyAuthoritativePayload(next);
    } catch {
      setPayload(previous);
    }
  }, [applyAuthoritativePayload, payload]);

  const dismissNotification = useCallback(
    async (notificationId: string) => {
      const previous = payload;
      setPayload((prev) => {
        const filtered = prev.notifications.filter((n) => n.id !== notificationId);
        return {
          ...prev,
          notifications: filtered,
          totalCount: filtered.length,
          unreadCount: filtered.filter((n) => !n.is_read).length,
          urgentRequestCount: filtered.filter((n) => n.category === 'urgent_request').length,
          dueSoonCount: filtered.filter((n) => n.category === 'due_soon').length,
          overdueCount: filtered.filter((n) => n.category === 'overdue').length,
        };
      });
      try {
        const next = await api.dismissNotification(notificationId);
        applyAuthoritativePayload(next);
      } catch {
        setPayload(previous);
      }
    },
    [applyAuthoritativePayload, payload]
  );

  const resolveMemberRequest = useCallback(
    async (requestId: string, status: 'Approved' | 'Dismissed') => {
      const notifId = `req-${requestId}`;
      const previous = payload;
      setPayload((prev) => {
        const filtered = prev.notifications.filter((n) => n.id !== notifId);
        return {
          ...prev,
          notifications: filtered,
          totalCount: filtered.length,
          unreadCount: filtered.filter((n) => !n.is_read).length,
          urgentRequestCount: filtered.filter((n) => n.category === 'urgent_request').length,
        };
      });
      try {
        await api.updateMemberRequest(requestId, { status });
        notify({
          type: status === 'Approved' ? 'success' : 'info',
          title: `Request ${status}`,
          description: `Member request ${requestId} marked as ${status.toLowerCase()}.`,
        });
        await refresh();
      } catch {
        setPayload(previous);
        notify({
          type: 'error',
          title: 'Action Failed',
          description: `Unable to update member request ${requestId}.`,
        });
      }
    },
    [notify, payload, refresh]
  );

  const createUrgentRequest = useCallback(
    async (input: CreateUrgentRequestInput) => {
      await api.createMemberRequest(input);
      await refresh();
    },
    [refresh]
  );

  return (
    <NotificationContext.Provider
      value={{
        notifications: payload.notifications,
        totalCount: payload.totalCount,
        unreadCount: payload.unreadCount,
        urgentRequestCount: payload.urgentRequestCount,
        dueSoonCount: payload.dueSoonCount,
        overdueCount: payload.overdueCount,
        warningThresholdDays: payload.warningThresholdDays,
        loading,
        refresh,
        markRead,
        markAllRead,
        dismissNotification,
        resolveMemberRequest,
        createUrgentRequest,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const ctx = useContext(NotificationContext);
  if (!ctx) {
    throw new Error('useNotifications must be used inside NotificationProvider');
  }
  return ctx;
}
