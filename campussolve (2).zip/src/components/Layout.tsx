import React, { useEffect, useMemo, useState } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import {
  Activity,
  AlertTriangle,
  ArrowLeftRight,
  BarChart3,
  Bell,
  BookCheck,
  BookOpen,
  BookPlus,
  CalendarClock,
  Check,
  CheckCheck,
  FileSpreadsheet,
  FileText,
  LayoutDashboard,
  Menu,
  Moon,
  Plus,
  Search,
  Settings,
  Sparkles,
  Sun,
  Users,
  X,
  Zap,
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useNotifications } from '../context/NotificationContext';
import { useToast } from '../context/ToastContext';
import { api, ApiClientError } from '../services/api';
import type {
  Book,
  LibraryNotification,
  Member,
  RequestType,
  RequestUrgency,
} from '../types/library';
import { Button, Modal } from './ui/Primitives';

interface NavItem {
  to: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  group: string;
}

const NAV_ITEMS: NavItem[] = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, group: 'Overview' },
  { to: '/books', label: 'Books', icon: BookOpen, group: 'Catalogue & Members' },
  { to: '/members', label: 'Members', icon: Users, group: 'Catalogue & Members' },
  { to: '/issue', label: 'Issue Books', icon: BookPlus, group: 'Circulation' },
  { to: '/return', label: 'Return Books', icon: BookCheck, group: 'Circulation' },
  { to: '/transactions', label: 'Transactions', icon: ArrowLeftRight, group: 'Circulation' },
  { to: '/overdue', label: 'Overdue Monitoring', icon: AlertTriangle, group: 'Circulation' },
  { to: '/search', label: 'Smart Search', icon: Sparkles, group: 'Intelligence' },
  { to: '/analytics', label: 'Analytics', icon: BarChart3, group: 'Intelligence' },
  { to: '/reports', label: 'Reports', icon: FileText, group: 'Intelligence' },
  { to: '/import-export', label: 'Import / Export', icon: FileSpreadsheet, group: 'Operations' },
  { to: '/activity', label: 'Activity Centre', icon: Activity, group: 'Operations' },
  { to: '/settings', label: 'Settings', icon: Settings, group: 'Operations' },
];

const ROUTE_TITLES: Record<string, string> = {
  '/': 'Dashboard',
  '/books': 'Books',
  '/members': 'Members',
  '/issue': 'Issue Books',
  '/return': 'Return Books',
  '/transactions': 'Transactions',
  '/overdue': 'Overdue Monitoring',
  '/search': 'Smart Search',
  '/analytics': 'Analytics',
  '/reports': 'Reports',
  '/import-export': 'Import / Export',
  '/activity': 'Activity Centre',
  '/settings': 'Settings',
};

type NotificationTab = 'all' | 'due' | 'requests';

function formatRelativeTime(iso: string): string {
  const ts = Date.parse(iso);
  if (Number.isNaN(ts)) return '';
  const diffSec = Math.max(0, Math.floor((Date.now() - ts) / 1000));
  if (diffSec < 60) return 'Just now';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  const diffDay = Math.floor(diffHr / 24);
  if (diffDay < 7) return `${diffDay}d ago`;
  return new Date(ts).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export function Layout({ children }: { children: React.ReactNode }) {
  const { theme, toggleTheme } = useTheme();
  const { notify } = useToast();
  const {
    notifications,
    totalCount,
    unreadCount,
    urgentRequestCount,
    dueSoonCount,
    overdueCount,
    markRead,
    markAllRead,
    dismissNotification,
    resolveMemberRequest,
    createUrgentRequest,
  } = useNotifications();

  const location = useLocation();
  const navigate = useNavigate();

  const [mobileOpen, setMobileOpen] = useState(false);
  const [globalQuery, setGlobalQuery] = useState('');
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifTab, setNotifTab] = useState<NotificationTab>('all');
  const [avatarFailed, setAvatarFailed] = useState(false);

  // Urgent Member Request Modal state
  const [reqModalOpen, setReqModalOpen] = useState(false);
  const [membersList, setMembersList] = useState<Member[]>([]);
  const [booksList, setBooksList] = useState<Book[]>([]);
  const [reqMemberId, setReqMemberId] = useState('');
  const [reqBookId, setReqBookId] = useState('');
  const [reqType, setReqType] = useState<RequestType>('Urgent Hold');
  const [reqUrgency, setReqUrgency] = useState<RequestUrgency>('Critical');
  const [reqTitle, setReqTitle] = useState('');
  const [reqNotes, setReqNotes] = useState('');
  const [reqSubmitting, setReqSubmitting] = useState(false);

  const currentTitle =
    ROUTE_TITLES[location.pathname] ??
    (location.pathname.startsWith('/books/')
      ? 'Book Detail'
      : location.pathname.startsWith('/members/')
        ? 'Member Profile'
        : 'Workspace');

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (!reqModalOpen || (membersList.length > 0 && booksList.length > 0)) return;
    let active = true;
    Promise.all([api.getMembers(), api.getBooks()])
      .then(([mRes, bRes]) => {
        if (!active) return;
        setMembersList(mRes.members);
        setBooksList(bRes.books);
        if (mRes.members.length > 0 && !reqMemberId) {
          setReqMemberId(mRes.members[0].id);
        }
      })
      .catch(() => {
        // Error surfaced on submit if directories fail
      });
    return () => {
      active = false;
    };
  }, [reqModalOpen, membersList.length, booksList.length, reqMemberId]);

  const handleGlobalSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (globalQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(globalQuery.trim())}`);
    } else {
      navigate('/search');
    }
  };

  const filteredNotifications = useMemo(() => {
    if (notifTab === 'due') {
      return notifications.filter((n) => n.category === 'due_soon' || n.category === 'overdue');
    }
    if (notifTab === 'requests') {
      return notifications.filter((n) => n.category === 'urgent_request');
    }
    return notifications;
  }, [notifications, notifTab]);

  const hasUrgentUnread = useMemo(
    () =>
      notifications.some(
        (n) => !n.is_read && (n.severity === 'critical' || n.category === 'urgent_request')
      ),
    [notifications]
  );

  const handleNotificationClick = (item: LibraryNotification) => {
    if (!item.is_read) {
      void markRead(item.id);
    }
    setNotifOpen(false);
    navigate(item.action_url);
  };

  const handleCreateRequestSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reqMemberId || !reqTitle.trim()) {
      notify({
        type: 'warning',
        title: 'Incomplete Request',
        description: 'Please select a member and enter a request summary.',
      });
      return;
    }
    setReqSubmitting(true);
    try {
      await createUrgentRequest({
        member_id: reqMemberId,
        book_id: reqBookId || null,
        request_type: reqType,
        urgency: reqUrgency,
        title: reqTitle.trim(),
        notes: reqNotes.trim(),
      });
      setReqModalOpen(false);
      setReqTitle('');
      setReqNotes('');
      setReqBookId('');
      setNotifTab('requests');
      setNotifOpen(true);
    } catch (err) {
      notify({
        type: 'error',
        title: 'Unable to Log Request',
        description: err instanceof ApiClientError ? err.message : 'Server rejected request payload.',
      });
    } finally {
      setReqSubmitting(false);
    }
  };

  const groups = ['Overview', 'Catalogue & Members', 'Circulation', 'Intelligence', 'Operations'];

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-[#F1F5F9] dark:bg-[#0B1224] border-r border-slate-200 dark:border-slate-800/80 select-none">
      {/* Brand Lockup */}
      <div className="h-16 px-5 flex items-center justify-between border-b border-slate-200 dark:border-slate-800/80 shrink-0">
        <NavLink to="/" className="flex items-center gap-3 min-w-0">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-[#4388FF] to-[#925CFF] flex items-center justify-center text-white shadow-sm shrink-0">
            <BookOpen className="h-4.5 w-4.5" />
          </div>
          <div className="min-w-0">
            <span className="block font-display font-bold text-base tracking-tight text-slate-900 dark:text-[#F8FAFC] truncate">
              CampusSolve
            </span>
          </div>
        </NavLink>
        <button
          type="button"
          onClick={() => setMobileOpen(false)}
          aria-label="Close navigation menu"
          className="lg:hidden p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-5" aria-label="Primary Sidebar">
        {groups.map((group) => {
          const items = NAV_ITEMS.filter((i) => i.group === group);
          return (
            <div key={group}>
              <p className="px-3 mb-1.5 text-[11px] font-medium text-slate-500 dark:text-slate-400">
                {group}
              </p>
              <div className="space-y-0.5">
                {items.map((item) => {
                  const Icon = item.icon;
                  const isActive =
                    item.to === '/'
                      ? location.pathname === '/'
                      : location.pathname === item.to || location.pathname.startsWith(`${item.to}/`);

                  return (
                    <NavLink
                      key={item.to}
                      to={item.to}
                      className={`relative flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                        isActive
                          ? 'text-[#4388FF] dark:text-[#F8FAFC]'
                          : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-[#F8FAFC] hover:bg-slate-200/60 dark:hover:bg-[#101A31]'
                      }`}
                    >
                      {isActive && (
                        <motion.div
                          layoutId="sidebar-active-pill"
                          transition={{ type: 'spring', stiffness: 420, damping: 34 }}
                          className="absolute inset-0 rounded-lg bg-white dark:bg-[#101A31] border border-slate-200/80 dark:border-[#4388FF]/30 shadow-xs"
                        />
                      )}
                      <Icon
                        className={`h-4 w-4 relative z-10 shrink-0 ${
                          isActive ? 'text-[#4388FF]' : ''
                        }`}
                      />
                      <span className="relative z-10 truncate">{item.label}</span>
                    </NavLink>
                  );
                })}
              </div>
            </div>
          );
        })}
      </nav>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-[#F8FAFC] dark:bg-[#080D1B] text-slate-900 dark:text-[#F8FAFC]">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 sticky top-0 h-screen">
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs"
            onClick={() => setMobileOpen(false)}
          />
          <aside className="relative z-50 w-64 h-full">
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Navigation Bar */}
        <header className="sticky top-0 z-30 h-16 px-4 sm:px-6 flex items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800/80 bg-white/85 dark:bg-[#080D1B]/85 backdrop-blur-md">
          {/* Left: Mobile Trigger + Breadcrumbs */}
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              aria-label="Open navigation menu"
              className="lg:hidden p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#101A31]"
            >
              <Menu className="h-5 w-5" />
            </button>

            <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-sm min-w-0">
              <NavLink
                to="/"
                className="text-slate-500 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-slate-100 hidden sm:inline whitespace-nowrap"
              >
                CampusSolve
              </NavLink>
              <span className="text-slate-400 hidden sm:inline" aria-hidden="true">
                /
              </span>
              <span className="font-display font-semibold text-slate-900 dark:text-[#F8FAFC] truncate">
                {currentTitle}
              </span>
            </nav>
          </div>

          {/* Right: Search, Notifications, Theme, Profile, Quick Action */}
          <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
            <form onSubmit={handleGlobalSearchSubmit} className="hidden md:block relative w-60 lg:w-72">
              <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="search"
                value={globalQuery}
                onChange={(e) => setGlobalQuery(e.target.value)}
                placeholder="Search books, ISBN, members..."
                className="w-full h-9 pl-9 pr-3 text-sm rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#101A31] text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
              />
            </form>

            {/* Real-Time Notification Centre */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setNotifOpen((o) => !o)}
                aria-label="Open notification centre"
                aria-expanded={notifOpen}
                className="relative h-9 w-9 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] flex items-center justify-center text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
              >
                <Bell className="h-4 w-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 h-4 min-w-[16px] px-1 rounded-full bg-[#FF6485] text-[10px] font-mono font-semibold text-white flex items-center justify-center shadow-sm">
                    {hasUrgentUnread && (
                      <span
                        aria-hidden="true"
                        className="absolute inset-0 rounded-full bg-[#FF6485] animate-ping opacity-55"
                      />
                    )}
                    <span className="relative">{unreadCount}</span>
                  </span>
                )}
              </button>

              {notifOpen && (
                <>
                  <div className="fixed inset-0 z-30" onClick={() => setNotifOpen(false)} />
                  <div
                    role="region"
                    aria-label="Library Notifications"
                    className="absolute right-0 mt-2 w-[21rem] sm:w-[27rem] z-40 rounded-xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-[#101A31] shadow-2xl overflow-hidden"
                  >
                    {/* Header */}
                    <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <span className="text-sm font-display font-semibold text-slate-900 dark:text-slate-100 block">
                          Library Notifications
                        </span>
                        <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                          {unreadCount} unread · {totalCount} active
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        {unreadCount > 0 && (
                          <button
                            type="button"
                            onClick={() => void markAllRead()}
                            className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#172544] transition-colors cursor-pointer"
                          >
                            <CheckCheck className="h-3.5 w-3.5 text-[#10D9A0]" />
                            Mark all read
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => {
                            setNotifOpen(false);
                            setReqModalOpen(true);
                          }}
                          className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium bg-[#4388FF]/12 text-[#4388FF] hover:bg-[#4388FF]/20 transition-colors cursor-pointer"
                        >
                          <Plus className="h-3 w-3" />
                          Urgent Request
                        </button>
                      </div>
                    </div>

                    {/* Filter Tabs */}
                    <div className="px-3 py-2 border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-[#0B1224]/70 flex items-center gap-1">
                      {(
                        [
                          { id: 'all', label: `All (${totalCount})` },
                          { id: 'due', label: `Due Dates (${dueSoonCount + overdueCount})` },
                          { id: 'requests', label: `Urgent Requests (${urgentRequestCount})` },
                        ] as const
                      ).map((tab) => (
                        <button
                          key={tab.id}
                          type="button"
                          onClick={() => setNotifTab(tab.id)}
                          className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer whitespace-nowrap ${
                            notifTab === tab.id
                              ? 'bg-white dark:bg-[#101A31] text-slate-900 dark:text-white shadow-xs border border-slate-200/80 dark:border-slate-700'
                              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>

                    {/* Notification List */}
                    <div className="max-h-96 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/80">
                      {filteredNotifications.map((item) => {
                        const isUrgentReq = item.category === 'urgent_request';
                        const isDueSoon = item.category === 'due_soon';
                        const isOverdue = item.category === 'overdue';

                        const accentCls =
                          item.severity === 'critical'
                            ? 'text-[#FF6485]'
                            : item.severity === 'high'
                              ? 'text-[#FFAD5A]'
                              : isDueSoon
                                ? 'text-[#22D3EE]'
                                : 'text-[#4388FF]';

                        const iconBgCls =
                          item.severity === 'critical'
                            ? 'bg-[#FF6485]/12 text-[#FF6485]'
                            : item.severity === 'high'
                              ? 'bg-[#FFAD5A]/12 text-[#FFAD5A]'
                              : isDueSoon
                                ? 'bg-[#22D3EE]/12 text-[#22D3EE]'
                                : 'bg-[#4388FF]/12 text-[#4388FF]';

                        const categoryLabel = isUrgentReq
                          ? item.request_type || 'Urgent Request'
                          : isDueSoon
                            ? item.days_remaining === 0
                              ? 'Due Today'
                              : item.days_remaining === 1
                                ? 'Due Tomorrow'
                                : `Due in ${item.days_remaining}d`
                            : isOverdue
                              ? 'Overdue Loan'
                              : item.category === 'inventory'
                                ? 'Inventory Alert'
                                : 'Borrow Limit';

                        return (
                          <div
                            key={item.id}
                            onClick={() => handleNotificationClick(item)}
                            role="button"
                            tabIndex={0}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' || e.key === ' ') {
                                e.preventDefault();
                                handleNotificationClick(item);
                              }
                            }}
                            className={`px-4 py-3 hover:bg-slate-50 dark:hover:bg-[#172544]/60 transition-colors cursor-pointer ${
                              !item.is_read ? 'bg-[#4388FF]/[0.03] dark:bg-[#4388FF]/[0.05]' : ''
                            }`}
                          >
                            <div className="flex items-start gap-3">
                              <div className={`h-8 w-8 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${iconBgCls}`}>
                                {isUrgentReq ? (
                                  <Zap className="h-4 w-4" />
                                ) : isDueSoon ? (
                                  <CalendarClock className="h-4 w-4" />
                                ) : isOverdue ? (
                                  <AlertTriangle className="h-4 w-4" />
                                ) : item.category === 'inventory' ? (
                                  <BookOpen className="h-4 w-4" />
                                ) : (
                                  <Users className="h-4 w-4" />
                                )}
                              </div>

                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between gap-2">
                                  <span className={`text-[11px] font-semibold truncate ${accentCls}`}>
                                    {categoryLabel}
                                  </span>
                                  <div className="flex items-center gap-1.5 shrink-0">
                                    <span className="text-[10px] font-mono text-slate-400">
                                      {formatRelativeTime(item.created_at) || item.entity_id}
                                    </span>
                                    {!item.is_read && (
                                      <span
                                        aria-label="Unread"
                                        className="h-2 w-2 rounded-full bg-[#4388FF] shrink-0"
                                      />
                                    )}
                                  </div>
                                </div>

                                <p className="text-xs font-semibold text-slate-900 dark:text-slate-100 mt-0.5 line-clamp-1">
                                  {item.title}
                                </p>
                                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2 leading-relaxed">
                                  {item.message}
                                </p>

                                {/* Inline Actions */}
                                <div
                                  className="mt-2 flex items-center gap-2"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  {isUrgentReq ? (
                                    <>
                                      <button
                                        type="button"
                                        onClick={() => void resolveMemberRequest(item.entity_id, 'Approved')}
                                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#10D9A0]/15 text-emerald-700 dark:text-[#10D9A0] hover:bg-[#10D9A0]/25 text-[11px] font-medium transition-colors cursor-pointer"
                                      >
                                        <Check className="h-3 w-3" />
                                        Approve
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => void resolveMemberRequest(item.entity_id, 'Dismissed')}
                                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 text-[11px] font-medium transition-colors cursor-pointer"
                                      >
                                        <X className="h-3 w-3" />
                                        Dismiss
                                      </button>
                                    </>
                                  ) : (
                                    <>
                                      {!item.is_read && (
                                        <button
                                          type="button"
                                          onClick={() => void markRead(item.id)}
                                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white text-[11px] font-medium transition-colors cursor-pointer"
                                        >
                                          <Check className="h-3 w-3" />
                                          Mark read
                                        </button>
                                      )}
                                      <button
                                        type="button"
                                        onClick={() => void dismissNotification(item.id)}
                                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-[11px] transition-colors cursor-pointer"
                                      >
                                        Dismiss
                                      </button>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}

                      {filteredNotifications.length === 0 && (
                        <div className="p-8 text-center text-xs text-slate-500 dark:text-slate-400">
                          {notifTab === 'due'
                            ? 'No upcoming book due dates or overdue loans right now.'
                            : notifTab === 'requests'
                              ? 'No pending urgent member requests.'
                              : 'All library notifications are cleared.'}
                        </div>
                      )}
                    </div>

                    {/* Footer */}
                    <div className="px-4 py-2.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-[#0B1224]/70 flex items-center justify-between text-[11px]">
                      <button
                        type="button"
                        onClick={() => {
                          setNotifOpen(false);
                          navigate('/overdue');
                        }}
                        className="font-medium text-[#4388FF] hover:underline cursor-pointer"
                      >
                        Overdue Queue
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setNotifOpen(false);
                          navigate('/transactions');
                        }}
                        className="font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                      >
                        View All Loans
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Theme Switcher */}
            <button
              type="button"
              onClick={toggleTheme}
              aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
              title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} Mode`}
              className="h-9 w-9 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] flex items-center justify-center text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
            >
              {theme === 'dark' ? <Sun className="h-4 w-4 text-[#FFAD5A]" /> : <Moon className="h-4 w-4 text-[#4388FF]" />}
            </button>

            {/* User Profile */}
            <NavLink
              to="/settings"
              className="hidden sm:flex items-center gap-2.5 pl-2 pr-3 py-1 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
            >
              {!avatarFailed ? (
                <img
                  src="/src/assets/images/avatar_chief_librarian_1795149379212.jpg"
                  alt="Dr. Eleanor Vance"
                  referrerPolicy="no-referrer"
                  onError={() => setAvatarFailed(true)}
                  className="h-7 w-7 rounded-md object-cover shrink-0"
                />
              ) : (
                <div className="h-7 w-7 rounded-md bg-[#4388FF]/20 text-[#4388FF] flex items-center justify-center text-xs font-bold">
                  EV
                </div>
              )}
              <div className="text-left leading-tight">
                <span className="block text-xs font-semibold text-slate-900 dark:text-slate-100 whitespace-nowrap">
                  Dr. Eleanor Vance
                </span>
                <span className="block text-[10px] text-slate-500 dark:text-slate-400 whitespace-nowrap">
                  Chief Librarian
                </span>
              </div>
            </NavLink>

            {/* Primary Quick Action */}
            <Button size="sm" onClick={() => navigate('/issue')}>
              <Plus className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Issue Book</span>
            </Button>
          </div>
        </header>

        {/* Page Viewport */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1600px] w-full mx-auto">
          {children}
        </main>
      </div>

      {/* Log Urgent Member Request Modal */}
      <Modal
        open={reqModalOpen}
        onClose={() => setReqModalOpen(false)}
        title="Log Urgent Member Request"
        subtitle="Creates a server-tracked member request and broadcasts a real-time alert to connected librarians."
      >
        <form onSubmit={handleCreateRequestSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Member *
              </label>
              <select
                value={reqMemberId}
                onChange={(e) => setReqMemberId(e.target.value)}
                required
                className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0B1224] text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
              >
                <option value="">Select member...</option>
                {membersList.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.full_name} ({m.id})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Related Book (Optional)
              </label>
              <select
                value={reqBookId}
                onChange={(e) => setReqBookId(e.target.value)}
                className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0B1224] text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
              >
                <option value="">None / General desk request</option>
                {booksList.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.title} ({b.id})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Request Type
              </label>
              <select
                value={reqType}
                onChange={(e) => setReqType(e.target.value as RequestType)}
                className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0B1224] text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
              >
                <option value="Urgent Hold">Urgent Hold</option>
                <option value="Loan Extension">Loan Extension</option>
                <option value="Course Reserve">Course Reserve</option>
                <option value="Replacement">Replacement</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Urgency Priority
              </label>
              <select
                value={reqUrgency}
                onChange={(e) => setReqUrgency(e.target.value as RequestUrgency)}
                className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0B1224] text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
              >
                <option value="Critical">Critical (Immediate)</option>
                <option value="Urgent">Urgent (Same Day)</option>
                <option value="Normal">Normal</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Request Summary *
            </label>
            <input
              type="text"
              value={reqTitle}
              onChange={(e) => setReqTitle(e.target.value)}
              placeholder="e.g. Same-day desk hold for thesis defense reference"
              required
              maxLength={160}
              className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0B1224] text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Desk Notes
            </label>
            <textarea
              rows={3}
              value={reqNotes}
              onChange={(e) => setReqNotes(e.target.value)}
              placeholder="Provide member context, pickup window, or justification..."
              maxLength={500}
              className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0B1224] text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
            />
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <Button type="button" variant="outline" onClick={() => setReqModalOpen(false)} disabled={reqSubmitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={reqSubmitting}>
              {reqSubmitting ? 'Broadcasting...' : 'Broadcast Urgent Request'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
