import { useEffect } from 'react';
import { motion } from 'motion/react';

export function SplashScreen({ onComplete }: { onComplete: () => void }) {
  useEffect(() => {
    const prefersReduced =
      typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const delay = prefersReduced ? 150 : 950;
    const timer = window.setTimeout(onComplete, delay);
    return () => window.clearTimeout(timer);
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.35, ease: 'easeOut' }}
      onClick={onComplete}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#080D1B] text-[#F8FAFC] overflow-hidden cursor-pointer select-none"
    >
      {/* Ambient radial lighting */}
      <div
        aria-hidden="true"
        className="absolute w-[540px] h-[540px] rounded-full bg-[#4388FF]/15 blur-[130px] -top-32 -left-24 pointer-events-none"
      />
      <div
        aria-hidden="true"
        className="absolute w-[480px] h-[480px] rounded-full bg-[#925CFF]/15 blur-[130px] -bottom-32 -right-24 pointer-events-none"
      />

      <motion.div
        initial={{ opacity: 0, y: 12, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
        className="relative z-10 flex flex-col items-center text-center px-6"
      >
        <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-[#4388FF] via-[#6B74FF] to-[#925CFF] p-[1px] shadow-2xl shadow-[#4388FF]/25 mb-6">
          <div className="h-full w-full rounded-[15px] bg-[#0B1224] flex items-center justify-center">
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none" aria-hidden="true">
              <path
                d="M6 7.5C6 6.67157 6.67157 6 7.5 6H14.5C15.3284 6 16 6.67157 16 7.5V25.5C16 24.6716 15.3284 24 14.5 24H7.5C6.67157 24 6 23.3284 6 22.5V7.5Z"
                stroke="#4388FF"
                strokeWidth="2.2"
              />
              <path
                d="M16 7.5C16 6.67157 16.6716 6 17.5 6H24.5C25.3284 6 26 6.67157 26 7.5V22.5C26 23.3284 25.3284 24 24.5 24H17.5C16.6716 24 16 24.6716 16 25.5V7.5Z"
                stroke="#22D3EE"
                strokeWidth="2.2"
              />
              <path d="M9.5 11H12.5M19.5 11H22.5M9.5 15H12.5M19.5 15H22.5" stroke="#925CFF" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </div>
        </div>

        <h1 className="font-display text-3xl sm:text-4xl font-extrabold tracking-tight bg-gradient-to-r from-[#F8FAFC] via-[#E2E8F0] to-[#94A3B8] bg-clip-text text-transparent">
          CAMPUSSOLVE
        </h1>
        <p className="mt-2 text-sm sm:text-base font-medium text-[#22D3EE]">
          Smart Library Management Ecosystem
        </p>
        <p className="mt-1.5 text-xs text-slate-400 tracking-wide">
          Discover. Organize. Manage. Transform.
        </p>

        <div className="mt-7 w-44 h-1 rounded-full bg-slate-800 overflow-hidden">
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: '0%' }}
            transition={{ duration: 0.75, ease: [0.16, 1, 0.3, 1] }}
            className="h-full w-full bg-gradient-to-r from-[#4388FF] via-[#22D3EE] to-[#925CFF]"
          />
        </div>
      </motion.div>
    </motion.div>
  );
}
