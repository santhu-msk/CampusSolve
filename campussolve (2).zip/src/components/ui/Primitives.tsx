import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  AlertCircle,
  AlertTriangle,
  BookOpen,
  CheckCircle2,
  Clock,
  RefreshCw,
  X,
  XCircle,
} from 'lucide-react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
}

export function Button({
  variant = 'primary',
  size = 'md',
  className = '',
  children,
  ...props
}: ButtonProps) {
  const base =
    'inline-flex items-center justify-center gap-2 font-medium rounded-lg transition-all duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4388FF] disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer';
  const sizes = {
    sm: 'px-3 py-1.5 text-xs min-h-[34px]',
    md: 'px-4 py-2 text-sm min-h-[40px]',
    lg: 'px-5 py-2.5 text-sm min-h-[44px]',
  };
  const variants = {
    primary:
      'bg-[#4388FF] hover:bg-[#3377F0] text-white shadow-sm shadow-[#4388FF]/20',
    secondary:
      'bg-slate-100 hover:bg-slate-200 text-slate-900 dark:bg-[#172544] dark:hover:bg-[#1E3058] dark:text-slate-100',
    outline:
      'border border-slate-200 dark:border-slate-700/80 bg-transparent hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-700 dark:text-slate-200',
    ghost:
      'bg-transparent hover:bg-slate-100 dark:hover:bg-slate-800/60 text-slate-600 dark:text-slate-300',
    danger:
      'bg-[#E11D48] hover:bg-[#BE123C] text-white shadow-sm shadow-[#E11D48]/20',
  };

  return (
    <button className={`${base} ${sizes[size]} ${variants[variant]} ${className}`} {...props}>
      {children}
    </button>
  );
}

export function StatusIndicator({
  status,
}: {
  status:
    | 'Available'
    | 'Low Stock'
    | 'Out of Stock'
    | 'Active'
    | 'Suspended'
    | 'Inactive'
    | 'Issued'
    | 'Returned'
    | 'Overdue'
    | 'Warning'
    | 'High'
    | 'Critical'
    | string;
}) {
  const styles: Record<string, { cls: string; icon: React.ReactNode }> = {
    Available: {
      cls: 'text-emerald-700 dark:text-[#10D9A0] bg-emerald-500/10 border-emerald-500/25',
      icon: <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />,
    },
    Active: {
      cls: 'text-emerald-700 dark:text-[#10D9A0] bg-emerald-500/10 border-emerald-500/25',
      icon: <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />,
    },
    Returned: {
      cls: 'text-emerald-700 dark:text-[#10D9A0] bg-emerald-500/10 border-emerald-500/25',
      icon: <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />,
    },
    'Low Stock': {
      cls: 'text-amber-700 dark:text-[#FFAD5A] bg-amber-500/10 border-amber-500/25',
      icon: <AlertTriangle className="h-3.5 w-3.5 shrink-0" />,
    },
    Warning: {
      cls: 'text-amber-700 dark:text-[#FFAD5A] bg-amber-500/10 border-amber-500/25',
      icon: <AlertTriangle className="h-3.5 w-3.5 shrink-0" />,
    },
    Issued: {
      cls: 'text-blue-700 dark:text-[#4388FF] bg-blue-500/10 border-blue-500/25',
      icon: <Clock className="h-3.5 w-3.5 shrink-0" />,
    },
    High: {
      cls: 'text-orange-700 dark:text-[#FFAD5A] bg-orange-500/15 border-orange-500/30',
      icon: <AlertTriangle className="h-3.5 w-3.5 shrink-0" />,
    },
    'Out of Stock': {
      cls: 'text-rose-700 dark:text-[#FF6485] bg-rose-500/10 border-rose-500/25',
      icon: <XCircle className="h-3.5 w-3.5 shrink-0" />,
    },
    Overdue: {
      cls: 'text-rose-700 dark:text-[#FF6485] bg-rose-500/10 border-rose-500/25',
      icon: <AlertCircle className="h-3.5 w-3.5 shrink-0" />,
    },
    Critical: {
      cls: 'text-rose-700 dark:text-[#FF6485] bg-rose-500/15 border-rose-500/35',
      icon: <AlertCircle className="h-3.5 w-3.5 shrink-0" />,
    },
    Suspended: {
      cls: 'text-rose-700 dark:text-[#FF6485] bg-rose-500/10 border-rose-500/25',
      icon: <XCircle className="h-3.5 w-3.5 shrink-0" />,
    },
    Inactive: {
      cls: 'text-slate-600 dark:text-slate-400 bg-slate-500/10 border-slate-500/20',
      icon: <Clock className="h-3.5 w-3.5 shrink-0" />,
    },
  };

  const entry = styles[status] ?? {
    cls: 'text-slate-700 dark:text-slate-300 bg-slate-500/10 border-slate-500/20',
    icon: <Clock className="h-3.5 w-3.5 shrink-0" />,
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-xs font-medium whitespace-nowrap shrink-0 ${entry.cls}`}
    >
      {entry.icon}
      <span>{status}</span>
    </span>
  );
}

export function AnimatedCounter({
  value,
  decimals = 0,
  prefix = '',
  suffix = '',
}: {
  value: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
}) {
  const [display, setDisplay] = useState(value);

  useEffect(() => {
    const prefersReduced =
      typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced) {
      setDisplay(value);
      return;
    }

    let frame = 0;
    const start = performance.now();
    const from = 0;
    const duration = 550;

    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setDisplay(from + (value - from) * eased);
      if (t < 1) {
        frame = requestAnimationFrame(tick);
      } else {
        setDisplay(value);
      }
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [value]);

  const formatted =
    decimals > 0
      ? display.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })
      : Math.round(display).toLocaleString('en-US');

  return (
    <span className="tabular-nums font-mono">
      {prefix}
      {formatted}
      {suffix}
    </span>
  );
}

export function BookCover({
  title,
  author,
  category,
  isbn,
  coverImage,
  size = 'md',
}: {
  title: string;
  author: string;
  category: string;
  isbn?: string;
  coverImage?: string | null;
  size?: 'sm' | 'md' | 'lg';
}) {
  const [imgError, setImgError] = useState(false);

  const paletteMap: Record<string, string> = {
    'Computer Science': 'from-[#0F1E42] via-[#152B5B] to-[#0B142B] border-[#4388FF]/30',
    'Natural Sciences': 'from-[#0B2538] via-[#10384B] to-[#081724] border-[#10D9A0]/30',
    Mathematics: 'from-[#1D1540] via-[#2B1D5C] to-[#120D29] border-[#925CFF]/30',
    'Humanities & Arts': 'from-[#2A1B3D] via-[#3A224F] to-[#180E24] border-[#FFAD5A]/30',
    'Economics & Law': 'from-[#2B1726] via-[#3F1F34] to-[#170B14] border-[#FF6485]/30',
    Engineering: 'from-[#11243C] via-[#183558] to-[#0B1626] border-[#22D3EE]/30',
  };

  const accentBarMap: Record<string, string> = {
    'Computer Science': 'bg-[#4388FF]',
    'Natural Sciences': 'bg-[#10D9A0]',
    Mathematics: 'bg-[#925CFF]',
    'Humanities & Arts': 'bg-[#FFAD5A]',
    'Economics & Law': 'bg-[#FF6485]',
    Engineering: 'bg-[#22D3EE]',
  };

  const sizeClass =
    size === 'sm'
      ? 'w-10 h-14 rounded-md'
      : size === 'lg'
        ? 'w-44 h-60 rounded-xl p-4'
        : 'w-28 h-40 rounded-lg p-3';

  if (coverImage && !imgError) {
    return (
      <div className={`relative overflow-hidden border border-slate-200 dark:border-slate-700/60 shrink-0 ${sizeClass}`}>
        <img
          src={coverImage}
          alt={`Cover art for ${title}`}
          referrerPolicy="no-referrer"
          onError={() => setImgError(true)}
          className="absolute inset-0 w-full h-full object-cover"
        />
        {size !== 'sm' && (
          <div className="relative z-10 h-full flex flex-col justify-end bg-gradient-to-t from-black/85 via-black/35 to-transparent -m-3 p-3">
            <p className="text-[11px] font-semibold text-white leading-tight line-clamp-2">{title}</p>
            <p className="text-[10px] text-slate-300 mt-0.5 truncate">{author}</p>
          </div>
        )}
      </div>
    );
  }

  const gradientCls = paletteMap[category] ?? 'from-[#101A31] via-[#19284B] to-[#0A1120] border-[#4388FF]/30';
  const barCls = accentBarMap[category] ?? 'bg-[#4388FF]';

  if (size === 'sm') {
    return (
      <div
        className={`relative flex items-center justify-center bg-gradient-to-br ${gradientCls} border shrink-0 ${sizeClass}`}
        aria-label={`${title} cover`}
      >
        <span className={`absolute left-0 top-0 bottom-0 w-1 rounded-l-md ${barCls}`} />
        <BookOpen className="h-4 w-4 text-slate-200/90" />
      </div>
    );
  }

  return (
    <div
      className={`relative flex flex-col justify-between bg-gradient-to-br ${gradientCls} border shadow-sm overflow-hidden shrink-0 ${sizeClass}`}
    >
      <div className={`absolute left-0 top-0 bottom-0 w-1.5 ${barCls}`} />
      <div className="pl-2">
        <p className="text-[9px] tracking-wider uppercase text-slate-300/80 font-mono truncate">{category}</p>
        <p className={`mt-1.5 font-display font-bold text-white leading-snug ${size === 'lg' ? 'text-sm line-clamp-4' : 'text-xs line-clamp-3'}`}>
          {title}
        </p>
      </div>
      <div className="pl-2 pt-2 border-t border-white/10">
        <p className="text-[10px] text-slate-200/90 truncate">{author}</p>
        {isbn && size === 'lg' && (
          <p className="text-[9px] font-mono text-slate-400 mt-1 truncate">{isbn}</p>
        )}
      </div>
    </div>
  );
}

export function Modal({
  open,
  onClose,
  title,
  subtitle,
  maxWidth = 'max-w-xl',
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  maxWidth?: string;
  children: React.ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 8 }}
            transition={{ duration: 0.16 }}
            role="dialog"
            aria-modal="true"
            className={`relative z-10 w-full ${maxWidth} max-h-[90vh] flex flex-col rounded-2xl border border-slate-200 dark:border-slate-700/70 bg-white dark:bg-[#101A31] shadow-2xl overflow-hidden`}
          >
            <div className="flex items-start justify-between gap-4 px-6 py-4 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h2 className="text-lg font-display font-semibold text-slate-900 dark:text-slate-50">{title}</h2>
                {subtitle && (
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{subtitle}</p>
                )}
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="Close dialog"
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="p-6 overflow-y-auto">{children}</div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  description,
  confirmLabel = 'Confirm Delete',
  loading = false,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  description: string;
  confirmLabel?: string;
  loading?: boolean;
}) {
  return (
    <Modal open={open} onClose={onClose} title={title} maxWidth="max-w-md">
      <div className="space-y-5">
        <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">{description}</p>
        <div className="flex items-center justify-end gap-3 pt-2">
          <Button variant="outline" onClick={onClose} disabled={loading}>
            Cancel
          </Button>
          <Button variant="danger" onClick={onConfirm} disabled={loading}>
            {loading ? 'Processing...' : confirmLabel}
          </Button>
        </div>
      </div>
    </Modal>
  );
}

export function TableSkeleton({ rows = 6, cols = 6 }: { rows?: number; cols?: number }) {
  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] overflow-hidden">
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4">
        <div className="h-9 w-64 rounded-lg bg-slate-200 dark:bg-slate-800 animate-pulse" />
        <div className="h-9 w-36 rounded-lg bg-slate-200 dark:bg-slate-800 animate-pulse" />
      </div>
      <div className="divide-y divide-slate-200 dark:divide-slate-800">
        {Array.from({ length: rows }).map((_, rIdx) => (
          <div key={rIdx} className="px-4 py-3.5 grid gap-4" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}>
            {Array.from({ length: cols }).map((__, cIdx) => (
              <div key={cIdx} className="h-4 rounded bg-slate-200 dark:bg-slate-800/80 animate-pulse" />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="rounded-xl border border-dashed border-slate-300 dark:border-slate-700/80 bg-white/60 dark:bg-[#101A31]/60 p-10 text-center flex flex-col items-center">
      <div className="h-12 w-12 rounded-xl bg-slate-100 dark:bg-slate-800/80 flex items-center justify-center text-slate-500 dark:text-slate-400 mb-3">
        {icon}
      </div>
      <h3 className="text-base font-display font-semibold text-slate-900 dark:text-slate-100">{title}</h3>
      <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-md">{description}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function ErrorPanel({
  message,
  onRetry,
}: {
  message: string;
  onRetry?: () => void;
}) {
  return (
    <div className="rounded-xl border border-rose-500/30 bg-rose-500/5 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div className="flex items-start gap-3">
        <AlertCircle className="h-5 w-5 text-[#FF6485] shrink-0 mt-0.5" />
        <div>
          <h3 className="text-sm font-semibold text-rose-700 dark:text-[#FF6485]">Backend Connection Error</h3>
          <p className="text-sm text-slate-600 dark:text-slate-300 mt-0.5">{message}</p>
        </div>
      </div>
      {onRetry && (
        <Button variant="outline" size="sm" onClick={onRetry}>
          <RefreshCw className="h-3.5 w-3.5" />
          Retry
        </Button>
      )}
    </div>
  );
}
