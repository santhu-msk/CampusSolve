import type {
  ActivityLog,
  AnalyticsPayload,
  Book,
  ImportPreviewResponse,
  LibrarySettings,
  Member,
  MemberRequest,
  NotificationsPayload,
  OverdueRecord,
  RequestType,
  RequestUrgency,
  SearchResponse,
  SyncStatus,
  TransactionRecord,
  WarningsPayload,
} from '../types/library';

const API_BASE = (import.meta.env.VITE_API_BASE_URL as string | undefined) ?? '';

export class ApiClientError extends Error {
  status: number;
  details?: unknown;
  isNetworkError: boolean;

  constructor(message: string, status = 500, details?: unknown, isNetworkError = false) {
    super(message);
    this.name = 'ApiClientError';
    this.status = status;
    this.details = details;
    this.isNetworkError = isNetworkError;
  }
}

async function request<T>(endpoint: string, init?: RequestInit): Promise<T> {
  const url = `${API_BASE}${endpoint}`;
  let response: Response;
  try {
    response = await fetch(url, {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        ...(init?.headers ?? {}),
      },
    });
  } catch {
    throw new ApiClientError(
      'Unable to reach CampusSolve backend server. Please verify the API service is running.',
      0,
      null,
      true
    );
  }

  let data: unknown = null;
  try {
    data = await response.json();
  } catch {
    data = null;
  }

  if (!response.ok) {
    const errObj = (typeof data === 'object' && data !== null ? data : {}) as Record<string, unknown>;
    const message =
      typeof errObj.error === 'string'
        ? errObj.error
        : typeof errObj.detail === 'string'
          ? errObj.detail
          : `Request failed with HTTP ${response.status}`;
    throw new ApiClientError(message, response.status, errObj.details);
  }

  return data as T;
}

export const api = {
  health: () =>
    request<{ status: string; database: string; booksCount: number; syncStatus?: string }>('/api/health'),
  getSyncStatus: () => request<SyncStatus>('/api/sync/status'),

  // Books
  getBooks: (params?: { search?: string; category?: string; availability?: string }) => {
    const qs = new URLSearchParams();
    if (params?.search) qs.set('search', params.search);
    if (params?.category && params.category !== 'All') qs.set('category', params.category);
    if (params?.availability && params.availability !== 'All') qs.set('availability', params.availability);
    const suffix = qs.toString() ? `?${qs.toString()}` : '';
    return request<{ books: Book[]; total: number }>(`/api/books${suffix}`);
  },
  getBook: (id: string) =>
    request<{ book: Book; transactions: TransactionRecord[] }>(`/api/books/${encodeURIComponent(id)}`),
  createBook: (payload: Partial<Book>) =>
    request<{ book: Book }>('/api/books', { method: 'POST', body: JSON.stringify(payload) }),
  updateBook: (id: string, payload: Partial<Book>) =>
    request<{ book: Book }>(`/api/books/${encodeURIComponent(id)}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  deleteBook: (id: string) =>
    request<{ deleted: boolean; id: string }>(`/api/books/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    }),

  // Members
  getMembers: (params?: { search?: string; status?: string; department?: string }) => {
    const qs = new URLSearchParams();
    if (params?.search) qs.set('search', params.search);
    if (params?.status && params.status !== 'All') qs.set('status', params.status);
    if (params?.department && params.department !== 'All') qs.set('department', params.department);
    const suffix = qs.toString() ? `?${qs.toString()}` : '';
    return request<{ members: Member[]; total: number }>(`/api/members${suffix}`);
  },
  getMember: (id: string) =>
    request<{ member: Member; transactions: TransactionRecord[] }>(`/api/members/${encodeURIComponent(id)}`),
  createMember: (payload: Partial<Member>) =>
    request<{ member: Member }>('/api/members', { method: 'POST', body: JSON.stringify(payload) }),
  updateMember: (id: string, payload: Partial<Member>) =>
    request<{ member: Member }>(`/api/members/${encodeURIComponent(id)}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  deleteMember: (id: string) =>
    request<{ deleted: boolean; id: string }>(`/api/members/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    }),

  // Issues & Returns
  getActiveIssues: () => request<{ issues: TransactionRecord[] }>('/api/issues'),
  issueBook: (payload: {
    member_id: string;
    book_id: string;
    issue_date: string;
    due_date: string;
    notes?: string;
  }) => request<{ transaction: TransactionRecord }>('/api/issues', { method: 'POST', body: JSON.stringify(payload) }),

  getRecentReturns: () => request<{ returns: TransactionRecord[] }>('/api/returns'),
  returnBook: (payload: {
    transaction_id: string;
    return_date: string;
    waive_fine?: boolean;
    notes?: string;
  }) =>
    request<{ transaction: TransactionRecord; overdue_days: number; fine_amount: number }>('/api/returns', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  // Transactions & Unified Search
  getTransactions: (params?: {
    search?: string;
    status?: string;
    start_date?: string;
    end_date?: string;
    sort_by?: string;
    sort_dir?: string;
  }) => {
    const qs = new URLSearchParams();
    if (params?.search) qs.set('search', params.search);
    if (params?.status && params.status !== 'All') qs.set('status', params.status);
    if (params?.start_date) qs.set('start_date', params.start_date);
    if (params?.end_date) qs.set('end_date', params.end_date);
    if (params?.sort_by) qs.set('sort_by', params.sort_by);
    if (params?.sort_dir) qs.set('sort_dir', params.sort_dir);
    const suffix = qs.toString() ? `?${qs.toString()}` : '';
    return request<{ transactions: TransactionRecord[]; total: number }>(`/api/transactions${suffix}`);
  },

  searchRecords: (params?: {
    q?: string;
    scope?: string;
    category?: string;
    status?: string;
    start_date?: string;
    end_date?: string;
    sort_by?: string;
    sort_dir?: string;
    page?: number;
    page_size?: number;
  }) => {
    const qs = new URLSearchParams();
    if (params?.q) qs.set('q', params.q);
    if (params?.scope) qs.set('scope', params.scope);
    if (params?.category && params.category !== 'All') qs.set('category', params.category);
    if (params?.status && params.status !== 'All') qs.set('status', params.status);
    if (params?.start_date) qs.set('start_date', params.start_date);
    if (params?.end_date) qs.set('end_date', params.end_date);
    if (params?.sort_by) qs.set('sort_by', params.sort_by);
    if (params?.sort_dir) qs.set('sort_dir', params.sort_dir);
    if (params?.page) qs.set('page', String(params.page));
    if (params?.page_size) qs.set('page_size', String(params.page_size));
    const suffix = qs.toString() ? `?${qs.toString()}` : '';
    return request<SearchResponse>(`/api/search${suffix}`);
  },

  // Overdue & Threshold Warnings
  getOverdue: (params?: { min_days?: number; severity?: string; search?: string }) => {
    const qs = new URLSearchParams();
    if (params?.min_days !== undefined) qs.set('min_days', String(params.min_days));
    if (params?.severity && params.severity !== 'All') qs.set('severity', params.severity);
    if (params?.search) qs.set('search', params.search);
    const suffix = qs.toString() ? `?${qs.toString()}` : '';
    return request<{
      records: OverdueRecord[];
      summary: {
        totalOverdue: number;
        criticalCount: number;
        totalFines: number;
        dailyFineRate: number;
        warningThresholdDays: number;
        criticalOverdueDays: number;
      };
    }>(`/api/overdue${suffix}`);
  },
  getWarnings: () => request<WarningsPayload>('/api/warnings'),

  // Analytics
  getAnalytics: (params?: { range?: string; category?: string }) => {
    const qs = new URLSearchParams();
    if (params?.range) qs.set('range', params.range);
    if (params?.category && params.category !== 'All') qs.set('category', params.category);
    const suffix = qs.toString() ? `?${qs.toString()}` : '';
    return request<AnalyticsPayload>(`/api/analytics${suffix}`);
  },

  // Reports
  generateReport: (params: {
    type: string;
    format: 'json' | 'csv' | 'markdown' | 'txt';
    start_date?: string;
    end_date?: string;
  }) => {
    const qs = new URLSearchParams();
    qs.set('type', params.type);
    qs.set('format', params.format);
    if (params.start_date) qs.set('start_date', params.start_date);
    if (params.end_date) qs.set('end_date', params.end_date);
    return request<{
      title: string;
      reportType: string;
      format: string;
      generatedAt: string;
      periodLabel: string;
      institution: string;
      library: string;
      summaryMetrics: Record<string, unknown>;
      rows: Array<Record<string, unknown>>;
      content: string;
    }>(`/api/reports?${qs.toString()}`);
  },

  // Import & Export
  getImportSample: (entity: 'books' | 'members') =>
    request<{ entity: 'books' | 'members'; format: 'csv' | 'json'; filename: string; content: string }>(
      `/api/import/sample?entity=${encodeURIComponent(entity)}`
    ),
  previewImport: (payload: { entity: 'books' | 'members'; format: 'csv' | 'json'; content: string }) =>
    request<ImportPreviewResponse>('/api/import/preview', { method: 'POST', body: JSON.stringify(payload) }),
  commitImport: (payload: { entity: 'books' | 'members'; format: 'csv' | 'json'; content: string }) =>
    request<{ importedCount: number; skippedCount: number; preview: ImportPreviewResponse }>('/api/import', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  exportData: (entity: string, format: 'csv' | 'json') =>
    request<{ entity: string; format: string; count: number; content: string }>(
      `/api/export?entity=${encodeURIComponent(entity)}&format=${encodeURIComponent(format)}`
    ),

  // Settings & Backup
  getSettings: () => request<{ settings: LibrarySettings }>('/api/settings'),
  updateSettings: (payload: LibrarySettings) =>
    request<{ settings: LibrarySettings }>('/api/settings', { method: 'PUT', body: JSON.stringify(payload) }),
  downloadBackup: () => request<Record<string, unknown>>('/api/backup'),

  // Activity
  getActivity: (params?: { action_type?: string; search?: string; limit?: number }) => {
    const qs = new URLSearchParams();
    if (params?.action_type && params.action_type !== 'All') qs.set('action_type', params.action_type);
    if (params?.search) qs.set('search', params.search);
    if (params?.limit) qs.set('limit', String(params.limit));
    const suffix = qs.toString() ? `?${qs.toString()}` : '';
    return request<{ activities: ActivityLog[] }>(`/api/activity${suffix}`);
  },

  // Real-Time Notifications & Urgent Member Requests
  getNotifications: () => request<NotificationsPayload>('/api/notifications'),
  markNotificationRead: (notificationId: string) =>
    request<NotificationsPayload>(`/api/notifications/${encodeURIComponent(notificationId)}/read`, {
      method: 'POST',
    }),
  markAllNotificationsRead: () =>
    request<NotificationsPayload>('/api/notifications/read-all', {
      method: 'POST',
    }),
  dismissNotification: (notificationId: string) =>
    request<NotificationsPayload>(`/api/notifications/${encodeURIComponent(notificationId)}/dismiss`, {
      method: 'POST',
    }),
  getMemberRequests: (params?: { status?: string; urgency?: string }) => {
    const qs = new URLSearchParams();
    if (params?.status && params.status !== 'All') qs.set('status', params.status);
    if (params?.urgency && params.urgency !== 'All') qs.set('urgency', params.urgency);
    const suffix = qs.toString() ? `?${qs.toString()}` : '';
    return request<{ requests: MemberRequest[]; total: number }>(`/api/requests${suffix}`);
  },
  createMemberRequest: (payload: {
    member_id: string;
    book_id?: string | null;
    request_type: RequestType;
    urgency: RequestUrgency;
    title: string;
    notes?: string;
  }) =>
    request<{ request: MemberRequest }>('/api/requests', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateMemberRequest: (
    requestId: string,
    payload: { status?: string; urgency?: string; notes?: string }
  ) =>
    request<{ request: MemberRequest }>(`/api/requests/${encodeURIComponent(requestId)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),
};
