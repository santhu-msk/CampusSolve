export type AvailabilityStatus = 'Available' | 'Low Stock' | 'Out of Stock';
export type MemberType = 'Student' | 'Faculty' | 'Researcher' | 'Staff';
export type MemberStatus = 'Active' | 'Suspended' | 'Inactive';
export type TransactionStatus = 'Issued' | 'Returned' | 'Overdue';

export interface Book {
  id: string;
  isbn: string;
  title: string;
  author: string;
  category: string;
  publisher: string;
  publication_year: number;
  shelf_location: string;
  description: string;
  cover_image: string | null;
  total_copies: number;
  available_copies: number;
  availability_status: AvailabilityStatus;
  active_issues_count?: number;
  created_at: string;
  updated_at: string;
}

export interface Member {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  department: string;
  course: string;
  member_type: MemberType;
  status: MemberStatus;
  max_borrow_limit: number;
  active_issues_count: number;
  total_borrows_count: number;
  overdue_count: number;
  joined_at: string;
  updated_at: string;
}

export interface TransactionRecord {
  id: string;
  book_id: string;
  member_id: string;
  book_title?: string;
  book_isbn?: string;
  book_author?: string;
  book_category?: string;
  member_name?: string;
  member_email?: string;
  member_department?: string;
  issue_date: string;
  due_date: string;
  return_date: string | null;
  status: TransactionStatus;
  days_overdue: number;
  fine_amount: number;
  notes: string;
  created_at: string;
  updated_at: string;
}

export interface OverdueRecord extends TransactionRecord {
  severity: 'Warning' | 'High' | 'Critical';
  estimated_fine: number;
  member_phone?: string;
}

export interface ActivityLog {
  id: number;
  action_type: string;
  entity_type: string;
  entity_id: string;
  summary: string;
  actor: string;
  created_at: string;
}

export interface LibrarySettings {
  library_name: string;
  institution_name: string;
  default_loan_days: number;
  daily_fine_rate: number;
  warning_threshold_days: number;
  critical_overdue_days: number;
  default_borrow_limit: number;
  currency_symbol: string;
}

export interface DashboardKPIs {
  totalBooks: number;
  totalCopies: number;
  availableCopies: number;
  issuedBooks: number;
  totalMembers: number;
  activeMembers: number;
  overdueBooks: number;
  totalTransactions: number;
  totalReturns?: number;
  avgBooksIssuedPerMonth?: number;
  utilizationRate: number;
  totalFinesOutstanding: number;
}

export interface AnalyticsPayload {
  kpis: DashboardKPIs;
  monthlyTrends: Array<{
    month: string;
    label: string;
    issued: number;
    returned: number;
    overdue: number;
  }>;
  availabilityDistribution: Array<{
    name: string;
    value: number;
    color: string;
  }>;
  categoryDistribution: Array<{
    category: string;
    titles: number;
    totalCopies: number;
    availableCopies: number;
    borrowCount: number;
  }>;
  topBooks: Array<{
    id: string;
    title: string;
    author: string;
    category: string;
    borrowCount: number;
    availableCopies: number;
    totalCopies: number;
  }>;
  activeMembers: Array<{
    id: string;
    full_name: string;
    department: string;
    member_type: string;
    totalBorrows: number;
    activeIssues: number;
    overdueCount: number;
  }>;
  overdueBreakdown: Array<{
    bucket: string;
    count: number;
    totalFine: number;
  }>;
  membershipGrowth: Array<{
    month: string;
    label: string;
    newMembers: number;
    cumulativeMembers: number;
  }>;
}

export interface ImportValidationRow {
  rowNumber: number;
  raw: Record<string, unknown>;
  valid: boolean;
  isDuplicate: boolean;
  errors: string[];
  normalized: Record<string, unknown>;
}

export interface ImportPreviewResponse {
  entity: 'books' | 'members';
  format: 'csv' | 'json';
  totalRows: number;
  validRows: number;
  duplicateRows: number;
  invalidRows: number;
  detectedColumns: string[];
  rows: ImportValidationRow[];
}

export interface SyncStatus {
  status: string;
  last_synced_at: string | null;
  storage_dir?: string;
  warnings: string[];
  files: Record<string, number>;
}

export interface ApproachingDueRecord extends TransactionRecord {
  days_remaining: number;
}

export interface AnomalousBookRecord extends Book {
  anomaly: string;
}

export interface WarningsPayload {
  thresholds: {
    warning_threshold_days: number;
    critical_overdue_days: number;
    daily_fine_rate: number;
  };
  totalAlerts: number;
  overdue: OverdueRecord[];
  approachingDue: ApproachingDueRecord[];
  unavailableBooks: Book[];
  lowStockBooks: Book[];
  anomalousQuantities: AnomalousBookRecord[];
  borrowLimitBreaches: Member[];
}

export interface SearchResponse {
  query: string;
  scope: string;
  counts: {
    total: number;
    books: number;
    members: number;
    transactions: number;
  };
  page: number;
  pageSize: number;
  books: Book[];
  members: Member[];
  transactions: TransactionRecord[];
}

export type RequestType = 'Urgent Hold' | 'Loan Extension' | 'Course Reserve' | 'Replacement';
export type RequestUrgency = 'Critical' | 'Urgent' | 'Normal';
export type RequestStatus = 'Pending' | 'In Review' | 'Approved' | 'Dismissed';

export interface MemberRequest {
  id: string;
  member_id: string;
  member_name: string;
  member_email: string | null;
  member_department: string | null;
  book_id: string | null;
  book_title: string | null;
  request_type: RequestType;
  urgency: RequestUrgency;
  title: string;
  notes: string;
  status: RequestStatus;
  created_at: string;
  updated_at: string;
}

export type NotificationCategory =
  | 'due_soon'
  | 'urgent_request'
  | 'overdue'
  | 'inventory'
  | 'member_limit';

export type NotificationSeverity = 'critical' | 'high' | 'warning' | 'info';

export interface LibraryNotification {
  id: string;
  category: NotificationCategory;
  severity: NotificationSeverity;
  title: string;
  message: string;
  entity_type: 'Transaction' | 'MemberRequest' | 'Book' | 'Member';
  entity_id: string;
  book_id?: string | null;
  book_title?: string | null;
  member_id?: string | null;
  member_name?: string | null;
  due_date?: string | null;
  days_remaining?: number | null;
  request_type?: RequestType | null;
  request_status?: RequestStatus | null;
  action_url: string;
  is_read: boolean;
  is_dismissed: boolean;
  created_at: string;
}

export interface NotificationsPayload {
  notifications: LibraryNotification[];
  totalCount: number;
  unreadCount: number;
  urgentRequestCount: number;
  dueSoonCount: number;
  overdueCount: number;
  warningThresholdDays: number;
  generatedAt: string;
}

