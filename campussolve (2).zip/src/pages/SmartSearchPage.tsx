import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeftRight, BookOpen, ChevronLeft, ChevronRight, Search, Users } from 'lucide-react';
import { api, ApiClientError } from '../services/api';
import type { Book, Member, TransactionRecord } from '../types/library';
import { BookCover, Button, EmptyState, ErrorPanel, StatusIndicator, TableSkeleton } from '../components/ui/Primitives';

const PAGE_SIZE = 12;

export function SmartSearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  const [query, setQuery] = useState(searchParams.get('q') ?? '');
  const [scope, setScope] = useState<'all' | 'books' | 'members' | 'transactions'>('all');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [sortBy, setSortBy] = useState<'relevance' | 'title' | 'date' | 'id'>('relevance');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [page, setPage] = useState(1);

  const [books, setBooks] = useState<Book[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [transactions, setTransactions] = useState<TransactionRecord[]>([]);
  const [allCategories, setAllCategories] = useState<string[]>(['All']);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadCategories = useCallback(async () => {
    try {
      const bRes = await api.getBooks();
      setAllCategories(['All', ...Array.from(new Set(bRes.books.map((b) => b.category)))]);
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    loadCategories();
  }, [loadCategories]);

  const runSearch = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.searchRecords({
        q: query.trim() || undefined,
        scope,
        category: categoryFilter !== 'All' ? categoryFilter : undefined,
        status: statusFilter !== 'All' ? statusFilter : undefined,
        start_date: startDate || undefined,
        end_date: endDate || undefined,
        sort_by: sortBy,
        sort_dir: sortDir,
      });
      setBooks(res.books);
      setMembers(res.members);
      setTransactions(res.transactions);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'Unable to execute record search.');
    } finally {
      setLoading(false);
    }
  }, [query, scope, categoryFilter, statusFilter, startDate, endDate, sortBy, sortDir]);

  useEffect(() => {
    runSearch();
  }, [runSearch]);

  useEffect(() => {
    const qParam = searchParams.get('q');
    if (qParam !== null) setQuery(qParam);
  }, [searchParams]);

  useEffect(() => {
    setPage(1);
  }, [query, scope, categoryFilter, statusFilter, startDate, endDate, sortBy, sortDir]);

  const totalMatches = books.length + members.length + transactions.length;

  const activeTotal = useMemo(() => {
    if (scope === 'books') return books.length;
    if (scope === 'members') return members.length;
    if (scope === 'transactions') return transactions.length;
    return Math.max(books.length, members.length, transactions.length);
  }, [scope, books.length, members.length, transactions.length]);

  const totalPages = Math.max(1, Math.ceil(activeTotal / PAGE_SIZE));
  const sliceStart = (page - 1) * PAGE_SIZE;
  const pagedBooks = scope === 'books' ? books.slice(sliceStart, sliceStart + PAGE_SIZE) : books.slice(0, 6);
  const pagedMembers = scope === 'members' ? members.slice(sliceStart, sliceStart + PAGE_SIZE) : members.slice(0, 6);
  const pagedTransactions =
    scope === 'transactions' ? transactions.slice(sliceStart, sliceStart + PAGE_SIZE) : transactions.slice(0, 8);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-[#F8FAFC]">
          Smart Search Across Ecosystem
        </h1>
        <p className="text-sm text-slate-500 dark:text-[#94A3B8] mt-0.5">
          Unified query, filtering, sorting, and pagination across book catalogue, ISBNs, member profiles, and circulation records.
        </p>
      </div>

      {/* Search Bar & Scope Filters */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5 space-y-4">
        <div className="relative">
          <Search className="h-5 w-5 text-[#4388FF] absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSearchParams(e.target.value ? { q: e.target.value } : {}, { replace: true });
            }}
            placeholder="Search by title, ISBN, author, member name, ID (BK-1001, MEM-2001, TXN-3027)..."
            className="w-full h-12 pl-12 pr-4 text-sm sm:text-base rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
          />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="inline-flex p-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-[#0B1224]">
            {(
              [
                { id: 'all', label: `All (${totalMatches})` },
                { id: 'books', label: `Books (${books.length})` },
                { id: 'members', label: `Members (${members.length})` },
                { id: 'transactions', label: `Transactions (${transactions.length})` },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setScope(tab.id)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                  scope === tab.id
                    ? 'bg-white dark:bg-[#101A31] text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              aria-label="Category filter"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="h-9 px-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-700 dark:text-slate-200"
            >
              {allCategories.map((c) => (
                <option key={c} value={c}>
                  {c === 'All' ? 'All Book Categories' : c}
                </option>
              ))}
            </select>

            <select
              aria-label="Status filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="h-9 px-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-700 dark:text-slate-200"
            >
              <option value="All">All Statuses</option>
              <option value="Available">Available (Book)</option>
              <option value="Low Stock">Low Stock (Book)</option>
              <option value="Out of Stock">Out of Stock (Book)</option>
              <option value="Active">Active (Member)</option>
              <option value="Suspended">Suspended (Member)</option>
              <option value="Issued">Issued (Transaction)</option>
              <option value="Overdue">Overdue (Transaction)</option>
              <option value="Returned">Returned (Transaction)</option>
            </select>

            <select
              aria-label="Sort field"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
              className="h-9 px-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-700 dark:text-slate-200"
            >
              <option value="relevance">Sort: Relevance</option>
              <option value="title">Sort: Title / Name</option>
              <option value="date">Sort: Date</option>
              <option value="id">Sort: ID</option>
            </select>

            <select
              aria-label="Sort direction"
              value={sortDir}
              onChange={(e) => setSortDir(e.target.value as typeof sortDir)}
              className="h-9 px-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-700 dark:text-slate-200"
            >
              <option value="asc">Ascending</option>
              <option value="desc">Descending</option>
            </select>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 dark:border-slate-800/80 text-xs">
          <div className="flex flex-wrap items-center gap-2 text-slate-500 dark:text-slate-400">
            <span>Date Range:</span>
            <input
              type="date"
              aria-label="Search start date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="h-8 px-2.5 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-700 dark:text-slate-200"
            />
            <span>to</span>
            <input
              type="date"
              aria-label="Search end date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="h-8 px-2.5 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-700 dark:text-slate-200"
            />
            {(query || categoryFilter !== 'All' || statusFilter !== 'All' || startDate || endDate) && (
              <button
                type="button"
                onClick={() => {
                  setQuery('');
                  setCategoryFilter('All');
                  setStatusFilter('All');
                  setStartDate('');
                  setEndDate('');
                  setSearchParams({}, { replace: true });
                }}
                className="text-[#4388FF] hover:underline font-medium px-2 cursor-pointer"
              >
                Reset Filters
              </button>
            )}
          </div>
          <span className="font-mono text-slate-500 dark:text-slate-400">
            {totalMatches} total match{totalMatches === 1 ? '' : 'es'}
          </span>
        </div>
      </div>

      {error && <ErrorPanel message={error} onRetry={runSearch} />}
      {loading ? (
        <TableSkeleton rows={6} cols={4} />
      ) : totalMatches === 0 ? (
        <EmptyState
          icon={<Search className="h-6 w-6" />}
          title="No records matched your query"
          description="Try searching with a partial title, author surname, ISBN, department, or record ID."
          action={
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setQuery('');
                setCategoryFilter('All');
                setStatusFilter('All');
                setStartDate('');
                setEndDate('');
              }}
            >
              Clear Search
            </Button>
          }
        />
      ) : (
        <div className="space-y-6">
          {(scope === 'all' || scope === 'books') && pagedBooks.length > 0 && (
            <section className="space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <BookOpen className="h-4 w-4 text-[#4388FF]" />
                  Books ({books.length})
                </h2>
                {scope === 'all' && books.length > 6 && (
                  <button
                    type="button"
                    onClick={() => setScope('books')}
                    className="text-xs font-medium text-[#4388FF] hover:underline cursor-pointer"
                  >
                    View all {books.length} books
                  </button>
                )}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {pagedBooks.map((b) => (
                  <div
                    key={b.id}
                    onClick={() => navigate(`/books/${b.id}`)}
                    className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-4 flex gap-4 hover:border-[#4388FF]/50 transition-colors cursor-pointer"
                  >
                    <BookCover
                      title={b.title}
                      author={b.author}
                      category={b.category}
                      coverImage={b.cover_image}
                      size="sm"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-mono text-[#4388FF]">{b.id}</span>
                        <StatusIndicator status={b.availability_status} />
                      </div>
                      <p className="mt-1 font-semibold text-sm text-slate-900 dark:text-slate-100 truncate">
                        {b.title}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {b.author} · {b.available_copies}/{b.total_copies} avail
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {(scope === 'all' || scope === 'members') && pagedMembers.length > 0 && (
            <section className="space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <Users className="h-4 w-4 text-[#10D9A0]" />
                  Members ({members.length})
                </h2>
                {scope === 'all' && members.length > 6 && (
                  <button
                    type="button"
                    onClick={() => setScope('members')}
                    className="text-xs font-medium text-[#4388FF] hover:underline cursor-pointer"
                  >
                    View all {members.length} members
                  </button>
                )}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {pagedMembers.map((m) => (
                  <div
                    key={m.id}
                    onClick={() => navigate(`/members/${m.id}`)}
                    className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-4 flex items-center justify-between gap-3 hover:border-[#4388FF]/50 transition-colors cursor-pointer"
                  >
                    <div className="min-w-0">
                      <p className="text-xs font-mono text-[#4388FF]">{m.id} · {m.member_type}</p>
                      <p className="font-semibold text-sm text-slate-900 dark:text-slate-100 truncate">
                        {m.full_name}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {m.department} · {m.course}
                      </p>
                    </div>
                    <StatusIndicator status={m.status} />
                  </div>
                ))}
              </div>
            </section>
          )}

          {(scope === 'all' || scope === 'transactions') && pagedTransactions.length > 0 && (
            <section className="space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <ArrowLeftRight className="h-4 w-4 text-[#925CFF]" />
                  Transactions ({transactions.length})
                </h2>
                {scope === 'all' && transactions.length > 8 && (
                  <button
                    type="button"
                    onClick={() => setScope('transactions')}
                    className="text-xs font-medium text-[#4388FF] hover:underline cursor-pointer"
                  >
                    View all {transactions.length} transactions
                  </button>
                )}
              </div>
              <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] divide-y divide-slate-100 dark:divide-slate-800/80">
                {pagedTransactions.map((t) => (
                  <div
                    key={t.id}
                    className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <p className="text-xs font-mono text-[#4388FF]">
                        {t.id} · Issued {t.issue_date} · Due {t.due_date}
                      </p>
                      <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">
                        {t.book_title} — {t.member_name}
                      </p>
                    </div>
                    <StatusIndicator status={t.status} />
                  </div>
                ))}
              </div>
            </section>
          )}

          {scope !== 'all' && totalPages > 1 && (
            <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-500">
              <span className="font-mono">
                Page {page} of {totalPages}
              </span>
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  disabled={page <= 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                >
                  <ChevronLeft className="h-3.5 w-3.5" />
                  Prev
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  disabled={page >= totalPages}
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                >
                  Next
                  <ChevronRight className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
