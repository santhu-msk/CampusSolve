import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { AlertCircle, BookCheck, CheckCircle2 } from 'lucide-react';
import { api, ApiClientError } from '../services/api';
import { useToast } from '../context/ToastContext';
import type { TransactionRecord } from '../types/library';
import { Button, ErrorPanel, StatusIndicator } from '../components/ui/Primitives';

export function ReturnBookPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { notify } = useToast();

  const today = new Date().toISOString().slice(0, 10);

  const [activeIssues, setActiveIssues] = useState<TransactionRecord[]>([]);
  const [recentReturns, setRecentReturns] = useState<TransactionRecord[]>([]);
  const [dailyFineRate, setDailyFineRate] = useState(2.5);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [txnId, setTxnId] = useState(searchParams.get('txnId') ?? '');
  const [returnDate, setReturnDate] = useState(today);
  const [waiveFine, setWaiveFine] = useState(false);
  const [notes, setNotes] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [lastReturned, setLastReturned] = useState<{
    transaction: TransactionRecord;
    overdue_days: number;
    fine_amount: number;
  } | null>(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const [iRes, rRes, sRes] = await Promise.all([
        api.getActiveIssues(),
        api.getRecentReturns(),
        api.getSettings(),
      ]);
      setActiveIssues(iRes.issues);
      setRecentReturns(rRes.returns);
      setDailyFineRate(sRes.settings.daily_fine_rate ?? 2.5);
    } catch (err) {
      setLoadError(err instanceof ApiClientError ? err.message : 'Unable to load active loans.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const selectedTxn = useMemo(
    () => activeIssues.find((t) => t.id.toUpperCase() === txnId.trim().toUpperCase()) ?? null,
    [activeIssues, txnId]
  );

  const previewOverdueDays = useMemo(() => {
    if (!selectedTxn || !returnDate) return 0;
    const dueMs = Date.parse(`${selectedTxn.due_date}T00:00:00Z`);
    const retMs = Date.parse(`${returnDate}T00:00:00Z`);
    if (Number.isNaN(dueMs) || Number.isNaN(retMs)) return 0;
    return Math.max(0, Math.floor((retMs - dueMs) / (1000 * 60 * 60 * 24)));
  }, [selectedTxn, returnDate]);

  const previewFine = waiveFine ? 0 : Number((previewOverdueDays * dailyFineRate).toFixed(2));

  const handleReturnSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);
    setLastReturned(null);

    if (!txnId.trim()) {
      setSubmitError('Please enter or select an active Transaction ID.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await api.returnBook({
        transaction_id: txnId.trim().toUpperCase(),
        return_date: returnDate,
        waive_fine: waiveFine,
        notes,
      });
      setLastReturned(res);
      notify({
        type: 'success',
        title: `Returned · ${res.transaction.id}`,
        description:
          res.overdue_days > 0
            ? `${res.overdue_days} day(s) overdue · Fine recorded: $${res.fine_amount.toFixed(2)}`
            : 'Returned on time. Available copy count updated.',
      });
      setTxnId('');
      setNotes('');
      setWaiveFine(false);
      await loadData();
    } catch (err) {
      const msg = err instanceof ApiClientError ? err.message : 'Failed to process return.';
      setSubmitError(msg);
      notify({ type: 'error', title: 'Return rejected', description: msg });
    } finally {
      setSubmitting(false);
    }
  };

  if (loadError) {
    return <ErrorPanel message={loadError} onRetry={loadData} />;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-[#F8FAFC]">
            Return Book & Fine Settlement
          </h1>
          <p className="text-sm text-slate-500 dark:text-[#94A3B8] mt-0.5">
            Automatic overdue day calculation (${dailyFineRate.toFixed(2)}/day) and instant inventory restoration.
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={() => navigate('/issue')}>
          Switch to Issue Workflow
        </Button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        <form
          onSubmit={handleReturnSubmit}
          className="xl:col-span-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-6 space-y-5"
        >
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100 border-b border-slate-200 dark:border-slate-800 pb-4">
            Check-In Active Transaction
          </h2>

          {submitError && (
            <div className="p-4 rounded-xl border border-rose-500/35 bg-rose-500/10 flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-[#FF6485] shrink-0 mt-0.5" />
              <div className="text-sm text-rose-700 dark:text-[#FF6485]">
                <p className="font-semibold">Return Rejected</p>
                <p className="text-xs mt-0.5">{submitError}</p>
              </div>
            </div>
          )}

          {lastReturned && (
            <div className="p-4 rounded-xl border border-emerald-500/35 bg-emerald-500/10 flex items-start gap-3">
              <CheckCircle2 className="h-5 w-5 text-[#10D9A0] shrink-0 mt-0.5" />
              <div className="text-xs text-slate-700 dark:text-slate-200">
                <p className="text-sm font-semibold text-emerald-700 dark:text-[#10D9A0]">
                  Check-In Complete · {lastReturned.transaction.id}
                </p>
                <p className="mt-1">
                  "{lastReturned.transaction.book_title}" restored to shelf · Overdue: {lastReturned.overdue_days}d ·
                  Fine: ${lastReturned.fine_amount.toFixed(2)}
                </p>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                Transaction ID *
              </label>
              <input
                type="text"
                value={txnId}
                onChange={(e) => setTxnId(e.target.value)}
                placeholder="e.g., TXN-3027"
                className="w-full h-10 px-3 text-sm font-mono uppercase rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                Select Active Loan
              </label>
              <select
                value={selectedTxn?.id ?? ''}
                onChange={(e) => setTxnId(e.target.value)}
                className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              >
                <option value="">Choose active transaction...</option>
                {activeIssues.map((tx) => (
                  <option key={tx.id} value={tx.id}>
                    {tx.id} — {tx.book_title} ({tx.member_name})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                Return Date *
              </label>
              <input
                type="date"
                required
                value={returnDate}
                onChange={(e) => setReturnDate(e.target.value)}
                className="w-full h-10 px-3 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              />
            </div>

            <label className="flex items-center gap-2.5 h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-xs text-slate-700 dark:text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={waiveFine}
                onChange={(e) => setWaiveFine(e.target.checked)}
                className="accent-[#4388FF]"
              />
              <span>Waive calculated overdue fine</span>
            </label>
          </div>

          {selectedTxn && (
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#0B1224] space-y-2.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-mono font-semibold text-[#4388FF]">{selectedTxn.id}</span>
                <StatusIndicator status={previewOverdueDays > 0 ? 'Overdue' : 'Issued'} />
              </div>
              <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">{selectedTxn.book_title}</p>
              <p className="text-slate-500 dark:text-slate-400">
                Borrower: {selectedTxn.member_name} ({selectedTxn.member_id}) · {selectedTxn.member_department}
              </p>
              <div className="grid grid-cols-3 gap-3 pt-2 border-t border-slate-200 dark:border-slate-800 font-mono">
                <div>
                  <span className="block text-[11px] text-slate-500">Due Date</span>
                  <span className="font-semibold">{selectedTxn.due_date}</span>
                </div>
                <div>
                  <span className="block text-[11px] text-slate-500">Days Overdue</span>
                  <span className={`font-semibold ${previewOverdueDays > 0 ? 'text-[#FF6485]' : 'text-[#10D9A0]'}`}>
                    {previewOverdueDays} days
                  </span>
                </div>
                <div>
                  <span className="block text-[11px] text-slate-500">Assessed Fine</span>
                  <span className="font-semibold">${previewFine.toFixed(2)}</span>
                </div>
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
              Return Condition Notes
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g., Returned in excellent condition"
              className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
            />
          </div>

          <div className="flex justify-end pt-2">
            <Button type="submit" disabled={submitting || loading}>
              <BookCheck className="h-4 w-4" />
              {submitting ? 'Processing Return...' : 'Complete Book Return'}
            </Button>
          </div>
        </form>

        {/* Active Queue & Recent Returns */}
        <div className="xl:col-span-6 space-y-5">
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
            <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100 mb-3">
              Active Loans Awaiting Return ({activeIssues.length})
            </h3>
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {activeIssues.map((tx) => (
                <button
                  key={tx.id}
                  type="button"
                  onClick={() => setTxnId(tx.id)}
                  className={`w-full text-left p-3 rounded-xl border transition-colors flex items-center justify-between gap-3 cursor-pointer ${
                    selectedTxn?.id === tx.id
                      ? 'border-[#4388FF] bg-[#4388FF]/10'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-[#0B1224] hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 text-xs font-mono">
                      <span className="font-semibold text-[#4388FF]">{tx.id}</span>
                      <span className="text-slate-400">·</span>
                      <span className="text-slate-500">Due {tx.due_date}</span>
                    </div>
                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate mt-0.5">
                      {tx.book_title}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                      {tx.member_name} ({tx.member_id})
                    </p>
                  </div>
                  <StatusIndicator status={tx.status} />
                </button>
              ))}
              {activeIssues.length === 0 && (
                <p className="text-xs text-slate-500 py-6 text-center">All issued books have been returned.</p>
              )}
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
            <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100 mb-3">
              Recently Completed Returns
            </h3>
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {recentReturns.slice(0, 6).map((tx) => (
                <div
                  key={tx.id}
                  className="p-2.5 rounded-lg border border-slate-100 dark:border-slate-800/80 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="min-w-0">
                    <p className="font-medium text-slate-900 dark:text-slate-100 truncate">{tx.book_title}</p>
                    <p className="text-slate-500 dark:text-slate-400 font-mono">
                      {tx.id} · Returned {tx.return_date} · Fine ${tx.fine_amount.toFixed(2)}
                    </p>
                  </div>
                  <StatusIndicator status="Returned" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
