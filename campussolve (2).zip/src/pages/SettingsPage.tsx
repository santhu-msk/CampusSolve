import React, { useCallback, useEffect, useState } from 'react';
import { Database, Moon, Save, Sun } from 'lucide-react';
import { api, ApiClientError } from '../services/api';
import { useTheme } from '../context/ThemeContext';
import { useToast } from '../context/ToastContext';
import type { LibrarySettings, SyncStatus } from '../types/library';
import { Button, ErrorPanel, TableSkeleton } from '../components/ui/Primitives';

export function SettingsPage() {
  const { theme, setTheme } = useTheme();
  const { notify } = useToast();

  const [settings, setSettings] = useState<LibrarySettings | null>(null);
  const [syncStatus, setSyncStatus] = useState<SyncStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [backingUp, setBackingUp] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadSettings = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [res, syncRes] = await Promise.all([api.getSettings(), api.getSyncStatus()]);
      setSettings(res.settings);
      setSyncStatus(syncRes);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'Unable to fetch settings.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadSettings();
  }, [loadSettings]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    setSaving(true);
    try {
      const res = await api.updateSettings(settings);
      setSettings(res.settings);
      notify({
        type: 'success',
        title: 'Settings saved',
        description: 'Library circulation rules and thresholds updated in SQLite.',
      });
    } catch (err) {
      notify({
        type: 'error',
        title: 'Save failed',
        description: err instanceof ApiClientError ? err.message : 'Unable to update settings.',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDownloadBackup = async () => {
    setBackingUp(true);
    try {
      const backup = await api.downloadBackup();
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `campussolve_sqlite_backup_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      notify({
        type: 'success',
        title: 'Database backup created',
        description: 'Full SQLite snapshot downloaded.',
      });
    } catch (err) {
      notify({
        type: 'error',
        title: 'Backup failed',
        description: err instanceof ApiClientError ? err.message : 'Unable to create backup.',
      });
    } finally {
      setBackingUp(false);
    }
  };

  if (error) return <ErrorPanel message={error} onRetry={loadSettings} />;
  if (loading || !settings) return <TableSkeleton rows={5} cols={2} />;

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-[#F8FAFC]">
          System Settings & Policies
        </h1>
        <p className="text-sm text-slate-500 dark:text-[#94A3B8] mt-0.5">
          Configure circulation rules, overdue escalation thresholds, theme preference, and database backups.
        </p>
      </div>

      {/* Theme Appearance Card */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Interface Theme
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Switch between Premium Dark Mode and Premium Light Mode.
          </p>
        </div>

        <div className="inline-flex p-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-[#0B1224]">
          <button
            type="button"
            onClick={() => setTheme('dark')}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-medium cursor-pointer ${
              theme === 'dark' ? 'bg-[#101A31] text-white shadow-xs' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Moon className="h-3.5 w-3.5" />
            Dark Mode
          </button>
          <button
            type="button"
            onClick={() => setTheme('light')}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-medium cursor-pointer ${
              theme === 'light' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Sun className="h-3.5 w-3.5" />
            Light Mode
          </button>
        </div>
      </div>

      {/* Circulation & Fine Policy Form */}
      <form
        onSubmit={handleSave}
        className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-6 space-y-5"
      >
        <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100 border-b border-slate-200 dark:border-slate-800 pb-3">
          Library Circulation & Overdue Policies
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">Library Name</label>
            <input
              type="text"
              required
              value={settings.library_name}
              onChange={(e) => setSettings({ ...settings, library_name: e.target.value })}
              className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
              Institution Name
            </label>
            <input
              type="text"
              required
              value={settings.institution_name}
              onChange={(e) => setSettings({ ...settings, institution_name: e.target.value })}
              className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
              Default Loan Duration (days)
            </label>
            <input
              type="number"
              min={1}
              max={180}
              value={settings.default_loan_days}
              onChange={(e) => setSettings({ ...settings, default_loan_days: Number(e.target.value) })}
              className="w-full h-10 px-3 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
              Daily Fine Rate ({settings.currency_symbol})
            </label>
            <input
              type="number"
              step="0.25"
              min={0}
              max={100}
              value={settings.daily_fine_rate}
              onChange={(e) => setSettings({ ...settings, daily_fine_rate: Number(e.target.value) })}
              className="w-full h-10 px-3 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
              Default Borrow Limit
            </label>
            <input
              type="number"
              min={1}
              max={20}
              value={settings.default_borrow_limit}
              onChange={(e) => setSettings({ ...settings, default_borrow_limit: Number(e.target.value) })}
              className="w-full h-10 px-3 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
              Warning Threshold (days overdue)
            </label>
            <input
              type="number"
              min={1}
              value={settings.warning_threshold_days}
              onChange={(e) => setSettings({ ...settings, warning_threshold_days: Number(e.target.value) })}
              className="w-full h-10 px-3 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
              Critical Escalation Threshold (days overdue)
            </label>
            <input
              type="number"
              min={1}
              value={settings.critical_overdue_days}
              onChange={(e) => setSettings({ ...settings, critical_overdue_days: Number(e.target.value) })}
              className="w-full h-10 px-3 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
            />
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <Button type="submit" disabled={saving}>
            <Save className="h-4 w-4" />
            {saving ? 'Saving...' : 'Save Configuration'}
          </Button>
        </div>
      </form>

      {/* Database Backup */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Database Backup & Snapshot
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Download a complete JSON snapshot of all books, members, transactions, and settings from SQLite.
          </p>
        </div>
        <Button variant="outline" onClick={handleDownloadBackup} disabled={backingUp}>
          <Database className="h-4 w-4" />
          {backingUp ? 'Preparing Snapshot...' : 'Download DB Backup'}
        </Button>
      </div>

      {/* Synchronized Local CSV/JSON Persistence Status */}
      {syncStatus && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                Local CSV & JSON Synchronization
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Atomic write-through mirror between SQLite and local CSV/JSON data files.
              </p>
            </div>
            <span
              className={`px-2.5 py-1 rounded-md text-xs font-mono font-semibold uppercase ${
                syncStatus.status === 'synchronized'
                  ? 'bg-emerald-500/12 text-[#10D9A0]'
                  : 'bg-rose-500/12 text-[#FF6485]'
              }`}
            >
              {syncStatus.status}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {Object.entries(syncStatus.files).map(([fname, count]) => (
              <div
                key={fname}
                className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#0B1224] flex items-center justify-between text-xs font-mono"
              >
                <span className="text-slate-700 dark:text-slate-200">{fname}</span>
                <span className="text-[#4388FF] font-semibold">{count} rows</span>
              </div>
            ))}
          </div>

          {syncStatus.warnings.length > 0 && (
            <div className="p-3 rounded-xl border border-amber-500/30 bg-amber-500/10 text-xs text-amber-700 dark:text-[#FFAD5A] space-y-1">
              {syncStatus.warnings.map((w, i) => (
                <p key={i}>{w}</p>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
