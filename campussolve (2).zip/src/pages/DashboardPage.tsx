import React, { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import {
  AlertTriangle,
  ArrowRight,
  ArrowUpRight,
  BookCheck,
  BookOpen,
  BookPlus,
  Calendar,
  FileText,
  Layers,
  Repeat,
  UserPlus,
  Users,
} from 'lucide-react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { api, ApiClientError } from '../services/api';
import type { ActivityLog, AnalyticsPayload, WarningsPayload } from '../types/library';
import { AnimatedCounter, Button, ErrorPanel, StatusIndicator } from '../components/ui/Primitives';

export function DashboardPage() {
  const navigate = useNavigate();
  const [range, setRange] = useState<'30d' | '90d' | '6m' | 'all'>('6m');
  const [analytics, setAnalytics] = useState<AnalyticsPayload | null>(null);
  const [warnings, setWarnings] = useState<WarningsPayload | null>(null);
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [anRes, actRes, warnRes] = await Promise.all([
        api.getAnalytics({ range }),
        api.getActivity({ limit: 8 }),
        api.getWarnings(),
      ]);
      setAnalytics(anRes);
      setActivities(actRes.activities);
      setWarnings(warnRes);
    } catch (err) {
      setError(
        err instanceof ApiClientError ? err.message : 'Failed to load dashboard telemetry from backend.'
      );
    } finally {
      setLoading(false);
    }
  }, [range]);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  const todayFormatted = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  if (error) {
    return (
      <div className="space-y-6">
        <ErrorPanel message={error} onRetry={loadDashboard} />
      </div>
    );
  }

  const kpis = analytics?.kpis;

  const statCards = [
    {
      label: 'Total Books',
      value: kpis?.totalBooks ?? 0,
      sub: `${kpis?.totalCopies ?? 0} physical copies indexed`,
      accent: 'from-[#4388FF] to-[#22D3EE]',
      iconBg: 'bg-[#4388FF]/12 text-[#4388FF]',
      icon: BookOpen,
      trend: 'Catalogue',
      to: '/books',
    },
    {
      label: 'Available Books',
      value: kpis?.availableCopies ?? 0,
      sub: `${kpis ? (100 - kpis.utilizationRate).toFixed(1) : '0.0'}% shelf capacity ready`,
      accent: 'from-[#10D9A0] to-[#22D3EE]',
      iconBg: 'bg-[#10D9A0]/12 text-[#10D9A0]',
      icon: BookCheck,
      trend: 'On Shelf',
      to: '/books',
    },
    {
      label: 'Issued Books',
      value: kpis?.issuedBooks ?? 0,
      sub: `${kpis?.utilizationRate ?? 0}% active utilization`,
      accent: 'from-[#925CFF] to-[#4388FF]',
      iconBg: 'bg-[#925CFF]/12 text-[#925CFF]',
      icon: BookPlus,
      trend: 'Checked Out',
      to: '/issues',
    },
    {
      label: 'Total Members',
      value: kpis?.totalMembers ?? 0,
      sub: `${kpis?.activeMembers ?? 0} active borrower accounts`,
      accent: 'from-[#22D3EE] to-[#4388FF]',
      iconBg: 'bg-[#22D3EE]/12 text-[#22D3EE]',
      icon: Users,
      trend: 'Directory',
      to: '/members',
    },
    {
      label: 'Overdue Books',
      value: kpis?.overdueBooks ?? 0,
      sub: `$${(kpis?.totalFinesOutstanding ?? 0).toFixed(2)} accrued fines`,
      accent: 'from-[#FF6485] to-[#FFAD5A]',
      iconBg: 'bg-[#FF6485]/12 text-[#FF6485]',
      icon: AlertTriangle,
      trend: 'Attention',
      to: '/overdue',
    },
    {
      label: 'Total Transactions',
      value: kpis?.totalTransactions ?? 0,
      sub: `${kpis?.totalReturns ?? 0} returned · ${kpis?.avgBooksIssuedPerMonth ?? 0}/mo avg`,
      accent: 'from-[#FFAD5A] to-[#925CFF]',
      iconBg: 'bg-[#FFAD5A]/12 text-[#FFAD5A]',
      icon: Repeat,
      trend: 'Ledger',
      to: '/transactions',
    },
  ];

  const quickActions = [
    {
      title: 'Add Book',
      desc: 'Index new ISBN & shelf copies',
      icon: BookPlus,
      color: 'text-[#4388FF]',
      bg: 'bg-[#4388FF]/10',
      to: '/books?action=new',
    },
    {
      title: 'Register Member',
      desc: 'Onboard student or faculty',
      icon: UserPlus,
      color: 'text-[#10D9A0]',
      bg: 'bg-[#10D9A0]/10',
      to: '/members?action=new',
    },
    {
      title: 'Issue Book',
      desc: 'Validate & dispatch loan',
      icon: Layers,
      color: 'text-[#925CFF]',
      bg: 'bg-[#925CFF]/10',
      to: '/issue',
    },
    {
      title: 'Return Book',
      desc: 'Check-in & compute fines',
      icon: BookCheck,
      color: 'text-[#22D3EE]',
      bg: 'bg-[#22D3EE]/10',
      to: '/return',
    },
    {
      title: 'Generate Report',
      desc: 'Export CSV, JSON or Markdown',
      icon: FileText,
      color: 'text-[#FFAD5A]',
      bg: 'bg-[#FFAD5A]/10',
      to: '/reports',
    },
  ];

  const tooltipStyle = {
    backgroundColor: '#0B1224',
    border: '1px solid rgba(148,163,184,0.2)',
    borderRadius: '10px',
    color: '#F8FAFC',
    fontSize: '12px',
  };

  return (
    <div className="space-y-7">
      {/* Hero Banner */}
      <section className="relative overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-6 sm:p-8">
        <div
          aria-hidden="true"
          className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-gradient-to-br from-[#4388FF]/15 via-[#925CFF]/15 to-transparent blur-3xl pointer-events-none"
        />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-[#94A3B8]">
              <Calendar className="h-3.5 w-3.5 text-[#4388FF]" />
              <span>{todayFormatted}</span>
              <span aria-hidden="true">·</span>
              <span>Discover. Organize. Manage. Transform.</span>
            </div>
            <h1 className="mt-2 font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC] text-balance">
              Welcome to CampusSolve
            </h1>
            <p className="mt-1.5 text-sm sm:text-base text-slate-600 dark:text-[#94A3B8]">
              Everything your library needs, intelligently organized. Real-time inventory, circulation compliance, and analytics backed by live database telemetry.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <div className="inline-flex items-center p-1 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-[#0B1224]">
              {(
                [
                  { id: '30d', label: '30D' },
                  { id: '90d', label: '90D' },
                  { id: '6m', label: '6M' },
                  { id: 'all', label: 'All' },
                ] as const
              ).map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setRange(item.id)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                    range === item.id
                      ? 'bg-white dark:bg-[#101A31] text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
            <Button onClick={() => navigate('/analytics')} variant="outline" size="sm">
              Analytics Centre
              <ArrowUpRight className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </section>

      {/* Six Premium KPI Statistic Cards */}
      <section className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {statCards.map((card, idx) => {
          const Icon = card.icon;
          return (
            <motion.button
              key={card.label}
              type="button"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25, delay: idx * 0.04 }}
              whileHover={{ y: -2 }}
              onClick={() => navigate(card.to === '/issues' ? '/transactions' : card.to)}
              className="group relative text-left rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5 overflow-hidden transition-colors hover:border-[#4388FF]/40 cursor-pointer"
            >
              <div
                aria-hidden="true"
                className={`absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r ${card.accent} opacity-75 group-hover:opacity-100 transition-opacity`}
              />
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-xs font-medium text-slate-500 dark:text-[#94A3B8]">{card.label}</p>
                  <div className="mt-2 text-3xl font-display font-bold text-slate-900 dark:text-[#F8FAFC]">
                    {loading ? (
                      <div className="h-9 w-20 rounded bg-slate-200 dark:bg-slate-800 animate-pulse" />
                    ) : (
                      <AnimatedCounter value={card.value} />
                    )}
                  </div>
                  <p className="mt-2 text-xs text-slate-500 dark:text-[#94A3B8]">{card.sub}</p>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <div className={`h-10 w-10 rounded-xl flex items-center justify-center ${card.iconBg}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <span className="text-[11px] font-medium text-slate-400 group-hover:text-[#4388FF] transition-colors inline-flex items-center gap-0.5">
                    {card.trend}
                    <ArrowRight className="h-3 w-3" />
                  </span>
                </div>
              </div>
            </motion.button>
          );
        })}
      </section>

      {/* Automated Threshold Warnings Strip */}
      {warnings && warnings.totalAlerts > 0 && (
        <section className="rounded-xl border border-amber-500/30 bg-amber-500/5 dark:bg-[#101A31] p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-[#FFAD5A] shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Active Threshold Warnings ({warnings.totalAlerts})
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                {warnings.overdue.length} overdue · {warnings.approachingDue.length} due within{' '}
                {warnings.thresholds.warning_threshold_days}d · {warnings.unavailableBooks.length} out-of-stock ·{' '}
                {warnings.borrowLimitBreaches.length} at borrow limit
                {warnings.anomalousQuantities.length > 0
                  ? ` · ${warnings.anomalousQuantities.length} inventory anomaly`
                  : ''}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <Button size="sm" variant="outline" onClick={() => navigate('/overdue')}>
              Inspect Warnings
            </Button>
          </div>
        </section>
      )}

      {/* Quick Action Cards */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-[#F8FAFC]">
            Quick Operations
          </h2>
          <span className="text-xs text-slate-500 dark:text-[#94A3B8]">Direct workflow shortcuts</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {quickActions.map((qa) => {
            const Icon = qa.icon;
            return (
              <button
                key={qa.title}
                type="button"
                onClick={() => navigate(qa.to)}
                className="flex items-center gap-3 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] hover:border-[#4388FF]/45 hover:bg-slate-50 dark:hover:bg-[#14203B] transition-all text-left cursor-pointer"
              >
                <div className={`h-10 w-10 rounded-lg flex items-center justify-center shrink-0 ${qa.bg} ${qa.color}`}>
                  <Icon className="h-5 w-5" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">{qa.title}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{qa.desc}</p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Visualizations Row 1: Monthly Borrowing Trends (A) + Monthly Return Trends (B) */}
      <section className="grid grid-cols-1 xl:grid-cols-2 gap-5">
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                Monthly Borrowing Trends
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Books issued per month across selected period
              </p>
            </div>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={analytics?.monthlyTrends ?? []} margin={{ top: 8, right: 12, left: -16, bottom: 0 }}>
                <defs>
                  <linearGradient id="gradIssued" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4388FF" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#4388FF" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.14)" />
                <XAxis dataKey="label" tick={{ fontSize: 12, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#94A3B8' }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Area
                  type="monotone"
                  dataKey="issued"
                  name="Books Issued"
                  stroke="#4388FF"
                  strokeWidth={2.5}
                  fill="url(#gradIssued)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                Monthly Return Trends
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Completed check-ins vs overdue occurrences
              </p>
            </div>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics?.monthlyTrends ?? []} margin={{ top: 8, right: 12, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.14)" />
                <XAxis dataKey="label" tick={{ fontSize: 12, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#94A3B8' }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Bar dataKey="returned" name="Returned" fill="#10D9A0" radius={[6, 6, 0, 0]} />
                <Bar dataKey="overdue" name="Active Overdue" fill="#FF6485" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      {/* Visualizations Row 2: Availability Distribution (C) + Category Distribution (D) */}
      <section className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
          <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Book Availability Distribution
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
            Live physical copy allocation across catalogue
          </p>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={analytics?.availabilityDistribution ?? []}
                  dataKey="value"
                  nameKey="name"
                  innerRadius={56}
                  outerRadius={84}
                  paddingAngle={3}
                >
                  {(analytics?.availabilityDistribution ?? []).map((entry) => (
                    <Cell key={entry.name} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="xl:col-span-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
          <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Category Distribution & Circulation Volume
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
            Total copies compared with borrowing activity by academic discipline
          </p>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics?.categoryDistribution ?? []} margin={{ top: 8, right: 12, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.14)" />
                <XAxis dataKey="category" tick={{ fontSize: 11, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#94A3B8' }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Bar dataKey="totalCopies" name="Total Copies" fill="#4388FF" radius={[5, 5, 0, 0]} />
                <Bar dataKey="borrowCount" name="Borrows" fill="#925CFF" radius={[5, 5, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      {/* Visualizations Row 3: Active Members Analysis (E) + Overdue Statistics (F) */}
      <section className="grid grid-cols-1 xl:grid-cols-2 gap-5">
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                Active Members Analysis
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Highest circulation engagement by member
              </p>
            </div>
            <Button variant="ghost" size="sm" onClick={() => navigate('/members')}>
              View All
            </Button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
                  <th className="py-2 pr-3 font-medium">Member</th>
                  <th className="py-2 px-3 font-medium">Department</th>
                  <th className="py-2 px-3 font-medium text-right">Borrows</th>
                  <th className="py-2 pl-3 font-medium text-right">Active</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/70">
                {(analytics?.activeMembers ?? []).slice(0, 6).map((m) => (
                  <tr
                    key={m.id}
                    onClick={() => navigate(`/members/${m.id}`)}
                    className="hover:bg-slate-50 dark:hover:bg-[#172544]/50 cursor-pointer transition-colors"
                  >
                    <td className="py-2.5 pr-3 font-medium text-slate-900 dark:text-slate-100">{m.full_name}</td>
                    <td className="py-2.5 px-3 text-xs text-slate-500 dark:text-slate-400">{m.department}</td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">{m.totalBorrows}</td>
                    <td className="py-2.5 pl-3 text-right font-mono tabular-nums text-[#4388FF]">{m.activeIssues}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                Overdue Statistics
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Breakdown by overdue age bracket
              </p>
            </div>
            <Button variant="ghost" size="sm" onClick={() => navigate('/overdue')}>
              Monitor Queue
            </Button>
          </div>
          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics?.overdueBreakdown ?? []} margin={{ top: 8, right: 12, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.14)" />
                <XAxis dataKey="bucket" tick={{ fontSize: 12, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#94A3B8' }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={tooltipStyle} />
                <Bar dataKey="count" name="Overdue Items" fill="#FF6485" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      {/* Recent Activity Section */}
      <section className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              Recent Activity Feed
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Latest cataloguing, circulation, and member audit events
            </p>
          </div>
          <Button variant="outline" size="sm" onClick={() => navigate('/activity')}>
            Full Audit Log
          </Button>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
          {activities.map((act) => (
            <div key={act.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-3 min-w-0">
                <StatusIndicator
                  status={
                    act.action_type.includes('RETURN')
                      ? 'Returned'
                      : act.action_type.includes('ISSUE')
                        ? 'Issued'
                        : 'Active'
                  }
                />
                <p className="text-sm text-slate-700 dark:text-slate-200 truncate">{act.summary}</p>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono shrink-0">
                <span>{act.entity_id}</span>
                <span aria-hidden="true">·</span>
                <span>{new Date(act.created_at).toLocaleDateString()}</span>
              </div>
            </div>
          ))}
          {!loading && activities.length === 0 && (
            <p className="py-6 text-center text-sm text-slate-500">No recent activities recorded.</p>
          )}
        </div>
      </section>
    </div>
  );
}
