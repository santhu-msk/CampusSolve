import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Eye, LayoutGrid, Pencil, Plus, Table2, Trash2, Users } from 'lucide-react';
import { api, ApiClientError } from '../services/api';
import { useToast } from '../context/ToastContext';
import type { Member, MemberStatus, MemberType } from '../types/library';
import { DataTable, type ColumnDef } from '../components/ui/DataTable';
import {
  Button,
  ConfirmDialog,
  EmptyState,
  ErrorPanel,
  Modal,
  StatusIndicator,
  TableSkeleton,
} from '../components/ui/Primitives';

const DEPARTMENTS = [
  'Computer Science',
  'Natural Sciences',
  'Mathematics',
  'Humanities & Arts',
  'Economics & Law',
  'Engineering',
  'Administration',
];

const EMPTY_MEMBER = {
  id: '',
  full_name: '',
  email: '',
  phone: '',
  department: 'Computer Science',
  course: '',
  member_type: 'Student' as MemberType,
  status: 'Active' as MemberStatus,
  max_borrow_limit: 5,
};

export function MembersPage() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { notify } = useToast();

  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');
  const [statusFilter, setStatusFilter] = useState('All');
  const [deptFilter, setDeptFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const [modalOpen, setModalOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<Member | null>(null);
  const [form, setForm] = useState(EMPTY_MEMBER);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const [deleteTarget, setDeleteTarget] = useState<Member | null>(null);
  const [deleting, setDeleting] = useState(false);

  const fetchMembers = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getMembers();
      setMembers(res.members);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'Unable to fetch member directory.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchMembers();
  }, [fetchMembers]);

  useEffect(() => {
    if (searchParams.get('action') === 'new') {
      openCreateModal();
      setSearchParams({}, { replace: true });
    }
  }, [searchParams, setSearchParams]);

  const openCreateModal = () => {
    setEditingMember(null);
    setForm(EMPTY_MEMBER);
    setFormError(null);
    setModalOpen(true);
  };

  const openEditModal = (m: Member, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setEditingMember(m);
    setForm({
      id: m.id,
      full_name: m.full_name,
      email: m.email,
      phone: m.phone,
      department: m.department,
      course: m.course,
      member_type: m.member_type,
      status: m.status,
      max_borrow_limit: m.max_borrow_limit,
    });
    setFormError(null);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!form.full_name.trim() || !form.email.trim() || !form.phone.trim() || !form.course.trim()) {
      setFormError('Full name, email, phone, and course/program are required.');
      return;
    }

    setSaving(true);
    try {
      if (editingMember) {
        await api.updateMember(editingMember.id, {
          full_name: form.full_name,
          email: form.email,
          phone: form.phone,
          department: form.department,
          course: form.course,
          member_type: form.member_type,
          status: form.status,
          max_borrow_limit: Number(form.max_borrow_limit),
        });
        notify({ type: 'success', title: 'Member updated', description: `${form.full_name} profile saved.` });
      } else {
        await api.createMember({
          ...(form.id.trim() ? { id: form.id.trim() } : {}),
          full_name: form.full_name,
          email: form.email,
          phone: form.phone,
          department: form.department,
          course: form.course,
          member_type: form.member_type,
          status: form.status,
          max_borrow_limit: Number(form.max_borrow_limit),
        });
        notify({ type: 'success', title: 'Member registered', description: `${form.full_name} added to directory.` });
      }
      setModalOpen(false);
      await fetchMembers();
    } catch (err) {
      const msg = err instanceof ApiClientError ? err.message : 'Failed to save member.';
      setFormError(msg);
      notify({ type: 'error', title: 'Registration error', description: msg });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await api.deleteMember(deleteTarget.id);
      notify({ type: 'success', title: 'Member removed', description: `${deleteTarget.full_name} deleted.` });
      setDeleteTarget(null);
      await fetchMembers();
    } catch (err) {
      const msg = err instanceof ApiClientError ? err.message : 'Unable to delete member.';
      notify({ type: 'error', title: 'Delete blocked', description: msg });
      setDeleteTarget(null);
    } finally {
      setDeleting(false);
    }
  };

  const filteredMembers = useMemo(() => {
    return members.filter((m) => {
      if (statusFilter !== 'All' && m.status !== statusFilter) return false;
      if (deptFilter !== 'All' && m.department !== deptFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          m.id.toLowerCase().includes(q) ||
          m.full_name.toLowerCase().includes(q) ||
          m.email.toLowerCase().includes(q) ||
          m.department.toLowerCase().includes(q) ||
          m.course.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [members, statusFilter, deptFilter, searchQuery]);

  const columns: ColumnDef<Member>[] = [
    {
      key: 'id',
      header: 'Member ID',
      sortable: true,
      sortValue: (m) => m.id,
      render: (m) => <span className="font-mono text-xs font-semibold text-[#4388FF]">{m.id}</span>,
    },
    {
      key: 'full_name',
      header: 'Member Name',
      sortable: true,
      sortValue: (m) => m.full_name,
      render: (m) => (
        <div>
          <p className="font-medium text-slate-900 dark:text-slate-100">{m.full_name}</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">{m.email}</p>
        </div>
      ),
    },
    {
      key: 'department',
      header: 'Department & Course',
      sortable: true,
      sortValue: (m) => m.department,
      render: (m) => (
        <div>
          <p className="text-xs font-medium text-slate-800 dark:text-slate-200">{m.department}</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">{m.course}</p>
        </div>
      ),
    },
    {
      key: 'member_type',
      header: 'Role',
      sortable: true,
      sortValue: (m) => m.member_type,
      render: (m) => <span className="text-xs text-slate-600 dark:text-slate-300">{m.member_type}</span>,
    },
    {
      key: 'phone',
      header: 'Contact',
      render: (m) => <span className="font-mono text-xs text-slate-500 dark:text-slate-400">{m.phone}</span>,
    },
    {
      key: 'active_issues_count',
      header: 'Active Loans',
      align: 'right',
      sortable: true,
      sortValue: (m) => m.active_issues_count,
      render: (m) => (
        <span className="font-mono tabular-nums">
          {m.active_issues_count} / {m.max_borrow_limit}
        </span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      sortable: true,
      sortValue: (m) => m.status,
      render: (m) => <StatusIndicator status={m.status} />,
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (m) => (
        <div className="inline-flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
          <button
            type="button"
            title="View member profile"
            onClick={() => navigate(`/members/${m.id}`)}
            className="p-1.5 rounded-lg text-slate-500 hover:text-[#4388FF] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Eye className="h-4 w-4" />
          </button>
          <button
            type="button"
            title="Edit member"
            onClick={(e) => openEditModal(m, e)}
            className="p-1.5 rounded-lg text-slate-500 hover:text-[#10D9A0] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Pencil className="h-4 w-4" />
          </button>
          <button
            type="button"
            title="Delete member"
            onClick={() => setDeleteTarget(m)}
            className="p-1.5 rounded-lg text-slate-500 hover:text-[#FF6485] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-[#F8FAFC]">
            Member Administration
          </h1>
          <p className="text-sm text-slate-500 dark:text-[#94A3B8] mt-0.5">
            {members.length} registered members · {members.filter((m) => m.status === 'Active').length} active accounts
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <div className="inline-flex p-1 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-[#0B1224]">
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-white dark:bg-[#101A31] text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <Table2 className="h-3.5 w-3.5" />
              Table
            </button>
            <button
              type="button"
              onClick={() => setViewMode('cards')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer ${
                viewMode === 'cards'
                  ? 'bg-white dark:bg-[#101A31] text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <LayoutGrid className="h-3.5 w-3.5" />
              Profiles
            </button>
          </div>

          <Button onClick={openCreateModal}>
            <Plus className="h-4 w-4" />
            Register Member
          </Button>
        </div>
      </div>

      {error && <ErrorPanel message={error} onRetry={fetchMembers} />}

      {loading ? (
        <TableSkeleton rows={7} cols={6} />
      ) : viewMode === 'table' ? (
        <DataTable
          data={filteredMembers}
          columns={columns}
          rowKey={(m) => m.id}
          externalSearch={searchQuery}
          onExternalSearchChange={setSearchQuery}
          searchPlaceholder="Search ID, name, email, department..."
          searchFilter={() => true}
          onRowClick={(m) => navigate(`/members/${m.id}`)}
          exportFilename="campussolve_members.csv"
          toolbarExtras={
            <div className="flex flex-wrap items-center gap-2">
              <select
                value={deptFilter}
                onChange={(e) => setDeptFilter(e.target.value)}
                className="h-9 px-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-700 dark:text-slate-200"
              >
                <option value="All">All Departments</option>
                {DEPARTMENTS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="h-9 px-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-700 dark:text-slate-200"
              >
                <option value="All">All Statuses</option>
                <option value="Active">Active</option>
                <option value="Suspended">Suspended</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
          }
          emptyState={
            <EmptyState
              icon={<Users className="h-6 w-6" />}
              title="No matching members"
              description="Register a new student, faculty, or researcher account."
              action={
                <Button size="sm" onClick={openCreateModal}>
                  <Plus className="h-4 w-4" />
                  Register Member
                </Button>
              }
            />
          }
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredMembers.map((m) => (
            <div
              key={m.id}
              onClick={() => navigate(`/members/${m.id}`)}
              className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5 space-y-4 hover:border-[#4388FF]/45 transition-all cursor-pointer"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="h-11 w-11 rounded-xl bg-gradient-to-br from-[#4388FF]/20 to-[#925CFF]/20 border border-[#4388FF]/30 flex items-center justify-center font-display font-bold text-sm text-[#4388FF] shrink-0">
                    {m.full_name
                      .split(' ')
                      .map((p) => p[0])
                      .join('')
                      .slice(0, 2)
                      .toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <p className="font-display font-semibold text-slate-900 dark:text-slate-100 truncate">
                      {m.full_name}
                    </p>
                    <p className="text-xs font-mono text-slate-500 dark:text-slate-400">{m.id} · {m.member_type}</p>
                  </div>
                </div>
                <StatusIndicator status={m.status} />
              </div>

              <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1">
                <p className="truncate">{m.department} · {m.course}</p>
                <p className="text-slate-500 dark:text-slate-400 truncate">{m.email}</p>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-mono">
                <span>Active: {m.active_issues_count}/{m.max_borrow_limit}</span>
                <span>Total Borrows: {m.total_borrows_count}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Register / Edit Member Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingMember ? `Edit Member · ${editingMember.id}` : 'Register New Library Member'}
        subtitle="Creates a validated member profile in SQLite."
        maxWidth="max-w-xl"
      >
        <form onSubmit={handleSave} className="space-y-4">
          {formError && (
            <div className="p-3 rounded-lg border border-rose-500/30 bg-rose-500/10 text-xs text-rose-700 dark:text-[#FF6485]">
              {formError}
            </div>
          )}

          {!editingMember && (
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Member ID (Optional — auto-generated if blank)
              </label>
              <input
                type="text"
                value={form.id}
                onChange={(e) => setForm({ ...form, id: e.target.value })}
                placeholder="e.g., MEM-2100"
                className="w-full h-10 px-3 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              />
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">Full Name *</label>
              <input
                type="text"
                required
                value={form.full_name}
                onChange={(e) => setForm({ ...form, full_name: e.target.value })}
                placeholder="e.g., Elena Vance"
                className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">Institutional Email *</label>
              <input
                type="email"
                required
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="name@northbridge.edu"
                className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">Phone Number *</label>
              <input
                type="text"
                required
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                placeholder="+1 (555) 204-8890"
                className="w-full h-10 px-3 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">Department *</label>
              <select
                value={form.department}
                onChange={(e) => setForm({ ...form, department: e.target.value })}
                className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              >
                {DEPARTMENTS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">Course / Program *</label>
            <input
              type="text"
              required
              value={form.course}
              onChange={(e) => setForm({ ...form, course: e.target.value })}
              placeholder="e.g., B.Tech Computer Science"
              className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">Member Type</label>
              <select
                value={form.member_type}
                onChange={(e) => setForm({ ...form, member_type: e.target.value as MemberType })}
                className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              >
                <option value="Student">Student</option>
                <option value="Faculty">Faculty</option>
                <option value="Researcher">Researcher</option>
                <option value="Staff">Staff</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">Status</label>
              <select
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value as MemberStatus })}
                className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              >
                <option value="Active">Active</option>
                <option value="Suspended">Suspended</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">Borrow Limit</label>
              <input
                type="number"
                min={1}
                max={20}
                value={form.max_borrow_limit}
                onChange={(e) => setForm({ ...form, max_borrow_limit: Number(e.target.value) })}
                className="w-full h-10 px-3 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? 'Saving...' : editingMember ? 'Save Profile' : 'Register Member'}
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Member Account"
        description={`Are you sure you want to delete ${deleteTarget?.full_name ?? ''} (${deleteTarget?.id ?? ''})? Accounts with active loans or audit history cannot be removed.`}
      />
    </div>
  );
}
