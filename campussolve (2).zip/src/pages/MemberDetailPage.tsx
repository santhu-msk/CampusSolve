import { useCallback, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, BookPlus, Mail, Phone } from 'lucide-react';
import { api, ApiClientError } from '../services/api';
import type { Member, TransactionRecord } from '../types/library';
import { Button, ErrorPanel, StatusIndicator, TableSkeleton } from '../components/ui/Primitives';

export function MemberDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [member, setMember] = useState<Member | null>(null);
  const [transactions, setTransactions] = useState<TransactionRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadMember = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    setError(null);
    try {
      const res = await api.getMember(id);
      setMember(res.member);
      setTransactions(res.transactions);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'Unable to load member profile.');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    loadMember();
  }, [loadMember]);

  if (loading) return <TableSkeleton rows={5} cols={5} />;
  if (error || !member) {
    return (
      <div className="space-y-4">
        <Button variant="outline" size="sm" onClick={() => navigate('/members')}>
          <ArrowLeft className="h-4 w-4" />
          Back to Members
        </Button>
        <ErrorPanel message={error ?? 'Member not found.'} onRetry={loadMember} />
      </div>
    );
  }

  const activeLoans = transactions.filter((t) => t.status !== 'Returned');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <Button variant="outline" size="sm" onClick={() => navigate('/members')}>
          <ArrowLeft className="h-4 w-4" />
          Back to Directory
        </Button>

        <Button
          size="sm"
          disabled={member.status !== 'Active'}
          onClick={() => navigate(`/issue?memberId=${encodeURIComponent(member.id)}`)}
        >
          <BookPlus className="h-4 w-4" />
          Issue Book to Member
        </Button>
      </div>

      {/* Member Profile Card */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-start gap-5">
          <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-[#4388FF] to-[#925CFF] text-white font-display font-bold text-xl flex items-center justify-center shrink-0">
            {member.full_name
              .split(' ')
              .map((p) => p[0])
              .join('')
              .slice(0, 2)
              .toUpperCase()}
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-[#F8FAFC]">
                {member.full_name}
              </h1>
              <StatusIndicator status={member.status} />
            </div>
            <p className="mt-1 text-sm text-slate-600 dark:text-[#94A3B8]">
              {member.id} · {member.member_type} · {member.department} · {member.course}
            </p>
            <div className="mt-3 flex flex-wrap items-center gap-5 text-xs text-slate-500 dark:text-slate-400">
              <span className="inline-flex items-center gap-1.5">
                <Mail className="h-3.5 w-3.5 text-[#4388FF]" />
                {member.email}
              </span>
              <span className="inline-flex items-center gap-1.5 font-mono">
                <Phone className="h-3.5 w-3.5 text-[#10D9A0]" />
                {member.phone}
              </span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 border-t md:border-t-0 md:border-l border-slate-200 dark:border-slate-800 pt-4 md:pt-0 md:pl-6">
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">Active Loans</p>
            <p className="mt-1 text-xl font-mono font-bold text-slate-900 dark:text-slate-100">
              {member.active_issues_count} / {member.max_borrow_limit}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">Total Borrows</p>
            <p className="mt-1 text-xl font-mono font-bold text-slate-900 dark:text-slate-100">
              {member.total_borrows_count}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">Overdue</p>
            <p className="mt-1 text-xl font-mono font-bold text-[#FF6485]">{member.overdue_count}</p>
          </div>
        </div>
      </div>

      {/* Active Issues */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
        <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100 mb-3">
          Active Checked-Out Books ({activeLoans.length})
        </h2>
        {activeLoans.length === 0 ? (
          <p className="text-sm text-slate-500 dark:text-slate-400 py-4">No books currently checked out.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {activeLoans.map((tx) => (
              <div
                key={tx.id}
                className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-[#0B1224] flex items-center justify-between gap-3"
              >
                <div className="min-w-0">
                  <p className="text-xs font-mono text-[#4388FF]">{tx.id} · {tx.book_id}</p>
                  <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                    {tx.book_title}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-mono">
                    Issued {tx.issue_date} · Due {tx.due_date}
                  </p>
                </div>
                <div className="flex flex-col items-end gap-2 shrink-0">
                  <StatusIndicator status={tx.status} />
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => navigate(`/return?txnId=${encodeURIComponent(tx.id)}`)}
                  >
                    Return
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Complete Transaction History */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
        <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100 mb-3">
          Borrowing & Transaction History ({transactions.length})
        </h2>
        {transactions.length === 0 ? (
          <p className="text-sm text-slate-500 dark:text-slate-400 py-6 text-center">No borrowing history found.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
                  <th className="py-2.5 pr-4 font-medium">Transaction</th>
                  <th className="py-2.5 px-4 font-medium">Book Title</th>
                  <th className="py-2.5 px-4 font-medium">Issue Date</th>
                  <th className="py-2.5 px-4 font-medium">Due Date</th>
                  <th className="py-2.5 px-4 font-medium">Return Date</th>
                  <th className="py-2.5 px-4 font-medium text-right">Fine</th>
                  <th className="py-2.5 pl-4 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/70">
                {transactions.map((t) => (
                  <tr key={t.id} className="hover:bg-slate-50 dark:hover:bg-[#172544]/40">
                    <td className="py-3 pr-4 font-mono text-xs font-semibold text-[#4388FF]">{t.id}</td>
                    <td className="py-3 px-4">
                      <button
                        type="button"
                        onClick={() => navigate(`/books/${t.book_id}`)}
                        className="font-medium text-slate-900 dark:text-slate-100 hover:text-[#4388FF] cursor-pointer text-left"
                      >
                        {t.book_title}
                      </button>
                      <span className="block text-xs text-slate-500 font-mono">{t.book_id}</span>
                    </td>
                    <td className="py-3 px-4 font-mono text-xs">{t.issue_date}</td>
                    <td className="py-3 px-4 font-mono text-xs">{t.due_date}</td>
                    <td className="py-3 px-4 font-mono text-xs">{t.return_date ?? '—'}</td>
                    <td className="py-3 px-4 text-right font-mono text-xs">
                      {t.fine_amount > 0 ? `$${t.fine_amount.toFixed(2)}` : '$0.00'}
                    </td>
                    <td className="py-3 pl-4">
                      <StatusIndicator status={t.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
