import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, BookCheck, Download } from 'lucide-react';
import { api, ApiClientError } from '../services/api';
import { useToast } from '../context/ToastContext';
import type { OverdueRecord, WarningsPayload } from '../types/library';
import { DataTable, type ColumnDef } from '../components/ui/DataTable';
import { Button, EmptyState, ErrorPanel, StatusIndicator, TableSkeleton } from '../components/ui/Primitives';

export function OverduePage() {
  const navigate = useNavigate();
  const { notify } = useToast();

  const [records, setRecords] = useState<OverdueRecord[]>([]);
  const [warnings, setWarnings] = useState<WarningsPayload | null>(null);
  const [summary, setSummary] = useState({
    totalOverdue: 0,
    criticalCount: 0,
    totalFines: 0,
    dailyFineRate: 2.5,
    warningThresholdDays: 3,
    criticalOverdueDays: 14,
  });
  const [minDays, setMinDays] = useState(1);
  const [severity, setSeverity] = useState('All');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchOverdue = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [res, warnRes] = await Promise.all([
        api.getOverdue({ min_days: minDays, severity, search }),
        api.getWarnings(),
      ]);
      setRecords(res.records);
      setSummary(res.summary);
      setWarnings(warnRes);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'Unable to fetch overdue monitoring records.');
    } finally {
      setLoading(false);
    }
  }, [minDays, severity, search]);

  useEffect(() => {
    fetchOverdue();
  }, [fetchOverdue]);

  const handleExportOverdue = async () => {
    try {
      const res = await api.exportData('overdue', 'csv');
      const blob = new Blob([res.content], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `campussolve_overdue_report_${new Date().toISOString().slice(0, 10)}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      notify({ type: 'success', title: 'Overdue report exported', description: `${res.count} overdue record(s) downloaded.` });
    } catch (err) {
      notify({
        type: 'error',
        title: 'Export failed',
        description: err instanceof ApiClientError ? err.message : 'Unable to export report.',
      });
    }
  };

  const columns: ColumnDef<OverdueRecord>[] = [
    {
      key: 'id',
      header: 'Transaction',
      sortable: true,
      sortValue: (r) => r.id,
      render: (r) => <span className="font-mono text-xs font-semibold text-[#4388FF]">{r.id}</span>,
    },
    {
      key: 'member_name',
      header: 'Member Details',
      sortable: true,
      sortValue: (r) => r.member_name ?? '',
      render: (r) => (
        <div>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/members/${r.member_id}`);
            }}
            className="font-medium text-slate-900 dark:text-slate-100 hover:text-[#4388FF] cursor-pointer text-left"
          >
            {r.member_name}
          </button>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {r.member_id} · {r.member_department} · {r.member_email}
          </p>
        </div>
      ),
    },
    {
      key: 'book_title',
      header: 'Book Details',
      sortable: true,
      sortValue: (r) => r.book_title ?? '',
      render: (r) => (
        <div className="max-w-[230px]">
          <p className="font-medium text-slate-900 dark:text-slate-100 truncate">{r.book_title}</p>
          <p className="text-xs font-mono text-slate-500">{r.book_id}</p>
        </div>
      ),
    },
    {
      key: 'due_date',
      header: 'Due Date',
      sortable: true,
      sortValue: (r) => r.due_date,
      render: (r) => <span className="font-mono text-xs">{r.due_date}</span>,
    },
    {
      key: 'days_overdue',
      header: 'Days Overdue',
      align: 'right',
      sortable: true,
      sortValue: (r) => r.days_overdue,
      render: (r) => (
        <span className="font-mono text-xs font-bold text-[#FF6485] tabular-nums">{r.days_overdue} days</span>
      ),
    },
    {
      key: 'estimated_fine',
      header: 'Accrued Fine',
      align: 'right',
      sortable: true,
      sortValue: (r) => r.estimated_fine,
      render: (r) => (
        <span className="font-mono text-xs font-semibold tabular-nums">${r.estimated_fine.toFixed(2)}</span>
      ),
    },
    {
      key: 'severity',
      header: 'Severity',
      sortable: true,
      sortValue: (r) => r.severity,
      render: (r) => <StatusIndicator status={r.severity} />,
    },
    {
      key: 'actions',
      header: 'Action',
      align: 'right',
      render: (r) => (
        <Button
          size="sm"
          variant="outline"
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/return?txnId=${encodeURIComponent(r.id)}`);
          }}
        >
          <BookCheck className="h-3.5 w-3.5" />
          Process Return
        </Button>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-[#F8FAFC]">
            Overdue Monitoring & Escalation
          </h1>
          <p className="text-sm text-slate-500 dark:text-[#94A3B8] mt-0.5">
            Fine rate ${summary.dailyFineRate.toFixed(2)}/day · Warning &gt;{summary.warningThresholdDays}d · Critical &ge;
            {summary.criticalOverdueDays}d
          </p>
        </div>

        <Button variant="outline" onClick={handleExportOverdue}>
          <Download className="h-4 w-4" />
          Export Overdue Report
        </Button>
      </div>

      {/* Critical Alert Banner */}
      {summary.criticalCount > 0 && (
        <div className="rounded-xl border border-rose-500/30 bg-rose-500/8 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-[#FF6485] shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-rose-700 dark:text-[#FF6485]">
                Critical Overdue Escalation Required ({summary.criticalCount} item{summary.criticalCount > 1 ? 's' : ''})
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                {summary.criticalCount} checkout(s) have exceeded the {summary.criticalOverdueDays}-day critical threshold and require immediate member follow-up.
              </p>
            </div>
          </div>
          <Button size="sm" variant="outline" onClick={() => setSeverity('Critical')}>
            Filter Critical Only
          </Button>
        </div>
      )}

      {/* Overdue KPI Summary Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">Overdue Books</p>
          <p className="mt-1.5 text-3xl font-display font-bold font-mono text-[#FF6485] tabular-nums">
            {summary.totalOverdue}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">Critical Escalations (&ge;{summary.criticalOverdueDays}d)</p>
          <p className="mt-1.5 text-3xl font-display font-bold font-mono text-[#FFAD5A] tabular-nums">
            {summary.criticalCount}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">Outstanding Accrued Fines</p>
          <p className="mt-1.5 text-3xl font-display font-bold font-mono text-slate-900 dark:text-slate-100 tabular-nums">
            ${summary.totalFines.toFixed(2)}
          </p>
        </div>
      </div>

      {/* Automated Threshold Alerts (Approaching Due, Out of Stock, Borrow Limit Breaches) */}
      {warnings &&
        (warnings.approachingDue.length > 0 ||
          warnings.unavailableBooks.length > 0 ||
          warnings.borrowLimitBreaches.length > 0 ||
          warnings.anomalousQuantities.length > 0) && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="rounded-xl border border-cyan-500/25 bg-cyan-500/5 p-4">
              <p className="text-xs font-semibold text-[#22D3EE]">
                Approaching Due Dates ({warnings.approachingDue.length})
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                {warnings.approachingDue.length > 0
                  ? warnings.approachingDue
                      .slice(0, 2)
                      .map((a) => `${a.book_title ?? a.book_id} (${a.days_remaining}d left)`)
                      .join(' · ')
                  : `No active loans due within ${summary.warningThresholdDays} days.`}
              </p>
            </div>

            <div className="rounded-xl border border-amber-500/25 bg-amber-500/5 p-4">
              <p className="text-xs font-semibold text-[#FFAD5A]">
                Unavailable Books ({warnings.unavailableBooks.length})
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                {warnings.unavailableBooks.length > 0
                  ? warnings.unavailableBooks
                      .slice(0, 2)
                      .map((b) => `${b.title} (${b.id})`)
                      .join(' · ')
                  : 'All catalogue titles have copies available.'}
              </p>
            </div>

            <div className="rounded-xl border border-purple-500/25 bg-purple-500/5 p-4">
              <p className="text-xs font-semibold text-[#925CFF]">
                Borrow Limit & Anomalies ({warnings.borrowLimitBreaches.length + warnings.anomalousQuantities.length})
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                {warnings.borrowLimitBreaches.length} member(s) at max limit ·{' '}
                {warnings.anomalousQuantities.length} quantity anomaly detected
              </p>
            </div>
          </div>
        )}

      {error && <ErrorPanel message={error} onRetry={fetchOverdue} />}

      {loading ? (
        <TableSkeleton rows={6} cols={7} />
      ) : (
        <DataTable
          data={records}
          columns={columns}
          rowKey={(r) => r.id}
          externalSearch={search}
          onExternalSearchChange={setSearch}
          searchPlaceholder="Filter overdue by member, book, department..."
          searchFilter={() => true}
          exportFilename="campussolve_overdue_queue.csv"
          initialSortKey="days_overdue"
          initialSortDir="desc"
          toolbarExtras={
            <div className="flex flex-wrap items-center gap-2">
              <select
                aria-label="Minimum overdue days"
                value={minDays}
                onChange={(e) => setMinDays(Number(e.target.value))}
                className="h-9 px-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-700 dark:text-slate-200"
              >
                <option value={1}>All Overdue (&ge;1 day)</option>
                <option value={4}>4+ Days Overdue</option>
                <option value={7}>7+ Days Overdue</option>
                <option value={14}>14+ Days Overdue</option>
              </select>

              <select
                aria-label="Severity filter"
                value={severity}
                onChange={(e) => setSeverity(e.target.value)}
                className="h-9 px-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-700 dark:text-slate-200"
              >
                <option value="All">All Severities</option>
                <option value="Warning">Warning</option>
                <option value="High">High</option>
                <option value="Critical">Critical</option>
              </select>
            </div>
          }
          emptyState={
            <EmptyState
              icon={<BookCheck className="h-6 w-6 text-[#10D9A0]" />}
              title="No overdue records in this filter"
              description="All matching loans are within their return window."
            />
          }
        />
      )}
    </div>
  );
}
