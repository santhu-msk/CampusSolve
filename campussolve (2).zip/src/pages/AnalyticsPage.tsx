import { useCallback, useEffect, useState } from 'react';
import { Download, Printer } from 'lucide-react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { api, ApiClientError } from '../services/api';
import { useToast } from '../context/ToastContext';
import type { AnalyticsPayload } from '../types/library';
import { AnimatedCounter, Button, ErrorPanel, TableSkeleton } from '../components/ui/Primitives';

const CATEGORIES = [
  'All',
  'Computer Science',
  'Natural Sciences',
  'Mathematics',
  'Humanities & Arts',
  'Economics & Law',
  'Engineering',
];

export function AnalyticsPage() {
  const { notify } = useToast();
  const [range, setRange] = useState<'30d' | '90d' | '6m' | '1y' | 'all'>('6m');
  const [category, setCategory] = useState('All');
  const [data, setData] = useState<AnalyticsPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadAnalytics = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getAnalytics({ range, category });
      setData(res);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'Unable to compute library analytics.');
    } finally {
      setLoading(false);
    }
  }, [range, category]);

  useEffect(() => {
    loadAnalytics();
  }, [loadAnalytics]);

  const handleExportSummary = () => {
    if (!data) return;
    const blob = new Blob([JSON.stringify({ range, category, generatedAt: new Date().toISOString(), ...data }, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `campussolve_analytics_${range}_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    notify({ type: 'success', title: 'Analytics summary exported', description: 'JSON snapshot downloaded.' });
  };

  const tooltipStyle = {
    backgroundColor: '#0B1224',
    border: '1px solid rgba(148,163,184,0.2)',
    borderRadius: '10px',
    color: '#F8FAFC',
    fontSize: '12px',
  };

  if (error) return <ErrorPanel message={error} onRetry={loadAnalytics} />;
  if (loading || !data) return <TableSkeleton rows={6} cols={4} />;

  const topCat = data.categoryDistribution[0];
  const topBook = data.topBooks[0];

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-[#F8FAFC]">
            Intelligent Analytics Centre
          </h1>
          <p className="text-sm text-slate-500 dark:text-[#94A3B8] mt-0.5">
            Every metric calculated directly from verified SQLite inventory, member, and transaction records.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 no-print">
          <select
            aria-label="Date range filter"
            value={range}
            onChange={(e) => setRange(e.target.value as typeof range)}
            className="h-9 px-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#101A31] text-slate-700 dark:text-slate-200"
          >
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
            <option value="6m">Last 6 Months</option>
            <option value="1y">Last 12 Months</option>
            <option value="all">All Time</option>
          </select>

          <select
            aria-label="Category filter"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="h-9 px-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#101A31] text-slate-700 dark:text-slate-200"
          >
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c === 'All' ? 'All Categories' : c}
              </option>
            ))}
          </select>

          <Button variant="outline" size="sm" onClick={() => window.print()}>
            <Printer className="h-3.5 w-3.5" />
            Print Report
          </Button>

          <Button size="sm" onClick={handleExportSummary}>
            <Download className="h-3.5 w-3.5" />
            Export Summary
          </Button>
        </div>
      </div>

      {/* Executive Summary Banner */}
      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-6">
        <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
          Executive Summary
        </h2>
        <p className="mt-1.5 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          The active collection comprises <strong className="font-mono">{data.kpis.totalBooks}</strong> titles across{' '}
          <strong className="font-mono">{data.kpis.totalCopies}</strong> physical copies, with{' '}
          <strong className="font-mono">{data.kpis.utilizationRate}%</strong> currently in circulation (
          <strong className="font-mono">{data.kpis.issuedBooks}</strong> copies checked out) and{' '}
          <strong className="font-mono">{data.kpis.totalReturns ?? 0}</strong> completed returns averaging{' '}
          <strong className="font-mono">{data.kpis.avgBooksIssuedPerMonth ?? 0}</strong> issues/month.
          {topCat && (
            <>
              {' '}
              The highest-demand discipline is <strong>{topCat.category}</strong> with{' '}
              <strong className="font-mono">{topCat.borrowCount}</strong> recorded loans.
            </>
          )}
          {topBook && (
            <>
              {' '}
              Most borrowed title: <strong>{topBook.title}</strong> ({topBook.borrowCount} checkouts).
            </>
          )}
        </p>

        <div className="mt-5 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 pt-5 border-t border-slate-200 dark:border-slate-800">
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">Inventory Utilization</p>
            <p className="mt-1 text-2xl font-display font-bold text-[#4388FF]">
              <AnimatedCounter value={data.kpis.utilizationRate} decimals={1} suffix="%" />
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">Active Borrowers</p>
            <p className="mt-1 text-2xl font-display font-bold text-[#10D9A0]">
              <AnimatedCounter value={data.kpis.activeMembers} />
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">Transactions in Scope</p>
            <p className="mt-1 text-2xl font-display font-bold text-[#925CFF]">
              <AnimatedCounter value={data.kpis.totalTransactions} />
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">Total Returns</p>
            <p className="mt-1 text-2xl font-display font-bold text-[#22D3EE]">
              <AnimatedCounter value={data.kpis.totalReturns ?? 0} />
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">Avg Issued / Month</p>
            <p className="mt-1 text-2xl font-display font-bold text-[#FFAD5A]">
              <AnimatedCounter value={data.kpis.avgBooksIssuedPerMonth ?? 0} decimals={2} />
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">Outstanding Fines</p>
            <p className="mt-1 text-2xl font-display font-bold text-[#FF6485]">
              <AnimatedCounter value={data.kpis.totalFinesOutstanding} decimals={2} prefix="$" />
            </p>
          </div>
        </div>
      </section>

      {/* Row 1: Monthly Circulation & Membership Growth */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
          <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Monthly Borrowing vs Return Patterns
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
            Issued, returned, and unresolved overdue trajectory
          </p>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data.monthlyTrends} margin={{ top: 8, right: 12, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.14)" />
                <XAxis dataKey="label" tick={{ fontSize: 12, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#94A3B8' }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Line type="monotone" dataKey="issued" name="Issued" stroke="#4388FF" strokeWidth={2.5} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="returned" name="Returned" stroke="#10D9A0" strokeWidth={2.5} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="overdue" name="Overdue" stroke="#FF6485" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
          <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Membership Growth Curve
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
            Cumulative registered campus members over 6 months
          </p>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.membershipGrowth} margin={{ top: 8, right: 12, left: -16, bottom: 0 }}>
                <defs>
                  <linearGradient id="gradMembers" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#925CFF" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#925CFF" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.14)" />
                <XAxis dataKey="label" tick={{ fontSize: 12, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#94A3B8' }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Area
                  type="monotone"
                  dataKey="cumulativeMembers"
                  name="Total Members"
                  stroke="#925CFF"
                  strokeWidth={2.5}
                  fill="url(#gradMembers)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Row 2: Popular Categories & Most Borrowed Books */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
          <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100 mb-4">
            Inventory Utilization by Category
          </h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.categoryDistribution} margin={{ top: 8, right: 12, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.14)" />
                <XAxis dataKey="category" tick={{ fontSize: 11, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#94A3B8' }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Bar dataKey="totalCopies" name="Total Copies" fill="#4388FF" radius={[5, 5, 0, 0]} />
                <Bar dataKey="availableCopies" name="Available" fill="#10D9A0" radius={[5, 5, 0, 0]} />
                <Bar dataKey="borrowCount" name="Loans" fill="#22D3EE" radius={[5, 5, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
          <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100 mb-4">
            Most Borrowed Titles
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500">
                  <th className="py-2 pr-3 font-medium">Title</th>
                  <th className="py-2 px-3 font-medium">Category</th>
                  <th className="py-2 px-3 font-medium text-right">Loans</th>
                  <th className="py-2 pl-3 font-medium text-right">Stock</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/70">
                {data.topBooks.map((b) => (
                  <tr key={b.id}>
                    <td className="py-2.5 pr-3">
                      <p className="font-medium text-slate-900 dark:text-slate-100 truncate max-w-[220px]">{b.title}</p>
                      <p className="text-xs text-slate-500 truncate max-w-[220px]">{b.author}</p>
                    </td>
                    <td className="py-2.5 px-3 text-xs text-slate-500">{b.category}</td>
                    <td className="py-2.5 px-3 text-right font-mono font-semibold text-[#4388FF]">{b.borrowCount}</td>
                    <td className="py-2.5 pl-3 text-right font-mono text-xs">
                      {b.availableCopies}/{b.totalCopies}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
