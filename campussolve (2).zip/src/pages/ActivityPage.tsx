import { useCallback, useEffect, useState } from 'react';
import { Activity } from 'lucide-react';
import { api, ApiClientError } from '../services/api';
import type { ActivityLog } from '../types/library';
import { EmptyState, ErrorPanel, StatusIndicator, TableSkeleton } from '../components/ui/Primitives';

export function ActivityPage() {
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [actionFilter, setActionFilter] = useState('All');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadActivities = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getActivity({ action_type: actionFilter, search, limit: 100 });
      setActivities(res.activities);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'Unable to fetch activity log.');
    } finally {
      setLoading(false);
    }
  }, [actionFilter, search]);

  useEffect(() => {
    loadActivities();
  }, [loadActivities]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-[#F8FAFC]">
          Activity Centre & Audit Trail
        </h1>
        <p className="text-sm text-slate-500 dark:text-[#94A3B8] mt-0.5">
          Chronological system ledger of book additions, circulation events, member updates, imports, and policy changes.
        </p>
      </div>

      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-4 flex flex-wrap items-center gap-3">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search audit entries..."
          className="flex-1 min-w-[200px] h-9 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
        />
        <select
          value={actionFilter}
          onChange={(e) => setActionFilter(e.target.value)}
          className="h-9 px-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-700 dark:text-slate-200"
        >
          <option value="All">All Event Types</option>
          <option value="BOOK_ISSUED">Book Issued</option>
          <option value="BOOK_RETURNED">Book Returned</option>
          <option value="BOOK_ADDED">Book Added</option>
          <option value="BOOK_UPDATED">Book Updated</option>
          <option value="MEMBER_REGISTERED">Member Registered</option>
          <option value="DATA_IMPORTED">Data Imported</option>
          <option value="REPORT_GENERATED">Report Generated</option>
          <option value="SETTINGS_UPDATED">Settings Updated</option>
        </select>
      </div>

      {error && <ErrorPanel message={error} onRetry={loadActivities} />}

      {loading ? (
        <TableSkeleton rows={7} cols={4} />
      ) : activities.length === 0 ? (
        <EmptyState
          icon={<Activity className="h-6 w-6" />}
          title="No audit events found"
          description="Try clearing the search or event type filter."
        />
      ) : (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] divide-y divide-slate-100 dark:divide-slate-800/80">
          {activities.map((a) => (
            <div key={a.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start sm:items-center gap-3 min-w-0">
                <StatusIndicator
                  status={
                    a.action_type.includes('RETURN')
                      ? 'Returned'
                      : a.action_type.includes('ISSUE')
                        ? 'Issued'
                        : a.action_type.includes('DELETE')
                          ? 'Overdue'
                          : 'Active'
                  }
                />
                <div className="min-w-0">
                  <p className="text-sm font-medium text-slate-900 dark:text-slate-100">{a.summary}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-mono mt-0.5">
                    {a.action_type} · {a.entity_type} ({a.entity_id}) · Actor: {a.actor}
                  </p>
                </div>
              </div>
              <span className="text-xs font-mono text-slate-500 dark:text-slate-400 shrink-0">
                {new Date(a.created_at).toLocaleString()}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
