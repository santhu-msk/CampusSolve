import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { BookOpen, Eye, LayoutGrid, Pencil, Plus, Table2, Trash2 } from 'lucide-react';
import { api, ApiClientError } from '../services/api';
import { useToast } from '../context/ToastContext';
import type { Book } from '../types/library';
import { DataTable, type ColumnDef } from '../components/ui/DataTable';
import {
  BookCover,
  Button,
  ConfirmDialog,
  EmptyState,
  ErrorPanel,
  Modal,
  StatusIndicator,
  TableSkeleton,
} from '../components/ui/Primitives';

const CATEGORIES = [
  'Computer Science',
  'Natural Sciences',
  'Mathematics',
  'Humanities & Arts',
  'Economics & Law',
  'Engineering',
];

const EMPTY_FORM = {
  id: '',
  isbn: '',
  title: '',
  author: '',
  category: 'Computer Science',
  publisher: '',
  publication_year: 2024,
  shelf_location: 'CS-A1-01',
  total_copies: 4,
  available_copies: 4,
  description: '',
};

export function BooksPage() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { notify } = useToast();

  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'table' | 'catalogue'>('table');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [availabilityFilter, setAvailabilityFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const [modalOpen, setModalOpen] = useState(false);
  const [editingBook, setEditingBook] = useState<Book | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const [deleteTarget, setDeleteTarget] = useState<Book | null>(null);
  const [deleting, setDeleting] = useState(false);

  const fetchBooks = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getBooks();
      setBooks(res.books);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'Unable to fetch book catalogue.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchBooks();
  }, [fetchBooks]);

  useEffect(() => {
    if (searchParams.get('action') === 'new') {
      openCreateModal();
      setSearchParams({}, { replace: true });
    }
  }, [searchParams, setSearchParams]);

  const openCreateModal = () => {
    setEditingBook(null);
    setForm(EMPTY_FORM);
    setFormError(null);
    setModalOpen(true);
  };

  const openEditModal = (book: Book, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setEditingBook(book);
    setForm({
      id: book.id,
      isbn: book.isbn,
      title: book.title,
      author: book.author,
      category: book.category,
      publisher: book.publisher,
      publication_year: book.publication_year,
      shelf_location: book.shelf_location,
      total_copies: book.total_copies,
      available_copies: book.available_copies,
      description: book.description,
    });
    setFormError(null);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!form.isbn.trim() || !form.title.trim() || !form.author.trim() || !form.publisher.trim()) {
      setFormError('ISBN, Title, Author, and Publisher are required.');
      return;
    }
    if (form.available_copies > form.total_copies) {
      setFormError('Available copies cannot exceed total copies.');
      return;
    }

    setSaving(true);
    try {
      if (editingBook) {
        await api.updateBook(editingBook.id, {
          isbn: form.isbn,
          title: form.title,
          author: form.author,
          category: form.category,
          publisher: form.publisher,
          shelf_location: form.shelf_location,
          description: form.description,
          publication_year: Number(form.publication_year),
          total_copies: Number(form.total_copies),
          available_copies: Number(form.available_copies),
        });
        notify({ type: 'success', title: 'Book updated', description: `"${form.title}" saved to database.` });
      } else {
        await api.createBook({
          ...(form.id.trim() ? { id: form.id.trim() } : {}),
          isbn: form.isbn,
          title: form.title,
          author: form.author,
          category: form.category,
          publisher: form.publisher,
          shelf_location: form.shelf_location,
          description: form.description,
          publication_year: Number(form.publication_year),
          total_copies: Number(form.total_copies),
          available_copies: Number(form.available_copies),
        });
        notify({ type: 'success', title: 'Book added', description: `"${form.title}" indexed in catalogue.` });
      }
      setModalOpen(false);
      await fetchBooks();
    } catch (err) {
      const msg = err instanceof ApiClientError ? err.message : 'Failed to save book record.';
      setFormError(msg);
      notify({ type: 'error', title: 'Save rejected', description: msg });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await api.deleteBook(deleteTarget.id);
      notify({
        type: 'success',
        title: 'Book removed',
        description: `"${deleteTarget.title}" deleted from catalogue.`,
      });
      setDeleteTarget(null);
      await fetchBooks();
    } catch (err) {
      const msg = err instanceof ApiClientError ? err.message : 'Unable to delete book.';
      notify({ type: 'error', title: 'Delete blocked', description: msg });
      setDeleteTarget(null);
    } finally {
      setDeleting(false);
    }
  };

  const filteredBooks = useMemo(() => {
    return books.filter((b) => {
      if (categoryFilter !== 'All' && b.category !== categoryFilter) return false;
      if (availabilityFilter !== 'All' && b.availability_status !== availabilityFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          b.id.toLowerCase().includes(q) ||
          b.isbn.toLowerCase().includes(q) ||
          b.title.toLowerCase().includes(q) ||
          b.author.toLowerCase().includes(q) ||
          b.publisher.toLowerCase().includes(q) ||
          b.category.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [books, categoryFilter, availabilityFilter, searchQuery]);

  const columns: ColumnDef<Book>[] = [
    {
      key: 'id',
      header: 'Book ID',
      sortable: true,
      sortValue: (b) => b.id,
      render: (b) => <span className="font-mono text-xs font-semibold text-[#4388FF]">{b.id}</span>,
    },
    {
      key: 'cover',
      header: 'Cover',
      render: (b) => (
        <BookCover
          title={b.title}
          author={b.author}
          category={b.category}
          coverImage={b.cover_image}
          size="sm"
        />
      ),
    },
    {
      key: 'isbn',
      header: 'ISBN',
      sortable: true,
      sortValue: (b) => b.isbn,
      render: (b) => <span className="font-mono text-xs text-slate-600 dark:text-slate-300">{b.isbn}</span>,
    },
    {
      key: 'title',
      header: 'Book Title',
      sortable: true,
      sortValue: (b) => b.title,
      render: (b) => (
        <div className="max-w-[260px]">
          <p className="font-medium text-slate-900 dark:text-slate-100 truncate" title={b.title}>
            {b.title}
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
            Shelf {b.shelf_location} · {b.publication_year}
          </p>
        </div>
      ),
    },
    {
      key: 'author',
      header: 'Author',
      sortable: true,
      sortValue: (b) => b.author,
      render: (b) => <span className="text-sm text-slate-700 dark:text-slate-300 max-w-[180px] block truncate">{b.author}</span>,
    },
    {
      key: 'category',
      header: 'Category',
      sortable: true,
      sortValue: (b) => b.category,
      render: (b) => <span className="text-xs text-slate-600 dark:text-slate-300">{b.category}</span>,
    },
    {
      key: 'publisher',
      header: 'Publisher',
      sortable: true,
      sortValue: (b) => b.publisher,
      render: (b) => <span className="text-xs text-slate-500 dark:text-slate-400">{b.publisher}</span>,
    },
    {
      key: 'total_copies',
      header: 'Total',
      align: 'right',
      sortable: true,
      sortValue: (b) => b.total_copies,
      render: (b) => <span className="font-mono tabular-nums">{b.total_copies}</span>,
    },
    {
      key: 'available_copies',
      header: 'Available',
      align: 'right',
      sortable: true,
      sortValue: (b) => b.available_copies,
      render: (b) => <span className="font-mono tabular-nums font-semibold">{b.available_copies}</span>,
    },
    {
      key: 'availability_status',
      header: 'Status',
      sortable: true,
      sortValue: (b) => b.availability_status,
      render: (b) => <StatusIndicator status={b.availability_status} />,
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (b) => (
        <div className="inline-flex items-center justify-end gap-1" onClick={(e) => e.stopPropagation()}>
          <button
            type="button"
            title="View book details"
            onClick={() => navigate(`/books/${b.id}`)}
            className="p-1.5 rounded-lg text-slate-500 hover:text-[#4388FF] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Eye className="h-4 w-4" />
          </button>
          <button
            type="button"
            title="Edit book"
            onClick={(e) => openEditModal(b, e)}
            className="p-1.5 rounded-lg text-slate-500 hover:text-[#10D9A0] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Pencil className="h-4 w-4" />
          </button>
          <button
            type="button"
            title="Delete book"
            onClick={() => setDeleteTarget(b)}
            className="p-1.5 rounded-lg text-slate-500 hover:text-[#FF6485] hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-[#F8FAFC]">
            Book Inventory & Catalogue
          </h1>
          <p className="text-sm text-slate-500 dark:text-[#94A3B8] mt-0.5">
            {books.length} unique titles · {books.reduce((s, b) => s + b.total_copies, 0)} physical copies managed
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <div className="inline-flex p-1 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-[#0B1224]">
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-white dark:bg-[#101A31] text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <Table2 className="h-3.5 w-3.5" />
              Table
            </button>
            <button
              type="button"
              onClick={() => setViewMode('catalogue')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                viewMode === 'catalogue'
                  ? 'bg-white dark:bg-[#101A31] text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <LayoutGrid className="h-3.5 w-3.5" />
              Catalogue
            </button>
          </div>

          <Button onClick={openCreateModal}>
            <Plus className="h-4 w-4" />
            Add Book
          </Button>
        </div>
      </div>

      {error && <ErrorPanel message={error} onRetry={fetchBooks} />}

      {loading ? (
        <TableSkeleton rows={7} cols={7} />
      ) : viewMode === 'table' ? (
        <DataTable
          data={filteredBooks}
          columns={columns}
          rowKey={(b) => b.id}
          externalSearch={searchQuery}
          onExternalSearchChange={setSearchQuery}
          searchPlaceholder="Search ISBN, title, author, publisher..."
          searchFilter={() => true}
          onRowClick={(b) => navigate(`/books/${b.id}`)}
          exportFilename="campussolve_books_catalogue.csv"
          toolbarExtras={
            <div className="flex flex-wrap items-center gap-2">
              <select
                aria-label="Filter by category"
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="h-9 px-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
              >
                <option value="All">All Categories</option>
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>

              <select
                aria-label="Filter by availability"
                value={availabilityFilter}
                onChange={(e) => setAvailabilityFilter(e.target.value)}
                className="h-9 px-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
              >
                <option value="All">All Statuses</option>
                <option value="Available">Available</option>
                <option value="Low Stock">Low Stock</option>
                <option value="Out of Stock">Out of Stock</option>
              </select>
            </div>
          }
          emptyState={
            <EmptyState
              icon={<BookOpen className="h-6 w-6" />}
              title="No matching books found"
              description="Adjust your filters or add a new book title to the library catalogue."
              action={
                <Button size="sm" onClick={openCreateModal}>
                  <Plus className="h-4 w-4" />
                  Add Book
                </Button>
              }
            />
          }
        />
      ) : (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-3 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31]">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter visual catalogue..."
              className="flex-1 min-w-[220px] h-9 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
            />
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="h-9 px-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-700 dark:text-slate-200"
            >
              <option value="All">All Categories</option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
            <select
              value={availabilityFilter}
              onChange={(e) => setAvailabilityFilter(e.target.value)}
              className="h-9 px-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-700 dark:text-slate-200"
            >
              <option value="All">All Statuses</option>
              <option value="Available">Available</option>
              <option value="Low Stock">Low Stock</option>
              <option value="Out of Stock">Out of Stock</option>
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredBooks.map((b) => (
              <div
                key={b.id}
                onClick={() => navigate(`/books/${b.id}`)}
                className="group rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-4 flex flex-col justify-between gap-4 hover:border-[#4388FF]/45 transition-all cursor-pointer"
              >
                <div className="flex gap-4">
                  <BookCover
                    title={b.title}
                    author={b.author}
                    category={b.category}
                    isbn={b.isbn}
                    coverImage={b.cover_image}
                    size="md"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-mono text-[#4388FF]">{b.id}</p>
                    <h3 className="mt-1 font-display text-sm font-semibold text-slate-900 dark:text-slate-100 line-clamp-2">
                      {b.title}
                    </h3>
                    <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 truncate">{b.author}</p>
                    <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400">
                      <span>{b.category}</span>
                      <span aria-hidden="true"> · </span>
                      <span>{b.publication_year}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                  <StatusIndicator status={b.availability_status} />
                  <span className="text-xs font-mono tabular-nums text-slate-600 dark:text-slate-300">
                    {b.available_copies} / {b.total_copies} avail
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add / Edit Book Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingBook ? `Edit Book · ${editingBook.id}` : 'Add New Book to Catalogue'}
        subtitle="All fields are validated and persisted directly to SQLite."
        maxWidth="max-w-2xl"
      >
        <form onSubmit={handleSave} className="space-y-4">
          {formError && (
            <div className="p-3 rounded-lg border border-rose-500/30 bg-rose-500/10 text-xs text-rose-700 dark:text-[#FF6485]">
              {formError}
            </div>
          )}

          {!editingBook && (
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Book ID (Optional — auto-generated if blank)
              </label>
              <input
                type="text"
                value={form.id}
                onChange={(e) => setForm({ ...form, id: e.target.value })}
                placeholder="e.g., BK-1100"
                className="w-full h-10 px-3 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
              />
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                ISBN-13 / Identifier *
              </label>
              <input
                type="text"
                required
                value={form.isbn}
                onChange={(e) => setForm({ ...form, isbn: e.target.value })}
                placeholder="978-0262046305"
                className="w-full h-10 px-3 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Category *
              </label>
              <select
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
              Book Title *
            </label>
            <input
              type="text"
              required
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="e.g., Designing Distributed Systems"
              className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Author(s) *
              </label>
              <input
                type="text"
                required
                value={form.author}
                onChange={(e) => setForm({ ...form, author: e.target.value })}
                placeholder="Author name"
                className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Publisher *
              </label>
              <input
                type="text"
                required
                value={form.publisher}
                onChange={(e) => setForm({ ...form, publisher: e.target.value })}
                placeholder="e.g., MIT Press"
                className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">Year</label>
              <input
                type="number"
                min={1450}
                max={2030}
                value={form.publication_year}
                onChange={(e) => setForm({ ...form, publication_year: Number(e.target.value) })}
                className="w-full h-10 px-3 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">Shelf Code</label>
              <input
                type="text"
                value={form.shelf_location}
                onChange={(e) => setForm({ ...form, shelf_location: e.target.value })}
                className="w-full h-10 px-3 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">Total Copies *</label>
              <input
                type="number"
                min={0}
                value={form.total_copies}
                onChange={(e) => {
                  const nextTotal = Math.max(0, Number(e.target.value));
                  setForm({
                    ...form,
                    total_copies: nextTotal,
                    available_copies: editingBook ? Math.min(form.available_copies, nextTotal) : nextTotal,
                  });
                }}
                className="w-full h-10 px-3 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">Available *</label>
              <input
                type="number"
                min={0}
                max={form.total_copies}
                value={form.available_copies}
                onChange={(e) => setForm({ ...form, available_copies: Number(e.target.value) })}
                className="w-full h-10 px-3 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">Description</label>
            <textarea
              rows={3}
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              placeholder="Abstract, edition notes, or academic scope..."
              className="w-full p-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? 'Saving...' : editingBook ? 'Save Changes' : 'Add Book'}
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Book Record"
        description={`Are you sure you want to permanently remove "${deleteTarget?.title ?? ''}" (${deleteTarget?.id ?? ''})? Books with active checkouts or historical audit records cannot be deleted.`}
      />
    </div>
  );
}
