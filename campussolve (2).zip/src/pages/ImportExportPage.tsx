import React, { useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle2, Download, FileSpreadsheet, Upload, XCircle } from 'lucide-react';
import { api, ApiClientError } from '../services/api';
import { useToast } from '../context/ToastContext';
import type { ImportPreviewResponse, SyncStatus } from '../types/library';
import { Button } from '../components/ui/Primitives';

export function ImportExportPage() {
  const { notify } = useToast();

  const [entity, setEntity] = useState<'books' | 'members'>('books');
  const [format, setFormat] = useState<'csv' | 'json'>('csv');
  const [fileName, setFileName] = useState<string>('');
  const [rawContent, setRawContent] = useState<string>('');
  const [dragActive, setDragActive] = useState(false);

  const [preview, setPreview] = useState<ImportPreviewResponse | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [importing, setImporting] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);

  const [exportEntity, setExportEntity] = useState<'books' | 'members' | 'transactions' | 'overdue'>('books');
  const [exportFormat, setExportFormat] = useState<'csv' | 'json'>('csv');
  const [exporting, setExporting] = useState(false);
  const [syncStatus, setSyncStatus] = useState<SyncStatus | null>(null);

  useEffect(() => {
    api.getSyncStatus().then(setSyncStatus).catch(() => {});
  }, []);

  const runPreview = async (targetEntity: 'books' | 'members', targetFormat: 'csv' | 'json', content: string) => {
    setPreviewLoading(true);
    setImportError(null);
    setPreview(null);
    try {
      const res = await api.previewImport({ entity: targetEntity, format: targetFormat, content });
      setPreview(res);
    } catch (err) {
      setImportError(err instanceof ApiClientError ? err.message : 'Unable to parse and validate file.');
    } finally {
      setPreviewLoading(false);
    }
  };

  const handleFile = async (file: File) => {
    const lower = file.name.toLowerCase();
    if (!lower.endsWith('.csv') && !lower.endsWith('.json')) {
      setPreview(null);
      setFileName(file.name);
      setImportError('Unsupported file format. Please upload a .csv or .json dataset file.');
      return;
    }
    const text = await file.text();
    const detectedFormat: 'csv' | 'json' =
      lower.endsWith('.json') || text.trim().startsWith('[') ? 'json' : 'csv';
    setFileName(file.name);
    setFormat(detectedFormat);
    setRawContent(text);
    await runPreview(entity, detectedFormat, text);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    const file = e.dataTransfer.files?.[0];
    if (file) await handleFile(file);
  };

  const handleCommitImport = async () => {
    if (!rawContent.trim()) return;
    setImporting(true);
    setImportError(null);
    try {
      const res = await api.commitImport({ entity, format, content: rawContent });
      notify({
        type: 'success',
        title: `Imported ${res.importedCount} ${entity}`,
        description:
          res.skippedCount > 0 ? `${res.skippedCount} duplicate/invalid row(s) skipped.` : 'All rows committed & synced.',
      });
      api.getSyncStatus().then(setSyncStatus).catch(() => {});
      await runPreview(entity, format, rawContent);
    } catch (err) {
      const msg = err instanceof ApiClientError ? err.message : 'Import failed.';
      setImportError(msg);
      notify({ type: 'error', title: 'Import failed', description: msg });
    } finally {
      setImporting(false);
    }
  };

  const handleDownloadErrors = () => {
    if (!preview) return;
    const badRows = preview.rows.filter((r) => !r.valid);
    const lines = ['row_number,duplicate,errors,raw_json'];
    for (const r of badRows) {
      lines.push(
        `${r.rowNumber},${r.isDuplicate},"${r.errors.join('; ').replace(/"/g, '""')}","${JSON.stringify(r.raw).replace(/"/g, '""')}"`
      );
    }
    const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `campussolve_import_errors_${entity}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExport = async () => {
    setExporting(true);
    try {
      const res = await api.exportData(exportEntity, exportFormat);
      const blob = new Blob([res.content], {
        type: exportFormat === 'json' ? 'application/json' : 'text/csv;charset=utf-8;',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `campussolve_${exportEntity}_${new Date().toISOString().slice(0, 10)}.${exportFormat}`;
      a.click();
      URL.revokeObjectURL(url);
      notify({
        type: 'success',
        title: 'Export downloaded',
        description: `${res.count} ${exportEntity} record(s) exported as ${exportFormat.toUpperCase()}.`,
      });
    } catch (err) {
      notify({
        type: 'error',
        title: 'Export failed',
        description: err instanceof ApiClientError ? err.message : 'Failed to export dataset.',
      });
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-[#F8FAFC]">
          Import & Export Centre
        </h1>
        <p className="text-sm text-slate-500 dark:text-[#94A3B8] mt-0.5">
          Drag-and-drop CSV/JSON ingestion with column detection, duplicate verification, row-level validation, and error reports.
        </p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        {/* Import Workspace */}
        <div className="xl:col-span-8 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="inline-flex p-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-[#0B1224]">
                {(['books', 'members'] as const).map((ent) => (
                  <button
                    key={ent}
                    type="button"
                    onClick={() => {
                      setEntity(ent);
                      setPreview(null);
                    }}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md capitalize cursor-pointer ${
                      entity === ent
                        ? 'bg-white dark:bg-[#101A31] text-slate-900 dark:text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    Import {ent}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={async () => {
                  try {
                    setEntity('books');
                    setPreviewLoading(true);
                    const sample = await api.getImportSample('books');
                    setFormat(sample.format);
                    setFileName(sample.filename);
                    setRawContent(sample.content);
                    await runPreview('books', sample.format, sample.content);
                  } catch (err) {
                    setPreviewLoading(false);
                    setImportError(err instanceof ApiClientError ? err.message : 'Unable to load sample CSV.');
                  }
                }}
              >
                Load Sample Books CSV (38)
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={async () => {
                  try {
                    setEntity('members');
                    setPreviewLoading(true);
                    const sample = await api.getImportSample('members');
                    setFormat(sample.format);
                    setFileName(sample.filename);
                    setRawContent(sample.content);
                    await runPreview('members', sample.format, sample.content);
                  } catch (err) {
                    setPreviewLoading(false);
                    setImportError(err instanceof ApiClientError ? err.message : 'Unable to load sample JSON.');
                  }
                }}
              >
                Load Sample Members JSON (35)
              </Button>
            </div>
          </div>

          {/* Drop Zone */}
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragActive(true);
            }}
            onDragLeave={() => setDragActive(false)}
            onDrop={handleDrop}
            className={`rounded-xl border-2 border-dashed p-8 text-center transition-colors ${
              dragActive
                ? 'border-[#4388FF] bg-[#4388FF]/10'
                : 'border-slate-300 dark:border-slate-700 bg-slate-50/70 dark:bg-[#0B1224]'
            }`}
          >
            <Upload className="h-8 w-8 text-[#4388FF] mx-auto mb-3" />
            <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
              {fileName ? `Loaded: ${fileName} (${format.toUpperCase()})` : 'Drop a .csv or .json file here, or browse'}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Supports 30–50+ entry batch files · Automatic format & duplicate detection
            </p>
            <label className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#4388FF] hover:bg-[#3377F0] text-white text-xs font-medium cursor-pointer">
              <FileSpreadsheet className="h-3.5 w-3.5" />
              Choose File
              <input
                type="file"
                accept=".csv,.json,text/csv,application/json"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleFile(file);
                }}
              />
            </label>
          </div>

          {importError && (
            <div className="p-3.5 rounded-xl border border-rose-500/30 bg-rose-500/10 text-xs text-rose-700 dark:text-[#FF6485]">
              {importError}
            </div>
          )}

          {previewLoading && <p className="text-xs text-slate-500">Validating uploaded rows...</p>}

          {preview && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#0B1224]">
                  <p className="text-xs text-slate-500">Total Rows</p>
                  <p className="text-lg font-mono font-bold">{preview.totalRows}</p>
                </div>
                <div className="p-3 rounded-xl border border-emerald-500/25 bg-emerald-500/5">
                  <p className="text-xs text-emerald-700 dark:text-[#10D9A0]">Ready to Import</p>
                  <p className="text-lg font-mono font-bold text-emerald-700 dark:text-[#10D9A0]">
                    {preview.validRows}
                  </p>
                </div>
                <div className="p-3 rounded-xl border border-amber-500/25 bg-amber-500/5">
                  <p className="text-xs text-amber-700 dark:text-[#FFAD5A]">Duplicates</p>
                  <p className="text-lg font-mono font-bold text-amber-700 dark:text-[#FFAD5A]">
                    {preview.duplicateRows}
                  </p>
                </div>
                <div className="p-3 rounded-xl border border-rose-500/25 bg-rose-500/5">
                  <p className="text-xs text-rose-700 dark:text-[#FF6485]">Invalid Rows</p>
                  <p className="text-lg font-mono font-bold text-rose-700 dark:text-[#FF6485]">
                    {preview.invalidRows}
                  </p>
                </div>
              </div>

              <div className="text-xs text-slate-500 dark:text-slate-400">
                Detected Columns: <span className="font-mono">{preview.detectedColumns.join(', ')}</span>
              </div>

              <div className="overflow-x-auto max-h-72 border border-slate-200 dark:border-slate-800 rounded-xl">
                <table className="w-full text-left border-collapse text-xs">
                  <thead className="bg-slate-50 dark:bg-[#0B1224] sticky top-0">
                    <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                      <th className="py-2 px-3">Row</th>
                      <th className="py-2 px-3">Summary</th>
                      <th className="py-2 px-3">Validation</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/70">
                    {preview.rows.map((r) => (
                      <tr key={r.rowNumber}>
                        <td className="py-2 px-3 font-mono">{r.rowNumber}</td>
                        <td className="py-2 px-3">
                          {entity === 'books'
                            ? `${String(r.normalized.title || '—')} (${String(r.normalized.isbn || '—')})`
                            : `${String(r.normalized.full_name || '—')} (${String(r.normalized.email || '—')})`}
                        </td>
                        <td className="py-2 px-3">
                          {r.valid ? (
                            <span className="inline-flex items-center gap-1 text-[#10D9A0] font-medium">
                              <CheckCircle2 className="h-3.5 w-3.5" />
                              Valid
                            </span>
                          ) : r.isDuplicate ? (
                            <span className="inline-flex items-center gap-1 text-[#FFAD5A] font-medium">
                              <AlertTriangle className="h-3.5 w-3.5" />
                              {r.errors.join('; ')}
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[#FF6485] font-medium">
                              <XCircle className="h-3.5 w-3.5" />
                              {r.errors.join('; ')}
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3">
                {preview.invalidRows > 0 ? (
                  <Button variant="outline" size="sm" onClick={handleDownloadErrors}>
                    <Download className="h-3.5 w-3.5" />
                    Download Error Report CSV
                  </Button>
                ) : (
                  <span />
                )}
                <Button disabled={preview.validRows === 0 || importing} onClick={handleCommitImport}>
                  {importing ? 'Importing...' : `Confirm Import (${preview.validRows} Valid Rows)`}
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Export Panel */}
        <div className="xl:col-span-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-6 space-y-5">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Database Export Centre
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Download live snapshots from SQLite in CSV or JSON format.
          </p>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">Dataset</label>
            <select
              value={exportEntity}
              onChange={(e) => setExportEntity(e.target.value as typeof exportEntity)}
              className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
            >
              <option value="books">Books Catalogue</option>
              <option value="members">Member Directory</option>
              <option value="transactions">Circulation Transactions</option>
              <option value="overdue">Overdue Monitoring Queue</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">Format</label>
            <div className="grid grid-cols-2 gap-2">
              {(['csv', 'json'] as const).map((fmt) => (
                <button
                  key={fmt}
                  type="button"
                  onClick={() => setExportFormat(fmt)}
                  className={`py-2 rounded-lg border text-xs font-medium uppercase cursor-pointer ${
                    exportFormat === fmt
                      ? 'border-[#4388FF] bg-[#4388FF] text-white'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {fmt}
                </button>
              ))}
            </div>
          </div>

          <Button className="w-full" onClick={handleExport} disabled={exporting}>
            <Download className="h-4 w-4" />
            {exporting ? 'Exporting...' : `Download ${exportEntity.toUpperCase()} (${exportFormat.toUpperCase()})`}
          </Button>

          {syncStatus && (
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-500 dark:text-slate-400">Auto-Synced CSV/JSON Store</span>
                <span className="font-mono font-semibold text-[#10D9A0]">{syncStatus.status}</span>
              </div>
              <p className="text-[11px] font-mono text-slate-500">
                books: {syncStatus.files['books.csv'] ?? 0} · members: {syncStatus.files['members.csv'] ?? 0} · txns:{' '}
                {syncStatus.files['transactions.csv'] ?? 0}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
