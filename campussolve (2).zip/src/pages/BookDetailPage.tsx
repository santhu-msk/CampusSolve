import { useCallback, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, BookPlus, Calendar, Layers, MapPin } from 'lucide-react';
import { api, ApiClientError } from '../services/api';
import type { Book, TransactionRecord } from '../types/library';
import { BookCover, Button, ErrorPanel, StatusIndicator, TableSkeleton } from '../components/ui/Primitives';

export function BookDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [book, setBook] = useState<Book | null>(null);
  const [transactions, setTransactions] = useState<TransactionRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadBook = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    setError(null);
    try {
      const res = await api.getBook(id);
      setBook(res.book);
      setTransactions(res.transactions);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'Unable to load book details.');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    loadBook();
  }, [loadBook]);

  if (loading) return <TableSkeleton rows={5} cols={4} />;
  if (error || !book) {
    return (
      <div className="space-y-4">
        <Button variant="outline" size="sm" onClick={() => navigate('/books')}>
          <ArrowLeft className="h-4 w-4" />
          Back to Catalogue
        </Button>
        <ErrorPanel message={error ?? 'Book not found.'} onRetry={loadBook} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <Button variant="outline" size="sm" onClick={() => navigate('/books')}>
          <ArrowLeft className="h-4 w-4" />
          Back to Books
        </Button>

        <Button
          size="sm"
          disabled={book.available_copies <= 0}
          onClick={() => navigate(`/issue?bookId=${encodeURIComponent(book.id)}`)}
        >
          <BookPlus className="h-4 w-4" />
          {book.available_copies > 0 ? 'Issue This Book' : 'Out of Stock'}
        </Button>
      </div>

      {/* Book Detail Hero */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-6 sm:p-8 flex flex-col md:flex-row gap-8">
        <BookCover
          title={book.title}
          author={book.author}
          category={book.category}
          isbn={book.isbn}
          coverImage={book.cover_image}
          size="lg"
        />

        <div className="flex-1 min-w-0 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-500 dark:text-slate-400">
              <span className="text-[#4388FF] font-semibold">{book.id}</span>
              <span aria-hidden="true">·</span>
              <span>ISBN {book.isbn}</span>
              <span aria-hidden="true">·</span>
              <span>{book.category}</span>
            </div>
            <StatusIndicator status={book.availability_status} />
          </div>

          <div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-[#F8FAFC] text-balance">
              {book.title}
            </h1>
            <p className="mt-1 text-base text-slate-600 dark:text-[#94A3B8]">
              by <span className="font-medium text-slate-900 dark:text-slate-100">{book.author}</span>
            </p>
          </div>

          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-3xl">
            {book.description || 'No catalog synopsis recorded for this edition.'}
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-slate-200 dark:border-slate-800">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Layers className="h-3.5 w-3.5" />
                Publisher
              </p>
              <p className="mt-1 text-sm font-semibold text-slate-900 dark:text-slate-100">{book.publisher}</p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Calendar className="h-3.5 w-3.5" />
                Publication Year
              </p>
              <p className="mt-1 text-sm font-mono font-semibold text-slate-900 dark:text-slate-100">
                {book.publication_year}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <MapPin className="h-3.5 w-3.5" />
                Shelf Location
              </p>
              <p className="mt-1 text-sm font-mono font-semibold text-slate-900 dark:text-slate-100">
                {book.shelf_location}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Copy Inventory</p>
              <p className="mt-1 text-sm font-mono font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
                {book.available_copies} available / {book.total_copies} total
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Book Circulation History */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
        <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100 mb-4">
          Circulation & Borrowing History ({transactions.length})
        </h2>
        {transactions.length === 0 ? (
          <p className="text-sm text-slate-500 dark:text-slate-400 py-6 text-center">
            No transactions recorded for this title yet.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
                  <th className="py-2.5 pr-4 font-medium">Transaction ID</th>
                  <th className="py-2.5 px-4 font-medium">Member</th>
                  <th className="py-2.5 px-4 font-medium">Issue Date</th>
                  <th className="py-2.5 px-4 font-medium">Due Date</th>
                  <th className="py-2.5 px-4 font-medium">Return Date</th>
                  <th className="py-2.5 pl-4 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/70">
                {transactions.map((t) => (
                  <tr key={t.id} className="hover:bg-slate-50 dark:hover:bg-[#172544]/40">
                    <td className="py-3 pr-4 font-mono text-xs font-semibold text-[#4388FF]">{t.id}</td>
                    <td className="py-3 px-4">
                      <button
                        type="button"
                        onClick={() => navigate(`/members/${t.member_id}`)}
                        className="font-medium text-slate-900 dark:text-slate-100 hover:text-[#4388FF] cursor-pointer text-left"
                      >
                        {t.member_name}
                      </button>
                      <span className="block text-xs text-slate-500 font-mono">{t.member_id}</span>
                    </td>
                    <td className="py-3 px-4 font-mono text-xs">{t.issue_date}</td>
                    <td className="py-3 px-4 font-mono text-xs">{t.due_date}</td>
                    <td className="py-3 px-4 font-mono text-xs">{t.return_date ?? 'Active Loan'}</td>
                    <td className="py-3 pl-4">
                      <StatusIndicator status={t.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
