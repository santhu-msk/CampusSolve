import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { AlertCircle, BookOpen, BookPlus, CheckCircle2, UserCheck } from 'lucide-react';
import { api, ApiClientError } from '../services/api';
import { useToast } from '../context/ToastContext';
import type { Book, Member, TransactionRecord } from '../types/library';
import { BookCover, Button, ErrorPanel, StatusIndicator } from '../components/ui/Primitives';

function addDaysIso(baseIso: string, days: number): string {
  const d = new Date(`${baseIso}T00:00:00Z`);
  if (Number.isNaN(d.getTime())) return baseIso;
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

export function IssueBookPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { notify } = useToast();

  const today = new Date().toISOString().slice(0, 10);

  const [books, setBooks] = useState<Book[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [activeIssues, setActiveIssues] = useState<TransactionRecord[]>([]);
  const [defaultLoanDays, setDefaultLoanDays] = useState(14);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [memberId, setMemberId] = useState(searchParams.get('memberId') ?? '');
  const [bookId, setBookId] = useState(searchParams.get('bookId') ?? '');
  const [issueDate, setIssueDate] = useState(today);
  const [dueDate, setDueDate] = useState(addDaysIso(today, 14));
  const [notes, setNotes] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [lastIssued, setLastIssued] = useState<TransactionRecord | null>(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const [bRes, mRes, iRes, sRes] = await Promise.all([
        api.getBooks(),
        api.getMembers(),
        api.getActiveIssues(),
        api.getSettings(),
      ]);
      setBooks(bRes.books);
      setMembers(mRes.members);
      setActiveIssues(iRes.issues);
      const loanDays = sRes.settings.default_loan_days || 14;
      setDefaultLoanDays(loanDays);
      setDueDate(addDaysIso(today, loanDays));
    } catch (err) {
      setLoadError(err instanceof ApiClientError ? err.message : 'Failed to load issue workflow data.');
    } finally {
      setLoading(false);
    }
  }, [today]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const matchedMember = useMemo(
    () => members.find((m) => m.id.toUpperCase() === memberId.trim().toUpperCase()) ?? null,
    [members, memberId]
  );

  const matchedBook = useMemo(
    () => books.find((b) => b.id.toUpperCase() === bookId.trim().toUpperCase()) ?? null,
    [books, bookId]
  );

  const handleIssueSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);
    setLastIssued(null);

    if (!memberId.trim() || !bookId.trim()) {
      setSubmitError('Please enter or select both a Member ID and a Book ID.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await api.issueBook({
        member_id: memberId.trim().toUpperCase(),
        book_id: bookId.trim().toUpperCase(),
        issue_date: issueDate,
        due_date: dueDate,
        notes,
      });
      setLastIssued(res.transaction);
      notify({
        type: 'success',
        title: `Issued · ${res.transaction.id}`,
        description: `"${res.transaction.book_title}" assigned to ${res.transaction.member_name}.`,
      });
      setNotes('');
      await loadData();
    } catch (err) {
      const msg = err instanceof ApiClientError ? err.message : 'Unable to issue book.';
      setSubmitError(msg);
      notify({ type: 'error', title: 'Validation rejected', description: msg });
    } finally {
      setSubmitting(false);
    }
  };

  if (loadError) {
    return <ErrorPanel message={loadError} onRetry={loadData} />;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-[#F8FAFC]">
            Smart Issue Book Workflow
          </h1>
          <p className="text-sm text-slate-500 dark:text-[#94A3B8] mt-0.5">
            Automatic ID verification, borrow-limit enforcement, duplicate detection, and real-time stock updates.
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={() => navigate('/return')}>
          Switch to Return Workflow
        </Button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        {/* Issue Form */}
        <form
          onSubmit={handleIssueSubmit}
          className="xl:col-span-7 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-6 space-y-5"
        >
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              New Circulation Dispatch
            </h2>
            <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
              Standard Loan: {defaultLoanDays} days
            </span>
          </div>

          {submitError && (
            <div className="p-4 rounded-xl border border-rose-500/35 bg-rose-500/10 flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-[#FF6485] shrink-0 mt-0.5" />
              <div className="text-sm text-rose-700 dark:text-[#FF6485]">
                <p className="font-semibold">Issue Validation Failed</p>
                <p className="text-xs mt-0.5">{submitError}</p>
              </div>
            </div>
          )}

          {lastIssued && (
            <div className="p-4 rounded-xl border border-emerald-500/35 bg-emerald-500/10 flex items-start justify-between gap-4">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="h-5 w-5 text-[#10D9A0] shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-emerald-700 dark:text-[#10D9A0]">
                    Book Issued Successfully · {lastIssued.id}
                  </p>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                    "{lastIssued.book_title}" issued to {lastIssued.member_name} · Due {lastIssued.due_date}
                  </p>
                </div>
              </div>
              <Button size="sm" variant="outline" type="button" onClick={() => navigate('/transactions')}>
                View Ledger
              </Button>
            </div>
          )}

          {/* Member ID + Quick Picker */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                Member ID *
              </label>
              <input
                type="text"
                value={memberId}
                onChange={(e) => setMemberId(e.target.value)}
                placeholder="e.g., MEM-2001"
                className="w-full h-10 px-3 text-sm font-mono uppercase rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                Quick Select Member
              </label>
              <select
                value={matchedMember?.id ?? ''}
                onChange={(e) => setMemberId(e.target.value)}
                className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              >
                <option value="">Choose from directory...</option>
                {members.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.id} — {m.full_name} ({m.status})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Book ID + Quick Picker */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                Book ID *
              </label>
              <input
                type="text"
                value={bookId}
                onChange={(e) => setBookId(e.target.value)}
                placeholder="e.g., BK-1001"
                className="w-full h-10 px-3 text-sm font-mono uppercase rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4388FF]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                Quick Select Book
              </label>
              <select
                value={matchedBook?.id ?? ''}
                onChange={(e) => setBookId(e.target.value)}
                className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              >
                <option value="">Choose from catalogue...</option>
                {books.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.id} — {b.title} ({b.available_copies}/{b.total_copies} avail)
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
                Issue Date *
              </label>
              <input
                type="date"
                required
                value={issueDate}
                onChange={(e) => setIssueDate(e.target.value)}
                className="w-full h-10 px-3 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-medium text-slate-600 dark:text-slate-300">Due Date *</label>
                <div className="flex items-center gap-1.5">
                  {[7, 14, 30].map((days) => (
                    <button
                      key={days}
                      type="button"
                      onClick={() => setDueDate(addDaysIso(issueDate, days))}
                      className="px-2 py-0.5 text-[11px] font-mono rounded border border-slate-200 dark:border-slate-700 hover:border-[#4388FF] text-slate-500 dark:text-slate-300 cursor-pointer"
                    >
                      +{days}d
                    </button>
                  ))}
                </div>
              </div>
              <input
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full h-10 px-3 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5">
              Circulation Notes (Optional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g., Semester lab reference or reserve copy"
              className="w-full h-10 px-3 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B1224] text-slate-900 dark:text-slate-100"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setMemberId('');
                setBookId('');
                setNotes('');
                setSubmitError(null);
              }}
            >
              Reset
            </Button>
            <Button type="submit" disabled={submitting || loading}>
              <BookPlus className="h-4 w-4" />
              {submitting ? 'Validating & Issuing...' : 'Confirm & Issue Book'}
            </Button>
          </div>
        </form>

        {/* Live ID Retrieval & Eligibility Inspector */}
        <div className="xl:col-span-5 space-y-4">
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <UserCheck className="h-4 w-4 text-[#4388FF]" />
                Member Verification
              </h3>
              {matchedMember && <StatusIndicator status={matchedMember.status} />}
            </div>

            {matchedMember ? (
              <div className="space-y-2 text-xs">
                <p className="text-base font-semibold text-slate-900 dark:text-slate-100">{matchedMember.full_name}</p>
                <p className="text-slate-500 dark:text-slate-400">
                  {matchedMember.member_type} · {matchedMember.department} · {matchedMember.course}
                </p>
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between font-mono">
                  <span>Active Loans: {matchedMember.active_issues_count} / {matchedMember.max_borrow_limit}</span>
                  <span>Overdue: {matchedMember.overdue_count}</span>
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {memberId.trim()
                  ? `No member record matches "${memberId.trim().toUpperCase()}". Backend will reject unregistered IDs.`
                  : 'Enter or select a Member ID to auto-verify borrowing eligibility.'}
              </p>
            )}
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <BookOpen className="h-4 w-4 text-[#10D9A0]" />
                Book Stock Verification
              </h3>
              {matchedBook && <StatusIndicator status={matchedBook.availability_status} />}
            </div>

            {matchedBook ? (
              <div className="flex gap-4 items-start">
                <BookCover
                  title={matchedBook.title}
                  author={matchedBook.author}
                  category={matchedBook.category}
                  coverImage={matchedBook.cover_image}
                  size="sm"
                />
                <div className="flex-1 min-w-0 space-y-1 text-xs">
                  <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                    {matchedBook.title}
                  </p>
                  <p className="text-slate-500 dark:text-slate-400 truncate">
                    {matchedBook.author} · ISBN {matchedBook.isbn}
                  </p>
                  <p className="font-mono text-slate-700 dark:text-slate-200 pt-1">
                    {matchedBook.available_copies} of {matchedBook.total_copies} copies available · Shelf{' '}
                    {matchedBook.shelf_location}
                  </p>
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {bookId.trim()
                  ? `No book record matches "${bookId.trim().toUpperCase()}".`
                  : 'Enter or select a Book ID to inspect shelf availability.'}
              </p>
            )}
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101A31] p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                Current Active Checkouts ({activeIssues.length})
              </h3>
              <button
                type="button"
                onClick={() => navigate('/return')}
                className="text-xs text-[#4388FF] hover:underline cursor-pointer"
              >
                Process Returns
              </button>
            </div>
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {activeIssues.slice(0, 8).map((tx) => (
                <div
                  key={tx.id}
                  className="p-2.5 rounded-lg border border-slate-100 dark:border-slate-800/80 bg-slate-50/70 dark:bg-[#0B1224] flex items-center justify-between gap-2 text-xs"
                >
                  <div className="min-w-0">
                    <p className="font-medium text-slate-900 dark:text-slate-100 truncate">{tx.book_title}</p>
                    <p className="text-slate-500 dark:text-slate-400 truncate">
                      {tx.id} · {tx.member_name} · Due {tx.due_date}
                    </p>
                  </div>
                  <StatusIndicator status={tx.status} />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
