# CampusSolve — Smart Library Management Ecosystem

**Discover. Organize. Manage. Transform.**

CampusSolve is a full-stack Smart Library Management Ecosystem combining a **FastAPI + SQLAlchemy + SQLite** backend, **atomic synchronized CSV/JSON local persistence**, a **menu-driven Python Terminal CLI** (`python -m backend.cli`), and a **React + TypeScript + Tailwind CSS** web dashboard sharing one centralized business logic and defensive validation engine.

---

## Key Features

- **Dual Interface Architecture (Web + Terminal CLI)**: Both the FastAPI REST server (`backend/main.py`) and the interactive Python terminal interface (`python -m backend.cli`) execute identical validation and business rules in `backend/services.py` and `backend/validators.py`.
- **Automatic Synchronized Persistence (`SQLite + CSV + JSON`)**: Every create, update, delete, issue, return, and bulk import commits to `data/campussolve.db` and atomically mirrors `books.csv`, `books.json`, `members.csv`, `members.json`, `transactions.csv`, and `transactions.json` via `backend/persistence.py` (with `os.fsync` + `os.replace`, stale `.tmp` cleanup, and corrupted-file backups in `data/backups/`).
- **Executive Dashboard**: 6 live KPI counters (`Total Books`, `Available Books`, `Issued Books`, `Total Members`, `Overdue Books`, `Total Transactions` including `totalReturns` and `avgBooksIssuedPerMonth`), 6 interactive Recharts visualizations, automated threshold warning banner, quick-action shortcuts, and live activity feed.
- **Book & Member Administration**: Table & card/catalogue views, optional custom record IDs, complete CRUD, ISBN-10/13 and email/phone validation, active-loan delete protection, sorting, pagination, and CSV export.
- **Circulation Workflows & Threshold Warnings**: Validated issue/return transactions, duplicate borrow prevention, borrow-limit enforcement, automated overdue fine calculation, and `GET /api/warnings` monitoring (overdue loans, approaching due dates, out-of-stock books, anomalous copy quantities, borrow-limit breaches).
- **Unified Search, Analytics & Multi-Format Reports**: `GET /api/search` supporting keyword, scope, category, status, date range, sorting, and pagination; empty-dataset-safe analytics; and downloadable **CSV**, **JSON**, **Markdown**, and **Plain Text** reports (`executive`, `inventory`, `members`, `issues`, `returns`, `overdue`, `transactions`, `audit`).
- **Batch CSV/JSON Import & Export**: Drag-and-drop ingestion with extension validation, column matching, duplicate detection, row-level error preview, downloadable error CSV, and a bundled 38-row sample book CSV containing clean, boundary, and intentional invalid test rows.

---

## Folder Structure

```
├── server.ts                          # Express + Vite proxy entry point (port 3000) managing FastAPI (port 8001)
├── backend/
│   ├── main.py                        # FastAPI REST endpoints delegating to services.py & persistence.py
│   ├── cli.py                         # Menu-driven Python Terminal CLI (python -m backend.cli)
│   ├── services.py                    # Shared business logic, search, analytics, warnings, reports, import/export
│   ├── validators.py                  # Centralized defensive input & domain validators + ServiceError/SyncError
│   ├── persistence.py                 # Atomic write-through CSV/JSON mirror, startup hydration & corruption backups
│   ├── models.py                      # SQLAlchemy ORM models
│   ├── schemas.py                     # Pydantic v2 request/response schemas
│   ├── database.py                    # SQLite engine (WAL mode + foreign keys) & session dependency
│   ├── seed.py                        # Initial demo dataset seeder (runs only when storage is empty)
│   ├── tests/
│   │   ├── test_api.py                # REST API, circulation & boundary test suite
│   │   └── test_persistence_and_cli.py# CSV/JSON sync, corruption recovery, empty analytics & CLI tests
│   └── requirements.txt
├── src/                               # React + TypeScript + Vite SPA
├── data/
│   ├── campussolve.db                 # SQLite primary transactional database (auto-created)
│   ├── books.csv / books.json         # Synchronized book catalogue mirrors
│   ├── members.csv / members.json     # Synchronized member directory mirrors
│   ├── transactions.csv / .json       # Synchronized circulation transaction mirrors
│   ├── backups/                       # Preserved backups if corrupted/malformed files are detected
│   ├── reports/                       # Plain-text/Markdown/CSV/JSON reports saved from CLI
│   ├── sample_books_35.csv            # 38-row sample book CSV (35 clean + 1 boundary + 2 validation tests)
│   └── sample_members_35.json         # 35-entry sample member import JSON
└── docs/
    ├── API.md                         # REST API reference
    └── SYNC_ARCHITECTURE.md           # Synchronization, recovery & CLI architecture guide
```

---

## Installation & Startup

### 1. Full-Stack Web App (Port 3000)
```bash
python3 -m venv .venv && .venv/bin/pip install -r backend/requirements.txt
npm install
npm run dev
```
`server.ts` spawns FastAPI (`uvicorn backend.main:app`) on `127.0.0.1:8001`, proxies `/api/*`, and serves the React UI on `http://localhost:3000`.

### 2. Menu-Driven Python Terminal Interface
```bash
.venv/bin/python -m backend.cli
```
Provides the 13-option interactive terminal menu sharing the exact same SQLite + CSV/JSON persistence store as the web app.

### 3. Run Automated Tests, Lint & Build
```bash
.venv/bin/python -m pytest backend/tests -v
npm run lint
npm run build
```

---

## Hackathon Demo Flow
1. Start the web app (`npm run dev`) and inspect `Dashboard`, `Books`, `Members`, and `Settings -> Local CSV & JSON Synchronization`.
2. Launch `.venv/bin/python -m backend.cli` in a terminal, add a book or issue a loan via the CLI menu, and refresh the website to see the exact record appear immediately.
3. Open `Import / Export`, click **Load Sample Books CSV (38)** to preview row-level validation (37 valid incl. boundary `available=0`, 1 duplicate seeded ISBN, 1 invalid ISBN/missing title/negative copy row) and download the error CSV.
4. Inspect `Overdue Monitoring` and the top notification bell for automated threshold warnings (`GET /api/warnings`).
5. Generate an `Executive Summary` or `Audit Log` report in Markdown/CSV/JSON/TXT from either the web UI or CLI option `[12]`.
