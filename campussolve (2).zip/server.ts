import express from 'express';
import type { Request, Response } from 'express';
import { execFile, spawn } from 'node:child_process';
import type { ChildProcess } from 'node:child_process';
import fs from 'node:fs';
import http from 'node:http';
import type { IncomingMessage } from 'node:http';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import type { Duplex } from 'node:stream';
import { promisify } from 'node:util';
import { createServer as createViteServer } from 'vite';

const execFileAsync = promisify(execFile);

const FASTAPI_HOST = '127.0.0.1';
const FASTAPI_PORT = Number(process.env.FASTAPI_PORT ?? 8001);
const FASTAPI_BASE = `http://${FASTAPI_HOST}:${FASTAPI_PORT}`;

let pythonProcess: ChildProcess | null = null;
let backendReadyPromise: Promise<void> | null = null;
let lastBackendError: string | null = null;
let isShuttingDown = false;

function resolveServerPort(): number {
  const rawPort = process.env.PORT?.trim();
  const nginxPort = process.env.NGINX_PORT?.trim();
  const defaultAppPort = Number(process.env.DEFAULT_APP_PORT ?? 3000);
  if (rawPort && rawPort !== nginxPort) {
    const parsed = Number(rawPort);
    if (Number.isFinite(parsed) && parsed > 0) {
      return parsed;
    }
  }
  return Number.isFinite(defaultAppPort) && defaultAppPort > 0 ? defaultAppPort : 3000;
}

function resolveVenvPython(): string {
  return path.resolve(process.cwd(), '.venv', 'bin', 'python');
}

function resolveVenvPip(): string {
  return path.resolve(process.cwd(), '.venv', 'bin', 'pip');
}

async function hasPythonBackendDeps(pythonBin: string): Promise<boolean> {
  try {
    await execFileAsync(
      pythonBin,
      ['-c', 'import fastapi, uvicorn, sqlalchemy, pydantic, email_validator, multipart'],
      { cwd: process.cwd(), timeout: 10000 }
    );
    return true;
  } catch {
    return false;
  }
}

async function ensurePythonEnvironment(): Promise<string> {
  const venvPython = resolveVenvPython();
  if (fs.existsSync(venvPython) && (await hasPythonBackendDeps(venvPython))) {
    return venvPython;
  }

  if (await hasPythonBackendDeps('python3')) {
    return 'python3';
  }

  const venvDir = path.resolve(process.cwd(), '.venv');
  if (!fs.existsSync(venvPython)) {
    console.log('Bootstrapping Python virtual environment (.venv) for FastAPI backend...');
    try {
      await execFileAsync('python3', ['-m', 'venv', '--without-pip', venvDir], {
        cwd: process.cwd(),
        timeout: 30000,
      });
    } catch {
      await execFileAsync('python3', ['-m', 'venv', venvDir], {
        cwd: process.cwd(),
        timeout: 30000,
      });
    }
  }

  const venvPip = resolveVenvPip();
  if (!fs.existsSync(venvPip)) {
    console.log('Installing pip into .venv...');
    const getPipPath = path.join(os.tmpdir(), 'campussolve-get-pip.py');
    const resp = await fetch('https://bootstrap.pypa.io/get-pip.py');
    if (!resp.ok) {
      throw new Error(`Failed to download get-pip.py (HTTP ${resp.status})`);
    }
    const scriptContent = Buffer.from(await resp.arrayBuffer());
    fs.writeFileSync(getPipPath, scriptContent);
    try {
      await execFileAsync(venvPython, [getPipPath, '--no-warn-script-location'], {
        cwd: process.cwd(),
        timeout: 60000,
      });
    } finally {
      fs.rmSync(getPipPath, { force: true });
    }
  }

  const reqFile = path.resolve(process.cwd(), 'backend', 'requirements.txt');
  if (!fs.existsSync(reqFile)) {
    throw new Error(`Missing Python requirements file at ${reqFile}`);
  }

  console.log('Installing Python FastAPI dependencies from backend/requirements.txt...');
  await execFileAsync(venvPip, ['install', '--no-cache-dir', '-r', reqFile], {
    cwd: process.cwd(),
    timeout: 180000,
  });

  if (!(await hasPythonBackendDeps(venvPython))) {
    throw new Error('Python FastAPI dependencies failed verification after installation');
  }

  return venvPython;
}

async function isFastApiHealthy(): Promise<boolean> {
  try {
    const res = await fetch(`${FASTAPI_BASE}/api/health`);
    return res.ok;
  } catch {
    return false;
  }
}

async function waitForFastApi(proc: ChildProcess, timeoutMs = 25000): Promise<void> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (await isFastApiHealthy()) {
      return;
    }
    if (proc.exitCode !== null || proc.killed) {
      throw new Error(`FastAPI process exited prematurely with code ${proc.exitCode}`);
    }
    await new Promise((r) => setTimeout(r, 200));
  }
  throw new Error(`Python FastAPI backend did not respond at ${FASTAPI_BASE}/api/health within ${timeoutMs}ms`);
}

async function startFastApiBackend(): Promise<void> {
  if (await isFastApiHealthy()) {
    console.log(`Connected to existing FastAPI backend at ${FASTAPI_BASE}`);
    lastBackendError = null;
    return;
  }

  const pythonBin = await ensurePythonEnvironment();
  console.log(`Starting Python FastAPI backend (${pythonBin} -m uvicorn backend.main:app)...`);

  const proc = spawn(
    pythonBin,
    ['-m', 'uvicorn', 'backend.main:app', '--host', FASTAPI_HOST, '--port', String(FASTAPI_PORT)],
    {
      cwd: process.cwd(),
      stdio: 'inherit',
      env: { ...process.env },
    }
  );
  pythonProcess = proc;

  proc.on('error', (err) => {
    console.error('Failed to spawn FastAPI process:', err);
    lastBackendError = err.message;
    if (pythonProcess === proc) {
      pythonProcess = null;
    }
  });

  proc.on('exit', (code, signal) => {
    if (!isShuttingDown) {
      console.warn(`FastAPI process exited (code=${code}, signal=${signal})`);
    }
    if (pythonProcess === proc) {
      pythonProcess = null;
      backendReadyPromise = null;
    }
  });

  await waitForFastApi(proc);
  lastBackendError = null;
  console.log(`Python FastAPI + SQLAlchemy + SQLite backend ready at ${FASTAPI_BASE}`);
}

function ensureBackendReady(): Promise<void> {
  if (!backendReadyPromise) {
    backendReadyPromise = startFastApiBackend().catch((err) => {
      lastBackendError = err instanceof Error ? err.message : String(err);
      backendReadyPromise = null;
      throw err;
    });
  }
  return backendReadyPromise;
}

function registerCleanupHooks(): void {
  const cleanup = () => {
    isShuttingDown = true;
    if (pythonProcess && !pythonProcess.killed) {
      pythonProcess.kill('SIGTERM');
    }
  };
  process.once('SIGINT', () => {
    cleanup();
    process.exit(0);
  });
  process.once('SIGTERM', () => {
    cleanup();
    process.exit(0);
  });
  process.once('exit', cleanup);
}

async function proxyToFastApi(req: Request, res: Response): Promise<void> {
  try {
    await ensureBackendReady();
  } catch (err) {
    console.error('[CampusSolve Backend Boot Error]', err);
    res.status(503).json({
      error: lastBackendError || 'Python FastAPI backend is unavailable.',
      status: 503,
    });
    return;
  }

  const targetUrl = `${FASTAPI_BASE}${req.originalUrl}`;
  const headers: Record<string, string> = {};
  if (req.headers['content-type']) {
    headers['content-type'] = String(req.headers['content-type']);
  }

  const hasBody = !['GET', 'HEAD'].includes(req.method.toUpperCase());
  const body = hasBody && req.body !== undefined ? JSON.stringify(req.body) : undefined;

  try {
    const upstream = await fetch(targetUrl, {
      method: req.method,
      headers,
      body,
    });

    const text = await upstream.text();
    const contentType = upstream.headers.get('content-type') ?? 'application/json';
    res.status(upstream.status).setHeader('content-type', contentType).send(text);
  } catch (err) {
    console.error('[CampusSolve Proxy Error]', err);
    backendReadyPromise = null;
    res.status(503).json({
      error: 'Unable to reach Python FastAPI backend service. Please verify uvicorn is running.',
      status: 503,
    });
  }
}

async function proxyWebSocketUpgrade(req: IncomingMessage, clientSocket: Duplex, head: Buffer): Promise<void> {
  try {
    await ensureBackendReady();
  } catch {
    clientSocket.write('HTTP/1.1 503 Service Unavailable\r\nConnection: close\r\n\r\n');
    clientSocket.destroy();
    return;
  }

  const upstreamSocket = net.connect(FASTAPI_PORT, FASTAPI_HOST, () => {
    let rawRequest = `${req.method ?? 'GET'} ${req.url ?? '/'} HTTP/${req.httpVersion}\r\n`;
    for (let i = 0; i < req.rawHeaders.length; i += 2) {
      rawRequest += `${req.rawHeaders[i]}: ${req.rawHeaders[i + 1]}\r\n`;
    }
    rawRequest += '\r\n';
    upstreamSocket.write(rawRequest);
    if (head.length > 0) {
      upstreamSocket.write(head);
    }
    upstreamSocket.pipe(clientSocket);
    clientSocket.pipe(upstreamSocket);
  });

  upstreamSocket.on('error', () => {
    if (!clientSocket.destroyed) {
      clientSocket.destroy();
    }
  });
  clientSocket.on('error', () => {
    if (!upstreamSocket.destroyed) {
      upstreamSocket.destroy();
    }
  });
}

async function startServer() {
  registerCleanupHooks();

  // Start FastAPI in parallel so port 3000 opens immediately for pre-warming
  void ensureBackendReady().catch((err) => {
    console.error('FastAPI background startup error:', err);
  });

  const app = express();
  app.use(express.json({ limit: '15mb' }));

  // Forward all /api/* requests to Python FastAPI backend
  app.use('/api', (req, res) => {
    void proxyToFastApi(req, res);
  });

  // Vite Dev Middleware or Production Static Assets
  const distDir = path.resolve(process.cwd(), 'dist');
  const isProd = process.env.NODE_ENV === 'production' && fs.existsSync(distDir);

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const httpServer = http.createServer(app);
  httpServer.on('upgrade', (req, socket, head) => {
    if (req.url?.startsWith('/api/ws')) {
      void proxyWebSocketUpgrade(req, socket, head);
    }
  });

  const PORT = resolveServerPort();
  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`CampusSolve Ecosystem running on http://0.0.0.0:${PORT} -> FastAPI at ${FASTAPI_BASE}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start CampusSolve server:', err);
  process.exit(1);
});
