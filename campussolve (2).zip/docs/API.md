# CampusSolve REST API Documentation

Base URL: `/api` (served by Python FastAPI in `backend/main.py` on port `8001` and proxied on port `3000` via `server.ts`).

## Endpoints

### Health & Persistence Sync
- `GET /api/health` — Returns service status, SQLite readiness, current book count, and `syncStatus`.
- `GET /api/sync/status` — Returns CSV/JSON write-through synchronization status, last sync timestamp, file row counts (`books.csv/json`, `members.csv/json`, `transactions.csv/json`), and any startup recovery warnings.

### Books (`/api/books`)
- `GET /api/books?search=&category=&availability=&sort_by=&sort_dir=` — List books with active checkout counts and sorting.
- `GET /api/books/:id` — Retrieve single book details and full circulation history.
- `POST /api/books` — Create a new book (optional custom `id`, ISBN-10/13 validation & uniqueness, `total_copies >= 0`, `0 <= available_copies <= total_copies`). Syncs CSV/JSON immediately.
- `PUT /api/books/:id` — Update book metadata or copy counts (guards against reducing total copies below active loans). Syncs CSV/JSON immediately.
- `DELETE /api/books/:id` — Delete a book (`409 Conflict` if active checkouts or audit history exist). Syncs CSV/JSON immediately.

### Members (`/api/members`)
- `GET /api/members?search=&status=&department=&sort_by=&sort_dir=` — List members with active/total borrow metrics and sorting.
- `GET /api/members/:id` — Retrieve member profile and transaction history.
- `POST /api/members` — Register a new member (optional custom `id`, email format & uniqueness, phone digit count, role, borrow limit). Syncs CSV/JSON immediately.
- `PUT /api/members/:id` — Update member profile or status (`Active` / `Suspended` / `Inactive`). Syncs CSV/JSON immediately.
- `DELETE /api/members/:id` — Delete member (`409 Conflict` if active loans or audit history exist). Syncs CSV/JSON immediately.

### Issue & Return Workflows
- `GET /api/issues` — List all currently active (unreturned) checkouts.
- `POST /api/issues` — Issue a book (`member_id`, `book_id`, `issue_date`, `due_date`, `notes`). Validates member existence/Active status, book existence/`available_copies > 0`, borrow limit, duplicate active checkout, and `due_date >= issue_date`. Syncs CSV/JSON immediately.
- `GET /api/returns` — List recently completed returns.
- `POST /api/returns` — Return a book (`transaction_id`, `return_date`, `waive_fine`, `notes`). Calculates `overdue_days`, assesses fine using configured `daily_fine_rate`, restores `available_copies`, and syncs CSV/JSON immediately.

### Transactions, Unified Search, Overdue & Warnings
- `GET /api/transactions?search=&status=&start_date=&end_date=&sort_by=&sort_dir=` — Complete circulation ledger with date-range filtering and sorting.
- `GET /api/search?q=&scope=all&category=&status=&start_date=&end_date=&sort_by=relevance&sort_dir=asc&page=1&page_size=20` — Unified search across books, members, and transactions with counts and pagination.
- `GET /api/overdue?min_days=1&severity=All&search=` — Live overdue queue with severity classification (`Warning`, `High`, `Critical`) and accrued fines.
- `GET /api/warnings` — Automated threshold alerts returning `overdue`, `approachingDue` (within `warning_threshold_days`), `unavailableBooks`, `lowStockBooks`, `anomalousQuantities`, and `borrowLimitBreaches`.

### Analytics & Reports
- `GET /api/analytics?range=6m&category=All` — Zero-division-safe KPIs (`totalBooks`, `totalCopies`, `availableCopies`, `issuedBooks`, `totalMembers`, `activeMembers`, `overdueBooks`, `totalTransactions`, `totalReturns`, `avgBooksIssuedPerMonth`, `utilizationRate`, `totalFinesOutstanding`) and chart series.
- `GET /api/reports?type=executive&format=markdown&start_date=&end_date=` — Generates formatted reports (`executive`, `inventory`, `members`, `issues`, `returns`, `overdue`, `transactions`, `audit`) in `csv`, `json`, `markdown`, or `txt`.

### Import, Export, Settings & Activity
- `GET /api/import/sample?entity=books|members` — Returns bundled sample CSV/JSON datasets (`sample_books_35.csv` with 38 rows incl. boundary & invalid test cases, `sample_members_35.json` with 35 rows).
- `POST /api/import/preview` — Validates CSV/JSON upload, detects columns, flags duplicates and row-level errors.
- `POST /api/import` — Commits valid non-duplicate rows inside a SQLite transaction and syncs CSV/JSON.
- `GET /api/export?entity=books&format=csv` — Exports `books`, `members`, `transactions`, or `overdue` in `csv` or `json`.
- `GET /api/settings` & `PUT /api/settings` — Reads/updates library policies (`default_loan_days`, `daily_fine_rate`, thresholds).
- `GET /api/backup` — Exports full SQLite JSON snapshot.
- `GET /api/activity?action_type=All&search=&limit=60` — Returns system audit events.
