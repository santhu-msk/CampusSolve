# CampusSolve Storage Synchronization & CLI Architecture

## 1. Shared Business Logic Core
Both the **Web REST API** (`backend/main.py`) and the **Python Terminal Interface** (`backend/cli.py`) delegate 100% of business rules, search, analytics, reporting, and mutations to:
- `backend/validators.py` — Defensive sanitization (`sanitize_text`), record ID validation, ISBN-10/13 format checks, email/phone format checks, ISO calendar date validation, and `ServiceError` / `SyncError` exception types.
- `backend/services.py` — Shared transactional workflows (`create_book`, `update_book`, `delete_book`, `create_member`, `update_member`, `delete_member`, `issue_book`, `return_book`, `compute_warnings`, `search_records`, `build_analytics`, `generate_report`, `validate_import`, `commit_import`, `export_data`).

## 2. Authoritative Source & Atomic Write-Through Sync
- **Primary Transactional Store**: SQLite (`data/campussolve.db`) configured in WAL mode with foreign keys enabled (`backend/database.py`).
- **Synchronized Local Mirrors**: Managed by `backend/persistence.py` in `data/`:
  - `books.csv` and `books.json`
  - `members.csv` and `members.json`
  - `transactions.csv` and `transactions.json`
- Every successful mutating service call commits SQLite and immediately calls `sync_all_files(db)`, which writes each file using a temp file + `flush()` + `os.fsync()` + atomic `os.replace()`.
- If synchronization fails (e.g. disk/permission error), `SyncError` is raised explicitly and recorded in `get_sync_status()` instead of failing silently.

## 3. Startup Recovery & Corruption Safety
On both FastAPI startup (`lifespan`) and CLI startup (`CampusSolveCLI.run()`), `initialize_storage(db)` performs:
1. **Interrupted Write Cleanup**: Removes any leftover `*.tmp` files in `data/` and records a recovery warning.
2. **Corruption Inspection & Preservation**: Validates existing CSV headers/column counts and JSON array structure. If a file is corrupted or malformed, it is **copied to `data/backups/corrupted_<filename>.<timestamp>.bak` before resynchronization** — corrupted user data is never silently discarded.
3. **Hydration Precedence**: If SQLite has `0` books at startup, `initialize_storage` hydrates SQLite from existing valid CSV/JSON files first, falling back to `seed_initial_data_if_empty(db)` only when neither SQLite nor CSV/JSON contains records.

## 4. Python Terminal CLI (`python -m backend.cli`)
Implemented with Python standard library formatting (`format_table`, `paginate_table`) and zero web dependencies:
- Branded banner & 13-option loop (`0` exits safely after verifying sync status).
- Input re-prompting loops on invalid ISBNs, non-integers, out-of-range numbers, invalid dates, and email/phone errors.
- `[y/N]` confirmation required before book deletion or bulk CSV commit.
- Cross-interface consistency: edits made in the CLI appear immediately in the web app and CSV/JSON mirrors (and vice versa).
